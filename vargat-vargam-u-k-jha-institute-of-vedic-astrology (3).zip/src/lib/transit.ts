import {
  Body,
  Ecliptic,
  EclipticGeoMoon,
  GeoVector,
  SunPosition,
  type Vector,
} from "astronomy-engine";
import { lahiriAyanamsha, meanRahuLongitude } from "./birthCalc";
import {
  PLANETS,
  houseOf,
  rashiName,
  type Chart,
  type ChartSigns,
  type PlanetKey,
  type Position,
} from "./astro";

export const TRANSIT_PLANETS: PlanetKey[] = [
  "Surya",
  "Chandra",
  "Mangal",
  "Budh",
  "Guru",
  "Shukra",
  "Shani",
  "Rahu",
  "Ketu",
];

const BODIES: Partial<Record<PlanetKey, Body>> = {
  Mangal: Body.Mars,
  Budh: Body.Mercury,
  Guru: Body.Jupiter,
  Shukra: Body.Venus,
  Shani: Body.Saturn,
};

export type TransitIngress = {
  fromSign: number;
  toSign: number;
  date: Date;
  motion: "D" | "R";
};

export type TransitPlanet = {
  key: PlanetKey;
  position: Position;
  longitude: number;
  houseFromLagna: number;
  natalPosition: Position;
  signDistanceFromNatal: number;
  motion: "D" | "R";
  nextIngress: TransitIngress | null;
  secondIngress: TransitIngress | null;
};

export type TransitResult = {
  calculatedAt: Date;
  ayanamsha: number;
  janmaLagna: number;
  chartSigns: ChartSigns;
  planets: TransitPlanet[];
};

function normalize(value: number): number {
  return ((value % 360) + 360) % 360;
}

function tropicalLongitude(key: PlanetKey, date: Date): number {
  if (key === "Surya") return normalize(SunPosition(date).elon);
  if (key === "Chandra") return normalize(EclipticGeoMoon(date).lon);
  if (key === "Rahu") return meanRahuLongitude(date);
  if (key === "Ketu") return normalize(meanRahuLongitude(date) + 180);

  const body = BODIES[key];
  if (!body) throw new Error(`Unsupported transit body: ${key}`);
  const vector: Vector = GeoVector(body, date, true);
  return normalize(Ecliptic(vector).elon);
}

export function siderealTransitLongitude(key: PlanetKey, date: Date): number {
  return normalize(tropicalLongitude(key, date) - lahiriAyanamsha(date));
}

function signOf(longitude: number): number {
  return Math.floor(normalize(longitude) / 30) + 1;
}

function positionFromLongitude(longitude: number, motion: "D" | "R"): Position {
  const normalized = normalize(longitude);
  const sign = signOf(normalized);
  const within = normalized - (sign - 1) * 30;
  let seconds = Math.round(within * 3600);
  // A rounded 30°00′00″ belongs to the next sign.
  if (seconds >= 108000) seconds = 107999;
  return {
    sign,
    deg: Math.floor(seconds / 3600),
    min: Math.floor((seconds % 3600) / 60),
    sec: seconds % 60,
    motion,
  };
}

function motionAt(key: PlanetKey, date: Date): "D" | "R" {
  if (key === "Rahu" || key === "Ketu") return "R";
  if (key === "Surya" || key === "Chandra") return "D";
  const before = siderealTransitLongitude(key, new Date(date.getTime() - 12 * 3600000));
  const after = siderealTransitLongitude(key, new Date(date.getTime() + 12 * 3600000));
  const delta = ((after - before + 540) % 360) - 180;
  return delta < 0 ? "R" : "D";
}

function stepDays(key: PlanetKey): number {
  if (key === "Chandra") return 0.2;
  if (key === "Surya" || key === "Budh" || key === "Shukra") return 0.75;
  if (key === "Mangal") return 1.5;
  if (key === "Rahu" || key === "Ketu") return 3;
  if (key === "Guru") return 4;
  return 7;
}

function maxSearchDays(key: PlanetKey): number {
  if (key === "Chandra") return 45;
  if (key === "Surya" || key === "Budh" || key === "Shukra") return 900;
  if (key === "Mangal") return 1800;
  if (key === "Rahu" || key === "Ketu") return 2200;
  if (key === "Guru") return 3200;
  return 6500;
}

/** Find the next sign boundary, including retrograde re-entry. */
function findNextIngress(key: PlanetKey, start: Date): TransitIngress | null {
  const startSign = signOf(siderealTransitLongitude(key, start));
  const stepMs = stepDays(key) * 86400000;
  const limit = start.getTime() + maxSearchDays(key) * 86400000;
  let low = start.getTime();
  let high = low + stepMs;

  while (high <= limit && signOf(siderealTransitLongitude(key, new Date(high))) === startSign) {
    low = high;
    high += stepMs;
  }
  if (high > limit) return null;

  // Refine the crossing to within one second.
  while (high - low > 1000) {
    const mid = Math.floor((low + high) / 2);
    if (signOf(siderealTransitLongitude(key, new Date(mid))) === startSign) low = mid;
    else high = mid;
  }

  const date = new Date(high);
  return {
    fromSign: startSign,
    toSign: signOf(siderealTransitLongitude(key, date)),
    date,
    motion: motionAt(key, date),
  };
}

export function computeTransits(natal: Chart, date = new Date()): TransitResult {
  const chartSigns = {} as ChartSigns;
  chartSigns.Lagna = natal.Lagna.sign; // Gochar chart anchored to Janma Lagna.

  const planets = TRANSIT_PLANETS.map((key): TransitPlanet => {
    const longitude = siderealTransitLongitude(key, date);
    const motion = motionAt(key, date);
    const position = positionFromLongitude(longitude, motion);
    chartSigns[key] = position.sign;
    const nextIngress = findNextIngress(key, date);
    const secondIngress = nextIngress
      ? findNextIngress(key, new Date(nextIngress.date.getTime() + 60000))
      : null;

    return {
      key,
      position,
      longitude,
      houseFromLagna: houseOf(position.sign, natal.Lagna.sign),
      natalPosition: natal[key],
      signDistanceFromNatal: houseOf(position.sign, natal[key].sign),
      motion,
      nextIngress,
      secondIngress,
    };
  });

  // ChartSigns requires every key; Janma Lagna is used as the stable reference.
  for (const planet of PLANETS) {
    if (!(planet.key in chartSigns)) chartSigns[planet.key] = natal[planet.key].sign;
  }

  return {
    calculatedAt: date,
    ayanamsha: lahiriAyanamsha(date),
    janmaLagna: natal.Lagna.sign,
    chartSigns,
    planets,
  };
}

export function formatTransitDate(date: Date, timeZone?: string): string {
  const zone = (timeZone ?? "").split(" (")[0];
  try {
    return new Intl.DateTimeFormat("en-GB", {
      timeZone: zone.includes("/") ? zone : undefined,
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23",
    })
      .format(date)
      .replace(",", "");
  } catch {
    return date.toISOString().replace("T", " ").slice(0, 19) + " UTC";
  }
}

export function transitSummary(planet: TransitPlanet): string {
  return `${planet.key}: natal ${rashiName(planet.natalPosition.sign)} → gochar ${rashiName(
    planet.position.sign,
  )} (H${planet.houseFromLagna}, ${planet.motion})`;
}
