/**
 * ================================================================================
 * ALENA ENGINE · SPOUSE / MATCH PREDICTION (47 RULES)
 * Parashara + Jaimini (Chara Karaka & Arudha) + Navamsa (D9) + Dwadashamsa (D12)
 * + Ashtakavarga समन्वय.
 *
 * उद्देश्य: जीवनसाथी की संभावित राशि (Spouse Ascendant / Moon Sign) का निर्धारण।
 * हर नियम एक candidate राशि पर weighted vote डालता है; उच्चतम स्कोर वाली राशि
 * सबसे संभावित जीवनसाथी-राशि बनती है।
 * ================================================================================
 */

import {
  RASHI_LORDS,
  computeVarga,
  houseOf,
  rashiName,
  type Chart,
  type ChartSigns,
  type PlanetKey,
} from "./astro";
import { computeArudhaPadas } from "./arudha";
import { computeJaiminiCharKaraka } from "./jaimini";
import { computeAshtakavarga } from "./ashtakavarga";

const NATURAL_BENEFICS: PlanetKey[] = ["Guru", "Shukra", "Chandra", "Budh"];
const NATURAL_MALEFICS: PlanetKey[] = ["Surya", "Mangal", "Shani", "Rahu", "Ketu"];

const DUAL_SIGNS = [3, 6, 9, 12];
const MOVABLE_SIGNS = [1, 4, 7, 10];
const FIXED_SIGNS = [2, 5, 8, 11];

function norm(n: number): number {
  return ((n - 1) % 12 + 12) % 12 + 1;
}

/** count-th house sign from a base sign (1-based, base counts as 1) */
function houseSign(base: number, count: number): number {
  return norm(base + (count - 1));
}

export type SpouseCategory =
  | "Parashari 7th"
  | "Jaimini DK"
  | "Jaimini UL (A7)"
  | "Navamsa D9"
  | "Dwadashamsa D12"
  | "Ashtakavarga"
  | "Karakamsa"
  | "Combination";

export type SpouseRule = {
  id: number;
  category: SpouseCategory;
  title: string;
  detail: string;
  candidateSign: number | null; // predicted spouse rashi (1..12) or null (no vote)
  weight: number;
};

export type SpouseTally = {
  sign: number;
  score: number;
  rules: number[]; // rule ids voting for this sign
};

export type SpouseResult = {
  rules: SpouseRule[];
  tally: SpouseTally[];
  topSign: number | null;
  topScore: number;
  d9: ChartSigns;
  d12: ChartSigns;
  seventhSign: number;
  dkSign: number;
  ulSign: number;
  dkPlanet: PlanetKey;
};

export function computeSpousePrediction(chart: Chart): SpouseResult {
  const lagna = chart.Lagna.sign;
  const d9 = computeVarga(chart, "D9");
  const d12Real = computeD12(chart);
  const arudha = computeArudhaPadas(chart);
  const karakas = computeJaiminiCharKaraka(chart);
  const av = computeAshtakavarga(chart);

  const seventhSign = houseSign(lagna, 7);
  const seventhLord = RASHI_LORDS[seventhSign];
  const seventhLordSign = chart[seventhLord].sign;

  const dk = karakas.find((k) => k.karaka.role === "DK")!;
  const dkPlanet = dk.key;
  const dkSign = chart[dkPlanet].sign;
  const dk7 = houseSign(dkSign, 7);

  // Upapada Lagna (UL) = Arudha of the 12th house (A12)
  const a12 = arudha.find((a) => a.label === "A12")!;
  const ulSign = a12.arudhaSign;
  const ul2 = houseSign(ulSign, 2);

  // Navamsa 7th and its lord
  const d9Lagna = d9.Lagna;
  const d9Seventh = houseSign(d9Lagna, 7);

  const rules: SpouseRule[] = [];
  const add = (
    id: number,
    category: SpouseCategory,
    title: string,
    detail: string,
    candidateSign: number | null,
    weight: number,
  ) => rules.push({ id, category, title, detail, candidateSign, weight });

  /* ---------------- PARASHARI (7TH HOUSE) — Rules 1–12 ---------------- */
  add(1, "Parashari 7th", "7वाँ भाव राशि", `Lagna ${rashiName(lagna)} से 7वीं राशि जीवनसाथी की मूल राशि है।`, seventhSign, 5);
  add(2, "Parashari 7th", "7वें भाव का स्वामी", `7वेश ${seventhLord} जिस राशि ${rashiName(seventhLordSign)} में है वह जीवनसाथी संकेत देती है।`, seventhLordSign, 3);
  add(3, "Parashari 7th", "7वेश से 7वाँ", `7वेश की राशि से 7वीं राशि।`, houseSign(seventhLordSign, 7), 2);
  add(4, "Parashari 7th", "शुक्र (दारा कारक ग्रह)", `शुक्र की राशि ${rashiName(chart.Shukra.sign)} — स्त्री/पत्नी का नैसर्गिक कारक।`, chart.Shukra.sign, 3);
  add(5, "Parashari 7th", "शुक्र से 7वाँ", `शुक्र से 7वीं राशि।`, houseSign(chart.Shukra.sign, 7), 2);
  add(6, "Parashari 7th", "गुरु (पति कारक)", `गुरु की राशि ${rashiName(chart.Guru.sign)} — पति का नैसर्गिक कारक।`, chart.Guru.sign, 3);
  add(7, "Parashari 7th", "गुरु से 7वाँ", `गुरु से 7वीं राशि।`, houseSign(chart.Guru.sign, 7), 2);
  add(8, "Parashari 7th", "7वें भाव में स्थित ग्रह", planetInSeventh(chart, seventhSign), planetSignInHouse(chart, seventhSign), 3);
  add(9, "Parashari 7th", "चंद्र से 7वाँ", `चंद्र लग्न ${rashiName(chart.Chandra.sign)} से 7वीं राशि।`, houseSign(chart.Chandra.sign, 7), 2);
  add(10, "Parashari 7th", "सूर्य से 7वाँ", `सूर्य ${rashiName(chart.Surya.sign)} से 7वीं राशि (पुरुष के लिए)।`, houseSign(chart.Surya.sign, 7), 1);
  add(11, "Parashari 7th", "7वेश का नवांश", `7वेश ${seventhLord} का नवांश राशि।`, d9[seventhLord], 2);
  add(12, "Parashari 7th", "7वें भाव की राशि-प्रकृति", signNatureNote(seventhSign), seventhSign, 1);

  /* ---------------- JAIMINI DK — Rules 13–22 ---------------- */
  add(13, "Jaimini DK", "दारा कारक (DK) राशि", `DK = ${dkPlanet} (${rashiName(dkSign)}) — जीवनसाथी का प्रमुख जैमिनि कारक।`, dkSign, 5);
  add(14, "Jaimini DK", "DK से 7वाँ", `DK ${dkPlanet} से 7वीं राशि जीवनसाथी की राशि/स्वभाव।`, dk7, 4);
  add(15, "Jaimini DK", "DK राशि का स्वामी", `${rashiName(dkSign)} का स्वामी ${RASHI_LORDS[dkSign]} जहाँ है।`, chart[RASHI_LORDS[dkSign]].sign, 2);
  add(16, "Jaimini DK", "DK का नवांश", `DK ${dkPlanet} का नवांश राशि।`, d9[dkPlanet], 3);
  add(17, "Jaimini DK", "DK के नवांश से 7वाँ", `DK के नवांश से 7वीं राशि।`, houseSign(d9[dkPlanet], 7), 2);
  add(18, "Jaimini DK", "DK का द्वादशांश (D12)", `DK ${dkPlanet} का D12 राशि — कुटुम्ब/विवाह संकेत।`, d12Real[dkPlanet], 2);
  add(19, "Jaimini DK", "DK Ashtakavarga बल", dkAshtakaNote(av, dkSign), dkSign, 1);
  add(20, "Jaimini DK", "DK व 7वें का योग", `DK राशि ${rashiName(dkSign)} और 7वीं राशि ${rashiName(seventhSign)} के बीच संकेत।`, dkSign === seventhSign ? dkSign : dk7, 2);
  add(21, "Jaimini DK", "DK चंद्र-सम्बंध", `DK से चंद्र की स्थिति से जीवनसाथी की मानसिक प्रकृति।`, houseSign(dkSign, houseOf(chart.Chandra.sign, dkSign)), 1);
  add(22, "Jaimini DK", "DK शुक्र-सम्बंध", `DK व शुक्र का सम्बंध — आकर्षण/सौंदर्य संकेत।`, houseSign(dkSign, houseOf(chart.Shukra.sign, dkSign)), 1);

  /* ---------------- JAIMINI UL (A7 / Upapada) — Rules 23–30 ---------------- */
  add(23, "Jaimini UL (A7)", "उपपद लग्न (UL)", `UL (A12 आरूढ़) = ${rashiName(ulSign)} — विवाह/जीवनसाथी का प्रमुख आरूढ़।`, ulSign, 5);
  add(24, "Jaimini UL (A7)", "UL से 2रा", `UL से 2री राशि जीवनसाथी की स्थायित्व-राशि।`, ul2, 3);
  add(25, "Jaimini UL (A7)", "UL का स्वामी", `${rashiName(ulSign)} का स्वामी ${RASHI_LORDS[ulSign]} जहाँ है।`, chart[RASHI_LORDS[ulSign]].sign, 2);
  add(26, "Jaimini UL (A7)", "UL से 7वाँ", `UL से 7वीं राशि।`, houseSign(ulSign, 7), 2);
  add(27, "Jaimini UL (A7)", "UL का नवांश", `UL राशि-स्वामी ${RASHI_LORDS[ulSign]} का नवांश।`, d9[RASHI_LORDS[ulSign]], 2);
  add(28, "Jaimini UL (A7)", "A7 (7वें का आरूढ़)", a7Note(arudha), a7Sign(arudha), 3);
  add(29, "Jaimini UL (A7)", "UL व DK समन्वय", `UL ${rashiName(ulSign)} व DK ${rashiName(dkSign)} — दोनों की संगति।`, ulSign === dkSign ? ulSign : ul2, 2);
  add(30, "Jaimini UL (A7)", "UL Ashtakavarga", ulAshtakaNote(av, ulSign), ulSign, 1);

  /* ---------------- NAVAMSA D9 — Rules 31–38 ---------------- */
  add(31, "Navamsa D9", "नवांश लग्न", `D9 लग्न ${rashiName(d9Lagna)} — विवाह जीवन का सूक्ष्म आधार।`, d9Lagna, 3);
  add(32, "Navamsa D9", "नवांश 7वाँ", `नवांश लग्न से 7वीं राशि ${rashiName(d9Seventh)} — जीवनसाथी की सूक्ष्म राशि।`, d9Seventh, 5);
  add(33, "Navamsa D9", "नवांश 7वेश", `D9-7वेश ${RASHI_LORDS[d9Seventh]} की D1 राशि।`, chart[RASHI_LORDS[d9Seventh]].sign, 2);
  add(34, "Navamsa D9", "नवांश में शुक्र", `शुक्र का नवांश ${rashiName(d9.Shukra)}।`, d9.Shukra, 2);
  add(35, "Navamsa D9", "नवांश में गुरु", `गुरु का नवांश ${rashiName(d9.Guru)}।`, d9.Guru, 2);
  add(36, "Navamsa D9", "नवांश में DK", `DK ${dkPlanet} का नवांश ${rashiName(d9[dkPlanet])} — जीवनसाथी का रूप।`, d9[dkPlanet], 3);
  add(37, "Navamsa D9", "वर्गोत्तम 7वाँ", vargottamaNote(seventhSign, d9Seventh), d9Seventh === seventhSign ? seventhSign : d9Seventh, 2);
  add(38, "Navamsa D9", "नवांश 7वें में ग्रह", planetInSign(d9, d9Seventh), planetSignD9(chart, d9, d9Seventh), 2);

  /* ---------------- DWADASHAMSA D12 — Rules 39–43 ---------------- */
  add(39, "Dwadashamsa D12", "D12 लग्न", `D12 लग्न ${rashiName(d12Real.Lagna)} — कुटुम्ब/ससुराल संकेत।`, d12Real.Lagna, 2);
  add(40, "Dwadashamsa D12", "D12 7वाँ", `D12 लग्न से 7वीं राशि ${rashiName(houseSign(d12Real.Lagna, 7))}।`, houseSign(d12Real.Lagna, 7), 3);
  add(41, "Dwadashamsa D12", "D12 में शुक्र", `शुक्र का D12 ${rashiName(d12Real.Shukra)}।`, d12Real.Shukra, 2);
  add(42, "Dwadashamsa D12", "D12 में DK", `DK ${dkPlanet} का D12 ${rashiName(d12Real[dkPlanet])}।`, d12Real[dkPlanet], 2);
  add(43, "Dwadashamsa D12", "D12 7वेश", `D12-7वेश ${RASHI_LORDS[houseSign(d12Real.Lagna, 7)]}।`, chart[RASHI_LORDS[houseSign(d12Real.Lagna, 7)]].sign, 1);

  /* ---------------- ASHTAKAVARGA + KARAKAMSA + COMBINATION — Rules 44–47 ---------------- */
  const av7Best = bestAshtakaSign(av, [seventhSign, dkSign, ulSign]);
  add(44, "Ashtakavarga", "7वें/DK/UL में उच्चतम बिन्दु राशि", `Ashtakavarga में सर्वाधिक बिन्दु वाली उम्मीदवार राशि ${rashiName(av7Best)}।`, av7Best, 3);
  const ak = karakas.find((k) => k.karaka.role === "AK")!;
  const karakamsa = d9[ak.key];
  add(45, "Karakamsa", "कारकांश से 7वाँ (DK दृष्टि)", `कारकांश (AK नवांश ${rashiName(karakamsa)}) से 7वीं राशि जीवनसाथी संकेत।`, houseSign(karakamsa, 7), 3);
  add(46, "Combination", "7वाँ + DK संयुक्त", `Parashari 7वाँ (${rashiName(seventhSign)}) व Jaimini DK (${rashiName(dkSign)}) का संयुक्त संकेत।`, combineTwo(seventhSign, dkSign), 3);
  add(47, "Combination", "अंतिम समन्वय (D9-7 + UL)", `नवांश 7वाँ (${rashiName(d9Seventh)}) व UL (${rashiName(ulSign)}) का समन्वय — सबसे सूक्ष्म संकेत।`, combineTwo(d9Seventh, ulSign), 4);

  // Tally
  const scoreBySign = new Map<number, { score: number; rules: number[] }>();
  for (const r of rules) {
    if (r.candidateSign == null) continue;
    const cur = scoreBySign.get(r.candidateSign) ?? { score: 0, rules: [] };
    cur.score += r.weight;
    cur.rules.push(r.id);
    scoreBySign.set(r.candidateSign, cur);
  }
  const tally: SpouseTally[] = Array.from(scoreBySign.entries())
    .map(([sign, v]) => ({ sign, score: v.score, rules: v.rules }))
    .sort((a, b) => b.score - a.score || a.sign - b.sign);

  const top = tally[0] ?? null;

  return {
    rules,
    tally,
    topSign: top ? top.sign : null,
    topScore: top ? top.score : 0,
    d9,
    d12: d12Real,
    seventhSign,
    dkSign,
    ulSign,
    dkPlanet,
  };
}

/* ------------------------------ helpers ------------------------------ */

function computeD12(chart: Chart): ChartSigns {
  // Dwadashamsa: 2.5° each; part index 0..11; sign = ((base-1 + part) % 12)+1
  const out = {} as ChartSigns;
  for (const key of Object.keys(chart) as PlanetKey[]) {
    const pos = chart[key];
    const within = pos.deg + pos.min / 60 + pos.sec / 3600;
    const part = Math.min(11, Math.floor(within / 2.5));
    out[key] = norm(pos.sign + part);
  }
  return out;
}

function planetInSeventh(chart: Chart, seventhSign: number): string {
  const occupant = (Object.keys(chart) as PlanetKey[]).find(
    (k) => k !== "Lagna" && chart[k].sign === seventhSign,
  );
  return occupant
    ? `7वें भाव में ${occupant} स्थित — जीवनसाथी के स्वभाव पर सीधा प्रभाव।`
    : `7वें भाव में कोई ग्रह नहीं; राशि ${rashiName(seventhSign)} व स्वामी प्रधान।`;
}

function planetSignInHouse(chart: Chart, seventhSign: number): number {
  const occupant = (Object.keys(chart) as PlanetKey[]).find(
    (k) => k !== "Lagna" && chart[k].sign === seventhSign,
  );
  return occupant ? chart[occupant].sign : seventhSign;
}

function planetInSign(signs: ChartSigns, sign: number): string {
  const occupant = (Object.keys(signs) as PlanetKey[]).find(
    (k) => k !== "Lagna" && signs[k] === sign,
  );
  return occupant
    ? `नवांश ${rashiName(sign)} में ${occupant} — जीवनसाथी विशेषता।`
    : `नवांश 7वें राशि ${rashiName(sign)} खाली; राशि प्रधान।`;
}

function planetSignD9(chart: Chart, d9: ChartSigns, sign: number): number {
  const occupant = (Object.keys(d9) as PlanetKey[]).find((k) => k !== "Lagna" && d9[k] === sign);
  return occupant ? chart[occupant].sign : sign;
}

function signNatureNote(sign: number): string {
  if (MOVABLE_SIGNS.includes(sign)) return "चर राशि — दूर/भिन्न स्थान का जीवनसाथी संकेत।";
  if (FIXED_SIGNS.includes(sign)) return "स्थिर राशि — निकट/परिचित जीवनसाथी संकेत।";
  return "द्विस्वभाव राशि — मिश्रित/मध्यम दूरी का जीवनसाथी संकेत।";
}

function dkAshtakaNote(av: ReturnType<typeof computeAshtakavarga>, sign: number): string {
  const b = av.sarva[sign - 1];
  return `DK राशि ${rashiName(sign)} में Sarvashtakavarga ${b} बिन्दु — ${b >= 28 ? "बलवान" : "मध्यम"} विवाह-योग।`;
}

function ulAshtakaNote(av: ReturnType<typeof computeAshtakavarga>, sign: number): string {
  const b = av.sarva[sign - 1];
  return `UL राशि ${rashiName(sign)} में Sarvashtakavarga ${b} बिन्दु।`;
}

function bestAshtakaSign(av: ReturnType<typeof computeAshtakavarga>, candidates: number[]): number {
  return candidates.reduce((best, s) => (av.sarva[s - 1] > av.sarva[best - 1] ? s : best), candidates[0]);
}

function a7Sign(arudha: ReturnType<typeof computeArudhaPadas>): number {
  const a7 = arudha.find((a) => a.label === "A7");
  return a7 ? a7.arudhaSign : arudha[0].arudhaSign;
}

function a7Note(arudha: ReturnType<typeof computeArudhaPadas>): string {
  const a7 = arudha.find((a) => a.label === "A7");
  return a7
    ? `A7 (7वें भाव का आरूढ़) = ${rashiName(a7.arudhaSign)} — प्रत्यक्ष जीवनसाथी-छवि।`
    : "A7 गणना उपलब्ध नहीं।";
}

function vargottamaNote(d1Seventh: number, d9Seventh: number): string {
  return d1Seventh === d9Seventh
    ? `7वाँ भाव वर्गोत्तम (D1=D9=${rashiName(d1Seventh)}) — अत्यंत प्रबल संकेत।`
    : `D1-7 ${rashiName(d1Seventh)} व D9-7 ${rashiName(d9Seventh)} भिन्न; D9 प्रधान।`;
}

function combineTwo(a: number, b: number): number {
  // If same, that sign; else the one that is a dual sign, else the first.
  if (a === b) return a;
  if (DUAL_SIGNS.includes(a)) return a;
  if (DUAL_SIGNS.includes(b)) return b;
  return a;
}

export { NATURAL_BENEFICS, NATURAL_MALEFICS };
