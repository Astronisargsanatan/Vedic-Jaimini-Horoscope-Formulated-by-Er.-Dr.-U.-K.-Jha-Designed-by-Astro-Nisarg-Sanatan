import type { EngineeringFactor } from "./astro";

export type VargaEngineeringMeta = {
  number: number;
  name: string;
  focus: string;
};

const FACTOR_META: Record<EngineeringFactor, VargaEngineeringMeta> = {
  2: { number: 2, name: "Hora", focus: "wealth, resources and material sustenance" },
  3: { number: 3, name: "Drekkana", focus: "courage, siblings and personal initiative" },
  4: { number: 4, name: "Chaturthansh", focus: "home, property and foundational security" },
  5: { number: 5, name: "Panchamansh", focus: "merit, creativity, intelligence and progeny" },
  6: { number: 6, name: "Shashtamansh", focus: "health, obstacles, service and resilience" },
  8: { number: 8, name: "Ashtamansh", focus: "longevity, transformation and sudden events" },
  9: { number: 9, name: "Navamansh", focus: "dharma, marriage and inner strength" },
  10: { number: 10, name: "Dashamansh", focus: "career, authority, action and public responsibility" },
};

const HARMONIC_NAMES: Record<number, string> = {
  1: "Rashi",
  2: "Hora",
  3: "Drekkana",
  4: "Chaturthansh",
  5: "Panchamansh",
  6: "Shashtamansh",
  7: "Saptamansh",
  8: "Ashtamansh",
  9: "Navamansh",
  10: "Dashamansh",
  12: "Dwadashamsha",
  16: "Shodashamsha",
  20: "Vimshamsha",
  24: "Chaturvimshamsha",
  27: "Bhamsa",
  30: "Trimshamsha",
  40: "Khavedamsha",
  45: "Akshavedamsha",
  60: "Shashtiamsha",
};

export function engineeringFactorMeta(factor: number): VargaEngineeringMeta {
  return FACTOR_META[factor as EngineeringFactor] ?? {
    number: factor,
    name: HARMONIC_NAMES[factor] ?? `D${factor} Harmonic`,
    focus: "the selected harmonic field",
  };
}

export function harmonicName(number: number): string {
  return HARMONIC_NAMES[number] ?? `D${number} Harmonic`;
}

export function mappingNotation(factors: readonly number[]): string {
  return factors.map((factor) => `D${factor}`).join(" × ");
}

export function layerNotation(factors: readonly number[]): string {
  return factors.map((factor) => `D${factor}`).join(" of ");
}

export function layerName(factors: readonly number[]): string {
  return factors.map((factor) => engineeringFactorMeta(factor).name).join(" of ");
}

export function mappingId(factors: readonly number[]): string {
  return factors.map((factor) => `D${factor}`).join("x");
}

export function focusArea(factors: readonly number[]): string {
  if (factors.length === 0) return "No harmonic focus available.";
  const base = engineeringFactorMeta(factors[0]);
  const lenses = factors.slice(1).map(engineeringFactorMeta);
  if (lenses.length === 0) return `Direct assessment of ${base.focus}.`;

  return `${capitalize(base.focus)} examined through ${lenses
    .map((meta) => meta.focus)
    .join(", then ")}.`;
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}