import { degWithinSign, type Chart, type PlanetKey } from "./astro";
import {
  DASHA_SEQUENCE,
  NAKSHATRAS,
  NAKSHATRA_SPAN,
  YEAR_MS,
  buildDashaChildren,
  sequenceFrom,
  type DashaLord,
  type DashaPeriod,
} from "./vimshottari";

export type AarshaCycle = "Krittikadi" | "Ardradi";
export type BirthHora = "Surya Hora" | "Chandra Hora";
export type Paksha = "Shukla Paksha" | "Krishna Paksha";

const ARDRADI_OWNERS: Record<string, DashaLord> = {
  Ardra: "Surya",
  Swati: "Surya",
  Shatabhisha: "Surya",
  Punarvasu: "Chandra",
  Vishakha: "Chandra",
  "Purva Bhadrapada": "Chandra",
  Pushya: "Mangal",
  Anuradha: "Mangal",
  "Uttara Bhadrapada": "Mangal",
  Ashlesha: "Rahu",
  Jyeshtha: "Rahu",
  Revati: "Rahu",
  Ashwini: "Guru",
  Magha: "Guru",
  Mula: "Guru",
  Bharani: "Shani",
  "Purva Phalguni": "Shani",
  "Purva Ashadha": "Shani",
  Krittika: "Budh",
  "Uttara Phalguni": "Budh",
  "Uttara Ashadha": "Budh",
  Rohini: "Ketu",
  Hasta: "Ketu",
  Shravana: "Ketu",
  Mrigashira: "Shukra",
  Chitra: "Shukra",
  Dhanishta: "Shukra",
};

export type NakshatraPosition = {
  longitude: number;
  index: number;
  name: string;
  pada: number;
  withinDegrees: number;
  traversedFraction: number;
};

export type AarshaResult = {
  hora: BirthHora;
  paksha: Paksha;
  cycle: AarshaCycle;
  lagnaNakshatra: NakshatraPosition;
  moonNakshatra: NakshatraPosition;
  inclusiveCount: number;
  targetNakshatra: NakshatraPosition;
  triggeringPlanet: DashaLord;
  triggeringPlanetNakshatra: NakshatraPosition;
  firstDashaLord: DashaLord;
  /** Balance source: the First Mahadasha Lord's own D1 Nakshatra position. */
  firstDashaLordNakshatra: NakshatraPosition;
  firstDashaYears: number;
  traversedArcMinutes: number;
  remainingArcMinutes: number;
  bhuktaAtBirthMs: number;
  bhogyaAtBirthMs: number;
  mahadashas: DashaPeriod[];
  activePath: DashaPeriod[];
};

function absoluteLongitude(chart: Chart, key: PlanetKey): number {
  return (chart[key].sign - 1) * 30 + degWithinSign(chart[key]);
}

export function nakshatraAt(longitude: number): NakshatraPosition {
  const normalized = ((longitude % 360) + 360) % 360;
  const index = Math.min(26, Math.floor(normalized / NAKSHATRA_SPAN));
  const withinDegrees = normalized - index * NAKSHATRA_SPAN;
  return {
    longitude: normalized,
    index,
    name: NAKSHATRAS[index].name,
    pada: Math.min(4, Math.floor(withinDegrees / (NAKSHATRA_SPAN / 4)) + 1),
    withinDegrees,
    traversedFraction: withinDegrees / NAKSHATRA_SPAN,
  };
}

export function ownerForCycle(nakshatraName: string, cycle: AarshaCycle): DashaLord {
  if (cycle === "Ardradi") return ARDRADI_OWNERS[nakshatraName];
  return NAKSHATRAS.find((item) => item.name === nakshatraName)!.lord;
}

/** Traditional Hora of the natal Lagna: odd signs Sun-first, even signs Moon-first. */
function birthHora(chart: Chart): BirthHora {
  const lagna = chart.Lagna;
  const firstHalf = degWithinSign(lagna) < 15;
  const oddSign = lagna.sign % 2 === 1;
  return oddSign === firstHalf ? "Surya Hora" : "Chandra Hora";
}

/** Shukla when Moon is 0..180° ahead of Sun, otherwise Krishna. */
function birthPaksha(chart: Chart): Paksha {
  const elongation =
    (absoluteLongitude(chart, "Chandra") - absoluteLongitude(chart, "Surya") + 360) % 360;
  return elongation < 180 ? "Shukla Paksha" : "Krishna Paksha";
}

function selectCycle(hora: BirthHora, paksha: Paksha): AarshaCycle {
  const sameNature =
    (hora === "Surya Hora" && paksha === "Shukla Paksha") ||
    (hora === "Chandra Hora" && paksha === "Krishna Paksha");
  return sameNature ? "Ardradi" : "Krittikadi";
}

function planetKey(lord: DashaLord): PlanetKey {
  return lord as PlanetKey;
}

export function computeAarshaVimshottari(
  chart: Chart,
  birth: Date,
  now = new Date(),
): AarshaResult {
  const hora = birthHora(chart);
  const paksha = birthPaksha(chart);
  const cycle = selectCycle(hora, paksha);
  const lagnaNakshatra = nakshatraAt(absoluteLongitude(chart, "Lagna"));
  const moonNakshatra = nakshatraAt(absoluteLongitude(chart, "Chandra"));

  // Inclusive counting: Lagna Nakshatra is 1; Moon Nakshatra is the last count.
  const inclusiveCount = ((moonNakshatra.index - lagnaNakshatra.index + 27) % 27) + 1;
  // Count the same number again from Moon inclusively.
  const targetIndex = (moonNakshatra.index + inclusiveCount - 1) % 27;
  const targetNakshatra = nakshatraAt(targetIndex * NAKSHATRA_SPAN);
  const triggeringPlanet = ownerForCycle(targetNakshatra.name, cycle);
  const triggeringPlanetNakshatra = nakshatraAt(
    absoluteLongitude(chart, planetKey(triggeringPlanet)),
  );
  const firstDashaLord = ownerForCycle(triggeringPlanetNakshatra.name, cycle);

  const firstYears = DASHA_SEQUENCE.find((item) => item.lord === firstDashaLord)!.years;
  const firstTotalMs = firstYears * YEAR_MS;
  // STRICT AARSHA BALANCE RULE:
  // Triggering Planet is ONLY a pointer that identifies the First Dasha Lord.
  // Bhukta/Bhogya comes from the First Dasha Lord's OWN longitude in its
  // occupied Nakshatra. The Triggering Planet's degrees are never used here.
  const firstDashaLordNakshatra = nakshatraAt(
    absoluteLongitude(chart, planetKey(firstDashaLord)),
  );
  const traversedArcMinutes = firstDashaLordNakshatra.withinDegrees * 60;
  const remainingArcMinutes = 800 - traversedArcMinutes;
  const bhuktaAtBirthMs = (traversedArcMinutes / 800) * firstTotalMs;
  const bhogyaAtBirthMs = (remainingArcMinutes / 800) * firstTotalMs;
  const firstEnd = birth.getTime() + bhogyaAtBirthMs;
  const firstStart = firstEnd - firstTotalMs;
  const sequence = sequenceFrom(firstDashaLord);
  const mahadashas: DashaPeriod[] = [];

  mahadashas.push({
    lord: firstDashaLord,
    level: 1,
    start: new Date(firstStart),
    end: new Date(firstEnd),
    durationMs: firstTotalMs,
    children: buildDashaChildren(firstDashaLord, new Date(firstStart), firstTotalMs, 1),
  });

  let cursor = firstEnd;
  for (let i = 1; i < sequence.length; i++) {
    const item = sequence[i];
    const durationMs = item.years * YEAR_MS;
    const start = new Date(cursor);
    const end = new Date(cursor + durationMs);
    mahadashas.push({
      lord: item.lord,
      level: 1,
      start,
      end,
      durationMs,
      children: buildDashaChildren(item.lord, start, durationMs, 1),
    });
    cursor = end.getTime();
  }

  const activePath: DashaPeriod[] = [];
  let level: DashaPeriod[] | undefined = mahadashas;
  while (level) {
    const active: DashaPeriod | undefined = level.find(
      (period) => now >= period.start && now < period.end,
    );
    if (!active) break;
    activePath.push(active);
    level = active.children;
  }

  return {
    hora,
    paksha,
    cycle,
    lagnaNakshatra,
    moonNakshatra,
    inclusiveCount,
    targetNakshatra,
    triggeringPlanet,
    triggeringPlanetNakshatra,
    firstDashaLord,
    firstDashaLordNakshatra,
    firstDashaYears: firstYears,
    traversedArcMinutes,
    remainingArcMinutes,
    bhuktaAtBirthMs,
    bhogyaAtBirthMs,
    mahadashas,
    activePath,
  };
}
