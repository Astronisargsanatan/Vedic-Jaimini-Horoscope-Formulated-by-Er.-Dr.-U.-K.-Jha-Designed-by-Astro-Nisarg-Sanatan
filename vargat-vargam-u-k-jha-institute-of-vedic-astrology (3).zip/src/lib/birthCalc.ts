/**
 * ================================================================================
 * MODULE: KUNDALI_CORE_COMPUTATION_ENGINE (ALENA_ENGINE_V3)
 * STANDARD: LAHIRI NIRAYANA (CHITRAPAKSHA AYANAMSHA)
 * ================================================================================
 */

import {
  Body,
  Ecliptic,
  EclipticGeoMoon,
  GeoVector,
  MakeTime,
  SiderealTime,
  SunPosition,
  e_tilt,
  type Vector,
} from "astronomy-engine";
import type { Chart, PlanetKey, Position } from "./astro";
import { computeArudhaPadas } from "./arudha";
import { computeJaiminiCharKaraka } from "./jaimini";
import { lookupPlaceTimezone } from "./gazetteer";
import { type GeoResult } from "./geo";
import tzLookup from "tz-lookup";

export type { GeoResult };

export type BirthInput = {
  fullName: string;
  date: string; // DD/MM/YYYY
  time: string; // HH:MM:SS
  locationMode?: "gazetteer" | "online" | "manual";
  placeId?: string;
  placeLabel?: string;
  onlinePlaceName?: string;
  onlineLatitude?: number;
  onlineLongitude?: number;
  manualCoordinateFormat?: "DD" | "DMS";
  customPlaceName?: string;
  latitude?: string;
  latitudeDirection?: "N" | "S";
  latitudeDegrees?: string;
  latitudeMinutes?: string;
  latitudeSeconds?: string;
  longitude?: string;
  longitudeDirection?: "E" | "W";
  longitudeDegrees?: string;
  longitudeMinutes?: string;
  longitudeSeconds?: string;
  timezoneOffset?: string; // ±HH:MM
};

type ParsedDateTime = {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
};

const BODY_MAP: Partial<Record<PlanetKey, Body>> = {
  Mangal: Body.Mars,
  Budh: Body.Mercury,
  Guru: Body.Jupiter,
  Shukra: Body.Venus,
  Shani: Body.Saturn,
};

const DEG2RAD = Math.PI / 180;
const RAD2DEG = 180 / Math.PI;

function fail(step: string, message: string): never {
  throw new Error(`[${step}] ${message}`);
}

/* ------------------------------------------------------------------ */
/* STEP 0 — INPUT VALIDATION                                           */
/* ------------------------------------------------------------------ */

export function parseBirthDateTime(date: string, time: string): ParsedDateTime {
  const dateMatch = date.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!dateMatch) fail("STEP 0", "Date of Birth must be in DD/MM/YYYY format.");

  const timeMatch = time.trim().match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
  if (!timeMatch) fail("STEP 0", "Time of Birth must be in HH:MM:SS 24-hour format.");

  const day = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const year = Number(dateMatch[3]);
  const hour = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  const second = Number(timeMatch[3] ?? 0);

  if (month < 1 || month > 12) fail("STEP 0", "Birth month must be between 1 and 12.");
  if (day < 1 || day > 31) fail("STEP 0", "Birth day must be between 1 and 31.");
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) {
    fail("STEP 0", "Birth time must be a valid 24-hour time.");
  }

  const probe = new Date(Date.UTC(year, month - 1, day, hour, minute, second));
  if (probe.getUTCFullYear() !== year || probe.getUTCMonth() !== month - 1 || probe.getUTCDate() !== day) {
    fail("STEP 0", "Date of Birth is not a valid calendar date.");
  }

  return { year, month, day, hour, minute, second };
}

/* ------------------------------------------------------------------ */
/* STEP 1 — GEO-TEMPORAL RESOLUTION                                    */
/* ------------------------------------------------------------------ */

export function geoFromPlace(placeId: string): GeoResult {
  const resolved = lookupPlaceTimezone(placeId);
  if (resolved) return resolved;
  fail("STEP 1", "Select a birth place from the dropdown list.");
}

function parseCoordinate(
  value: string | undefined,
  direction: "N" | "S" | "E" | "W" | undefined,
  kind: "latitude" | "longitude",
): number {
  const number = Number((value ?? "").trim());
  const limit = kind === "latitude" ? 90 : 180;
  if (!Number.isFinite(number) || number < 0 || number > limit) {
    fail(
      "STEP 1",
      `${kind === "latitude" ? "Latitude" : "Longitude"} must be between 0 and ${limit}.`,
    );
  }
  const negative = direction === "S" || direction === "W";
  return negative ? -number : number;
}

function parseDmsCoordinate(
  degrees: string | undefined,
  minutes: string | undefined,
  seconds: string | undefined,
  direction: "N" | "S" | "E" | "W" | undefined,
  kind: "latitude" | "longitude",
): number {
  const d = Number((degrees ?? "").trim());
  const m = Number((minutes ?? "").trim());
  const s = Number((seconds ?? "").trim());
  const limit = kind === "latitude" ? 90 : 180;
  if (
    !Number.isFinite(d) ||
    !Number.isFinite(m) ||
    !Number.isFinite(s) ||
    d < 0 ||
    d > limit ||
    m < 0 ||
    m >= 60 ||
    s < 0 ||
    s >= 60 ||
    (d === limit && (m > 0 || s > 0))
  ) {
    fail(
      "STEP 1",
      `${kind === "latitude" ? "Latitude" : "Longitude"} DMS must be valid: 0–${limit}°, 0–59′, 0–59.999″.`,
    );
  }
  const decimal = d + m / 60 + s / 3600;
  return direction === "S" || direction === "W" ? -decimal : decimal;
}

function parseManualOffset(value: string | undefined): number {
  const match = (value ?? "").trim().match(/^([+-])(\d{1,2}):(\d{2})$/);
  if (!match) fail("STEP 1", "Timezone Offset must use ±HH:MM format, for example +05:30.");
  const hours = Number(match[2]);
  const minutes = Number(match[3]);
  if (hours > 14 || minutes > 59) fail("STEP 1", "Timezone Offset is outside the valid range.");
  return (match[1] === "-" ? -1 : 1) * (hours * 60 + minutes);
}

function manualGeo(input: BirthInput): { geo: GeoResult; offsetMinutes: number } {
  if (!input.customPlaceName?.trim()) fail("STEP 1", "Custom Place Name is required.");
  const dms = input.manualCoordinateFormat === "DMS";
  const lat = dms
    ? parseDmsCoordinate(
        input.latitudeDegrees,
        input.latitudeMinutes,
        input.latitudeSeconds,
        input.latitudeDirection ?? "N",
        "latitude",
      )
    : parseCoordinate(input.latitude, input.latitudeDirection ?? "N", "latitude");
  const lon = dms
    ? parseDmsCoordinate(
        input.longitudeDegrees,
        input.longitudeMinutes,
        input.longitudeSeconds,
        input.longitudeDirection ?? "E",
        "longitude",
      )
    : parseCoordinate(input.longitude, input.longitudeDirection ?? "E", "longitude");
  const offsetMinutes = parseManualOffset(input.timezoneOffset);
  const offsetLabel = formatOffset(offsetMinutes).replace("GMT", "UTC");
  return {
    geo: {
      displayName: input.customPlaceName.trim(),
      category: "Manual Coordinates",
      lat,
      lon,
      roundedLat: Math.round(lat * 60) / 60,
      roundedLon: Math.round(lon * 60) / 60,
      timezone: offsetLabel,
    },
    offsetMinutes,
  };
}

function onlineGeo(input: BirthInput): GeoResult {
  const lat = input.onlineLatitude;
  const lon = input.onlineLongitude;
  if (!input.onlinePlaceName?.trim() || lat == null || lon == null) {
    fail("STEP 1", "Search online and select one location result before calculating.");
  }
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    fail("STEP 1", "The selected online location has invalid coordinates.");
  }
  return {
    displayName: input.onlinePlaceName.trim(),
    category: "Online Geocoder",
    lat,
    lon,
    roundedLat: Math.round(lat * 60) / 60,
    roundedLon: Math.round(lon * 60) / 60,
    timezone: tzLookup(lat, lon),
  };
}

/** Offset of an IANA zone for a given instant, minutes east of UTC. */
export function getTimezoneOffsetMinutes(timeZone: string, instant: Date): number {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(instant);

  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
  const asUtc = Date.UTC(
    get("year"),
    get("month") - 1,
    get("day"),
    get("hour") % 24,
    get("minute"),
    get("second"),
  );
  return Math.round((asUtc - instant.getTime()) / 60000);
}

function localToUtc(parsed: ParsedDateTime, timeZone: string) {
  const wallAsUtc = Date.UTC(
    parsed.year,
    parsed.month - 1,
    parsed.day,
    parsed.hour,
    parsed.minute,
    parsed.second,
  );
  let offset = getTimezoneOffsetMinutes(timeZone, new Date(wallAsUtc));
  let utc = new Date(wallAsUtc - offset * 60000);
  offset = getTimezoneOffsetMinutes(timeZone, utc);
  utc = new Date(wallAsUtc - offset * 60000);
  return { utc, offsetMinutes: offset };
}

function localToUtcWithOffset(parsed: ParsedDateTime, offsetMinutes: number) {
  const wallAsUtc = Date.UTC(
    parsed.year,
    parsed.month - 1,
    parsed.day,
    parsed.hour,
    parsed.minute,
    parsed.second,
  );
  return { utc: new Date(wallAsUtc - offsetMinutes * 60000), offsetMinutes };
}

/**
 * Local Mean Time correction: LMT = Standard Time + 4m × (λ − Standard Meridian)
 * East of the standard meridian adds time, west subtracts.
 */
export function localMeanTimeMinutes(parsed: ParsedDateTime, lonDeg: number, offsetMinutes: number) {
  const standardMeridian = offsetMinutes / 4;
  const correction = 4 * (lonDeg - standardMeridian); // minutes
  const totalSeconds =
    parsed.hour * 3600 + parsed.minute * 60 + parsed.second + Math.round(correction * 60);
  const norm = ((totalSeconds % 86400) + 86400) % 86400;
  const h = Math.floor(norm / 3600);
  const m = Math.floor((norm % 3600) / 60);
  const s = norm % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return { correctionMinutes: correction, lmt: `${pad(h)}:${pad(m)}:${pad(s)}` };
}

/* ------------------------------------------------------------------ */
/* TIME / ANGLE HELPERS                                                */
/* ------------------------------------------------------------------ */

function normalize(deg: number): number {
  return ((deg % 360) + 360) % 360;
}

export function julianDay(date: Date): number {
  return date.getTime() / 86400000 + 2440587.5;
}

/**
 * Lahiri (Chitrapaksha) ayanamsha.
 * Anchored at J2000.0 = 23°51'11.5" and advanced by mean precession 50.290966"/yr.
 * Classical view: 23°00'00" base + Table VII precession correction.
 */
export function lahiriAyanamsha(date: Date): number {
  const yearsFromJ2000 = (julianDay(date) - 2451545.0) / 365.25;
  return 23.8531944 + yearsFromJ2000 * (50.290966 / 3600);
}

export function dmsFromDecimal(value: number): string {
  const sign = value < 0 ? "-" : "";
  const abs = Math.abs(value);
  const d = Math.floor(abs);
  const mFloat = (abs - d) * 60;
  let m = Math.floor(mFloat);
  let s = Math.round((mFloat - m) * 60);
  if (s === 60) {
    s = 0;
    m += 1;
  }
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${sign}${d}° ${pad(m)}' ${pad(s)}"`;
}

export function hmsFromHours(hours: number): string {
  const norm = ((hours % 24) + 24) % 24;
  const totalSeconds = Math.round(norm * 3600);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

/* ------------------------------------------------------------------ */
/* STEP 2 — SIDEREAL TIME / RAMC                                       */
/* ------------------------------------------------------------------ */

/**
 * Greenwich Apparent Sidereal Time (hours) at a UTC instant — this is the
 * rigorous equivalent of Lahiri Table I + Table II + Table IV corrections.
 */
function greenwichSiderealTime(date: Date): number {
  return SiderealTime(MakeTime(date)); // hours
}

/**
 * Local Sidereal Time in hours = GAST + λ/15 (East positive).
 * Lahiri Table III correction (0.66 s per degree from 82°30'E) is the
 * pre-computed form of this same longitudinal term.
 */
function localSiderealTime(date: Date, lonDeg: number): number {
  const gast = greenwichSiderealTime(date);
  return ((gast + lonDeg / 15) % 24 + 24) % 24;
}

/* ------------------------------------------------------------------ */
/* STEP 3 — NIRAYANA ASCENDANT & MC                                    */
/* ------------------------------------------------------------------ */

function tropicalAscendantAndMC(date: Date, lat: number, lonDeg: number) {
  const lstHours = localSiderealTime(date, lonDeg);
  const ramc = normalize(lstHours * 15); // Right Ascension of MC, degrees

  const obliquity = e_tilt(MakeTime(date)).tobl; // true obliquity of date
  const eps = obliquity * DEG2RAD;
  const theta = ramc * DEG2RAD;
  const phi = lat * DEG2RAD;

  // Sayana MC: tan(MC) = tan(RAMC) / cos(ε)
  const mc = normalize(Math.atan2(Math.sin(theta), Math.cos(theta) * Math.cos(eps)) * RAD2DEG);

  // Sayana Ascendant: tan(Asc) = cos(RAMC) / −(sin(RAMC)·cos(ε) + tan(φ)·sin(ε))
  const ascendant = Math.atan2(
    Math.cos(theta),
    -(Math.sin(theta) * Math.cos(eps) + Math.tan(phi) * Math.sin(eps)),
  );

  return {
    ramc,
    lstHours,
    obliquity,
    mcTropical: mc,
    ascTropical: normalize(ascendant * RAD2DEG),
  };
}

/* ------------------------------------------------------------------ */
/* STEP 4 — PLANETARY LONGITUDES                                       */
/* ------------------------------------------------------------------ */

function longitudeToPosition(nirayana: number, motion: "D" | "R"): Position {
  const lon = normalize(nirayana);
  const sign = Math.floor(lon / 30) + 1;
  const within = lon - (sign - 1) * 30;
  const totalSeconds = Math.round(within * 3600);
  const deg = Math.min(29, Math.floor(totalSeconds / 3600));
  const rem = totalSeconds - deg * 3600;
  const min = Math.floor(rem / 60);
  const sec = rem % 60;
  return { sign, deg, min, sec, motion };
}

/**
 * Generate a Lahiri Nirayana D1 chart for any exact instant and observer.
 * Used by Dasha Pravesh charts; the observer must always be the native's
 * original birth latitude/longitude, never current or transit location.
 */
export function calculateChartAtInstant(instant: Date, latitude: number, longitude: number): Chart {
  const ayan = lahiriAyanamsha(instant);
  const { ascTropical } = tropicalAscendantAndMC(instant, latitude, longitude);
  const chart = {} as Chart;
  chart.Lagna = longitudeToPosition(ascTropical - ayan, "D");
  chart.Surya = longitudeToPosition(sunLongitude(instant) - ayan, "D");
  chart.Chandra = longitudeToPosition(moonLongitude(instant) - ayan, "D");
  for (const [planet, body] of Object.entries(BODY_MAP) as [PlanetKey, Body][]) {
    chart[planet] = longitudeToPosition(
      planetLongitude(body, instant) - ayan,
      motionStatus(body, instant),
    );
  }
  const rahu = meanRahuLongitude(instant);
  chart.Rahu = longitudeToPosition(rahu - ayan, "R");
  chart.Ketu = longitudeToPosition(rahu + 180 - ayan, "R");
  return chart;
}

function sunLongitude(date: Date): number {
  return normalize(SunPosition(date).elon);
}

function moonLongitude(date: Date): number {
  return normalize(EclipticGeoMoon(date).lon);
}

/** Apparent geocentric true-ecliptic-of-date longitude of a planet. */
function planetLongitude(body: Body, date: Date): number {
  const eqj: Vector = GeoVector(body, date, true);
  return normalize(Ecliptic(eqj).elon);
}

function motionStatus(body: Body, date: Date): "D" | "R" {
  const sample = (h: number) => planetLongitude(body, new Date(date.getTime() + h * 3600000));
  const delta = ((sample(12) - sample(-12) + 540) % 360) - 180;
  return delta < 0 ? "R" : "D";
}

/** Mean ascending lunar node (Rahu), tropical — Meeus polynomial. */
export function meanRahuLongitude(date: Date): number {
  const t = (julianDay(date) - 2451545.0) / 36525;
  return normalize(
    125.04455501 -
      1934.1361849 * t +
      0.0020762 * t * t +
      (t * t * t) / 467410 -
      (t * t * t * t) / 60616000,
  );
}

/* ------------------------------------------------------------------ */
/* OUTPUT TYPES                                                        */
/* ------------------------------------------------------------------ */

export type KarakaTag = "AK" | "AmK" | "BK" | "MK" | "PK" | "GK" | "DK";

export type PlanetRow = {
  planet: string;
  sign: string;
  signNumber: number;
  degree: string;
  charkarak: KarakaTag | null;
  lordship: string | null;
  motion: "Direct" | "Retrograde";
};

export type HousePayload = {
  sign: number;
  signName: string;
  lagna_degree?: string;
  planets: string[];
  arudhas: string[];
};

export type BirthCalculation = {
  input: BirthInput;
  geo: GeoResult;
  localDateTime: string;
  utcDate: Date;
  timezoneOffsetMinutes: number;
  timezoneOffsetLabel: string;
  lmt: string;
  lmtCorrectionMinutes: number;
  siderealTime: string;
  ramc: number;
  mcNirayana: Position;
  mcTropical: number;
  obliquity: number;
  julianDay: number;
  lahiriAyanamsha: number;
  chart: Chart;
  planetRows: PlanetRow[];
  houses: Record<string, HousePayload>;
  kundaliPayload: Record<string, unknown>;
  notes: string[];
};

/* ------------------------------------------------------------------ */
/* MAIN ENGINE                                                         */
/* ------------------------------------------------------------------ */

export async function calculateBirthChart(input: BirthInput): Promise<BirthCalculation> {
  if (!input.fullName.trim()) fail("STEP 0", "Full Name is required.");

  const parsed = parseBirthDateTime(input.date, input.time);
  const manual = input.locationMode === "manual" ? manualGeo(input) : null;
  const geo =
    manual?.geo ??
    (input.locationMode === "online"
      ? onlineGeo(input)
      : geoFromPlace(input.placeId ?? input.placeLabel ?? ""));

  // STEP 1 — IANA historical zone/DST or explicit fixed manual offset.
  const { utc, offsetMinutes } = manual
    ? localToUtcWithOffset(parsed, manual.offsetMinutes)
    : localToUtc(parsed, geo.timezone);
  const lmtInfo = localMeanTimeMinutes(parsed, geo.lon, offsetMinutes);

  // STEP 2/3 — sidereal time, RAMC, Ascendant, MC
  const { ramc, lstHours, obliquity, mcTropical, ascTropical } = tropicalAscendantAndMC(
    utc,
    geo.lat,
    geo.lon,
  );

  const ayan = lahiriAyanamsha(utc);

  const chart = {} as Chart;
  chart.Lagna = longitudeToPosition(ascTropical - ayan, "D");
  const mcNirayana = longitudeToPosition(mcTropical - ayan, "D");

  chart.Surya = longitudeToPosition(sunLongitude(utc) - ayan, "D");
  chart.Chandra = longitudeToPosition(moonLongitude(utc) - ayan, "D");

  for (const [planet, body] of Object.entries(BODY_MAP) as [PlanetKey, Body][]) {
    chart[planet] = longitudeToPosition(planetLongitude(body, utc) - ayan, motionStatus(body, utc));
  }

  const rahuTropical = meanRahuLongitude(utc);
  chart.Rahu = longitudeToPosition(rahuTropical - ayan, "R");
  chart.Ketu = longitudeToPosition(rahuTropical + 180 - ayan, "R");

  // STEP 5 — Jaimini Char Karakas (7 grahas only) and Arudhas
  const karakas = computeJaiminiCharKaraka(chart);
  const karakaByPlanet = new Map(karakas.map((k) => [k.key, k.karaka.role as KarakaTag]));
  const arudhas = computeArudhaPadas(chart);

  // STEP 6 — planetary table
  const planetRows: PlanetRow[] = (Object.keys(chart) as PlanetKey[]).map((key) => {
    const pos = chart[key];
    const isNode = key === "Rahu" || key === "Ketu";
    return {
      planet: key,
      signNumber: pos.sign,
      sign: `${pos.sign}`,
      degree: `${pos.deg}° ${String(pos.min).padStart(2, "0")}' ${String(pos.sec).padStart(2, "0")}"`,
      charkarak: isNode ? null : karakaByPlanet.get(key) ?? null,
      lordship: isNode ? null : null,
      motion: pos.motion === "R" ? "Retrograde" : "Direct",
    };
  });

  // STEP 6 — houses payload
  const lagnaSign = chart.Lagna.sign;
  const houses: Record<string, HousePayload> = {};
  for (let h = 1; h <= 12; h++) {
    const sign = ((lagnaSign - 1 + (h - 1)) % 12) + 1;
    houses[String(h)] = {
      sign,
      signName: "",
      ...(h === 1 ? { lagna_degree: `${chart.Lagna.deg}° ${String(chart.Lagna.min).padStart(2, "0")}' ${String(chart.Lagna.sec).padStart(2, "0")}"` } : {}),
      planets: [],
      arudhas: [],
    };
  }

  (Object.keys(chart) as PlanetKey[]).forEach((key) => {
    if (key === "Lagna") return;
    const house = ((chart[key].sign - lagnaSign + 12) % 12) + 1;
    houses[String(house)].planets.push(key);
  });

  arudhas.forEach((a) => {
    houses[String(a.arudhaHouse)].arudhas.push(a.label);
  });

  const kundaliPayload = {
    native_info: {
      name: input.fullName,
      dob: input.date,
      tob: input.time,
      pob: geo.displayName,
      lat: geo.roundedLat,
      lon: geo.roundedLon,
      tz: `${geo.timezone} (${formatOffset(offsetMinutes)})`,
    },
    astronomical_elements: {
      lmt: lmtInfo.lmt,
      sidereal_time: hmsFromHours(lstHours),
      ayanamsha: `Lahiri (Chitrapaksha) ${dmsFromDecimal(ayan)}`,
    },
    kundali_houses: houses,
    planetary_table: planetRows,
  };

  return {
    input,
    geo,
    localDateTime: `${input.date} ${input.time}`,
    utcDate: utc,
    timezoneOffsetMinutes: offsetMinutes,
    timezoneOffsetLabel: formatOffset(offsetMinutes),
    lmt: lmtInfo.lmt,
    lmtCorrectionMinutes: lmtInfo.correctionMinutes,
    siderealTime: hmsFromHours(lstHours),
    ramc,
    mcNirayana,
    mcTropical,
    obliquity,
    julianDay: julianDay(utc),
    lahiriAyanamsha: ayan,
    chart,
    planetRows,
    houses,
    kundaliPayload,
    notes: [
      "STEP 1: LMT = Standard Time + 4m × (λ − standard meridian); IST default meridian 82°30'E.",
      "STEP 2: Sidereal Time = GAST + λ/15 (rigorous form of Lahiri Tables I–IV).",
      "STEP 3: Asc = atan2(cos RAMC, −(sin RAMC·cos ε + tan φ·sin ε)); ε from true obliquity of date.",
      "STEP 4: Geocentric apparent longitudes in true ecliptic of date, minus Lahiri ayanamsha.",
      "STEP 4: Rahu/Ketu = Mean nodes only; Ketu = Rahu + 180°; lordship strictly NULL.",
      "STEP 5: Char Karaka from Navamsha traversed (7 grahas); Arudhas AL–A12 with Kendra exceptions.",
    ],
  };
}

function formatOffset(minutes: number): string {
  const sign = minutes >= 0 ? "+" : "-";
  const abs = Math.abs(minutes);
  return `GMT${sign}${String(Math.floor(abs / 60)).padStart(2, "0")}:${String(abs % 60).padStart(2, "0")}`;
}
