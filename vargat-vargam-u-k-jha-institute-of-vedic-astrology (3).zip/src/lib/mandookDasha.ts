import { degWithinSign, rashiName, type Chart } from "./astro";

export type MandookModality = "Moveable" | "Fixed" | "Common";
export type MandookPolarity = "Odd" | "Even";

export const ODD_SIGNS = [1, 3, 5, 7, 9, 11] as const;
export const EVEN_SIGNS = [2, 4, 6, 8, 10, 12] as const;
export const MOVEABLE_SIGNS = [1, 4, 7, 10] as const;
export const FIXED_SIGNS = [2, 5, 8, 11] as const;
export const COMMON_SIGNS = [3, 6, 9, 12] as const;

/** Even Lagna uses its Adarsha; odd Lagna starts from itself. */
export const ADARSHA_SIGNS: Record<number, number> = {
  1: 8,
  2: 7,
  3: 6,
  4: 11,
  5: 10,
  6: 3,
  7: 2,
  8: 1,
  9: 12,
  10: 5,
  11: 4,
  12: 9,
};

/** Exact Maha-Dasha sequences supplied for each natal Lagna. */
export const MANDOOK_MAHA_SEQUENCES: Record<number, number[]> = {
  1: [1, 3, 5, 7, 9, 11, 10, 8, 6, 4, 2, 12],
  2: [7, 5, 3, 1, 11, 9, 8, 10, 12, 2, 4, 6],
  3: [3, 5, 7, 9, 11, 1, 12, 10, 8, 6, 4, 2],
  4: [11, 9, 7, 5, 3, 1, 12, 2, 4, 6, 8, 10],
  5: [5, 7, 9, 11, 1, 3, 2, 12, 10, 8, 6, 4],
  6: [3, 1, 11, 9, 7, 5, 4, 6, 8, 10, 12, 2],
  7: [7, 9, 11, 1, 3, 5, 4, 2, 12, 10, 8, 6],
  8: [1, 11, 9, 7, 5, 3, 2, 4, 6, 8, 10, 12],
  9: [9, 11, 1, 3, 5, 7, 6, 4, 2, 12, 10, 8],
  10: [5, 3, 1, 11, 9, 7, 6, 8, 10, 12, 2, 4],
  11: [11, 1, 3, 5, 7, 9, 8, 6, 4, 2, 12, 10],
  12: [9, 7, 5, 3, 1, 11, 10, 12, 2, 4, 6, 8],
};

/** Exact Bhukti rows for an odd natal Lagna, keyed by operating Maha sign. */
export const ODD_LAGNA_BHUKTI: Record<number, number[]> = {
  1: [1, 3, 5, 7, 9, 11, 10, 8, 6, 4, 2, 12],
  2: [2, 12, 10, 8, 6, 4, 3, 5, 7, 9, 11, 1],
  3: [3, 5, 7, 9, 11, 1, 12, 10, 8, 6, 4, 2],
  4: [4, 2, 12, 10, 8, 6, 5, 7, 9, 11, 1, 3],
  5: [5, 7, 9, 11, 1, 3, 2, 12, 10, 8, 6, 4],
  6: [6, 4, 2, 12, 10, 8, 7, 9, 11, 1, 3, 5],
  7: [7, 9, 11, 1, 3, 5, 4, 2, 12, 10, 8, 6],
  8: [8, 6, 4, 2, 12, 10, 9, 11, 1, 3, 5, 7],
  9: [9, 11, 1, 3, 5, 7, 6, 4, 2, 12, 10, 8],
  10: [10, 8, 6, 4, 2, 12, 11, 1, 3, 5, 7, 9],
  11: [11, 1, 3, 5, 7, 9, 8, 6, 4, 2, 12, 10],
  12: [12, 10, 8, 6, 4, 2, 1, 3, 5, 7, 9, 11],
};

/** Exact Bhukti rows for an even natal Lagna, keyed by operating Maha sign. */
export const EVEN_LAGNA_BHUKTI: Record<number, number[]> = {
  1: [1, 11, 9, 7, 5, 3, 2, 4, 6, 8, 10, 12],
  2: [2, 4, 6, 8, 10, 12, 11, 9, 7, 5, 3, 1],
  3: [3, 1, 11, 9, 7, 5, 4, 6, 8, 10, 12, 2],
  4: [4, 6, 8, 10, 12, 2, 1, 11, 9, 7, 5, 3],
  5: [5, 3, 1, 11, 9, 7, 6, 8, 10, 12, 2, 4],
  6: [6, 8, 10, 12, 2, 4, 3, 1, 11, 9, 7, 5],
  7: [7, 5, 3, 1, 11, 9, 8, 10, 12, 2, 4, 6],
  8: [8, 10, 12, 2, 4, 6, 5, 3, 1, 11, 9, 7],
  9: [9, 7, 5, 3, 1, 11, 10, 12, 2, 4, 6, 8],
  10: [10, 12, 2, 4, 6, 8, 7, 5, 3, 1, 11, 9],
  11: [11, 9, 7, 5, 3, 1, 12, 2, 4, 6, 8, 10],
  12: [12, 2, 4, 6, 8, 10, 9, 7, 5, 3, 1, 11],
};

export type MandookDuration = {
  totalDays: number;
  label: string;
};

export type MandookBhukti = {
  order: number;
  sign: number;
  start: Date;
  end: Date;
  duration: MandookDuration;
  junctionAfter: boolean;
};

export type MandookMaha = {
  order: number;
  sign: number;
  start: Date;
  end: Date;
  duration: MandookDuration;
  bhuktis: MandookBhukti[];
  junctionAfter: boolean;
  partialAtBirth: boolean;
};

export type MandookResult = {
  lagnaSign: number;
  polarity: MandookPolarity;
  startingSign: number;
  modality: MandookModality;
  yearsPerSign: number;
  totalCycleYears: number;
  lagnaAbsoluteLongitude: number;
  consumed: MandookDuration;
  balance: MandookDuration;
  sequence: number[];
  mahadashas: MandookMaha[];
  activeMaha?: MandookMaha;
  activeBhukti?: MandookBhukti;
};

const YEAR_DAYS = 365.25;
const MONTH_DAYS = 30.4375;
const DAY_MS = 86400000;

function durationFromDays(totalDays: number): MandookDuration {
  let seconds = Math.round(totalDays * 86400);
  const years = Math.floor(seconds / Math.round(YEAR_DAYS * 86400));
  seconds -= years * Math.round(YEAR_DAYS * 86400);
  const months = Math.floor(seconds / Math.round(MONTH_DAYS * 86400));
  seconds -= months * Math.round(MONTH_DAYS * 86400);
  const days = Math.floor(seconds / 86400);
  return { totalDays, label: `${years} वर्ष ${months} माह ${days} दिन` };
}

function modality(sign: number): MandookModality {
  if (MOVEABLE_SIGNS.includes(sign as never)) return "Moveable";
  if (FIXED_SIGNS.includes(sign as never)) return "Fixed";
  return "Common";
}

function yearsForModality(value: MandookModality): number {
  return value === "Moveable" ? 7 : value === "Fixed" ? 8 : 9;
}

export function computeMandookDasha(chart: Chart, birth: Date, now = new Date()): MandookResult {
  const lagnaSign = chart.Lagna.sign;
  const polarity: MandookPolarity = ODD_SIGNS.includes(lagnaSign as never) ? "Odd" : "Even";
  const startingSign = polarity === "Odd" ? lagnaSign : ADARSHA_SIGNS[lagnaSign];
  const startModality = modality(startingSign);
  const yearsPerSign = yearsForModality(startModality);
  const totalCycleYears = yearsPerSign * 12;
  const lagnaAbsoluteLongitude = (lagnaSign - 1) * 30 + degWithinSign(chart.Lagna);

  // Exact balance formula supplied by the user.
  const consumedYears = (lagnaAbsoluteLongitude / 360) * yearsPerSign;
  const balanceYears = yearsPerSign - consumedYears;
  const consumed = durationFromDays(consumedYears * YEAR_DAYS);
  const balance = durationFromDays(balanceYears * YEAR_DAYS);
  const sequence = MANDOOK_MAHA_SEQUENCES[lagnaSign];
  const bhuktiTable = polarity === "Odd" ? ODD_LAGNA_BHUKTI : EVEN_LAGNA_BHUKTI;

  let cursor = birth.getTime();
  const fullMahaDays = yearsPerSign * YEAR_DAYS;
  const bhuktiDays = fullMahaDays / 12;
  const mahadashas = sequence.map((sign, index): MandookMaha => {
    const periodDays = index === 0 ? balance.totalDays : fullMahaDays;
    const start = new Date(cursor);
    const end = new Date(cursor + periodDays * DAY_MS);

    // Full theoretical Maha start is before birth for the first partial period.
    // Bhukti boundaries are calculated across the full parent span, then only
    // overlapping intervals are retained for the first operating balance.
    const theoreticalStart = index === 0
      ? birth.getTime() - consumed.totalDays * DAY_MS
      : start.getTime();
    const bhuktis = bhuktiTable[sign]
      .map((bhuktiSign, bhuktiIndex): MandookBhukti => {
        const bhuktiStart = new Date(theoreticalStart + bhuktiIndex * bhuktiDays * DAY_MS);
        const bhuktiEnd = new Date(theoreticalStart + (bhuktiIndex + 1) * bhuktiDays * DAY_MS);
        return {
          order: bhuktiIndex + 1,
          sign: bhuktiSign,
          start: bhuktiStart,
          end: bhuktiEnd,
          duration: durationFromDays(bhuktiDays),
          junctionAfter: bhuktiIndex === 5,
        };
      });

    cursor = end.getTime();
    return {
      order: index + 1,
      sign,
      start,
      end,
      duration: durationFromDays(periodDays),
      bhuktis,
      junctionAfter: index === 5,
      partialAtBirth: index === 0,
    };
  });

  const activeMaha = mahadashas.find((period) => now >= period.start && now < period.end);
  const activeBhukti = activeMaha?.bhuktis.find((period) => now >= period.start && now < period.end);

  return {
    lagnaSign,
    polarity,
    startingSign,
    modality: startModality,
    yearsPerSign,
    totalCycleYears,
    lagnaAbsoluteLongitude,
    consumed,
    balance,
    sequence,
    mahadashas,
    activeMaha,
    activeBhukti,
  };
}

export function formatMandookDate(date: Date, timeZone?: string): string {
  const zone = (timeZone ?? "").split(" (")[0];
  if (zone.includes("/")) {
    try {
      return new Intl.DateTimeFormat("en-GB", {
        timeZone: zone,
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hourCycle: "h23",
      }).format(date).replace(",", "");
    } catch {
      // UTC fallback below.
    }
  }
  return `${String(date.getUTCDate()).padStart(2, "0")}/${String(date.getUTCMonth() + 1).padStart(2, "0")}/${date.getUTCFullYear()} ${String(date.getUTCHours()).padStart(2, "0")}:${String(date.getUTCMinutes()).padStart(2, "0")}:${String(date.getUTCSeconds()).padStart(2, "0")} UTC`;
}

export function mandookSignLabel(sign: number): string {
  return `${sign}. ${rashiName(sign)}`;
}