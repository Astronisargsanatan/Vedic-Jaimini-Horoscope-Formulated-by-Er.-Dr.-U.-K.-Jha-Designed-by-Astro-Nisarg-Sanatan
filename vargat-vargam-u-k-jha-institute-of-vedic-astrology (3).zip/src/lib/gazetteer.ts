import { makeGeo, type GeoResult } from "./geo";

export type PlaceCategory =
  | "Gujarat District"
  | "Gujarat Taluka"
  | "India Metro"
  | "India City"
  | "India District"
  | "Foreign City";

export type Place = {
  id: string;
  name: string;
  district: string;
  state: string;
  country: string;
  lat: number;
  lon: number;
  timezone: string;
  category: PlaceCategory;
  keywords?: string;
};

export const INDIA_TZ = "Asia/Kolkata";

type Row = [name: string, district: string, state: string, lat: number, lon: number, category: PlaceCategory];

function slugify(name: string, district: string): string {
  return `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}__${district.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
}

function toPlace(row: Row, country: string, timezone: string): Place {
  const [name, district, state, lat, lon, category] = row;
  return {
    id: slugify(name, district),
    name,
    district,
    state,
    country,
    lat,
    lon,
    timezone,
    category,
    keywords: `${name} ${district} ${state} ${category}`.toLowerCase(),
  };
}

/* ------------------------------------------------------------------ */
/* GUJARAT — districts + talukas                                       */
/* ------------------------------------------------------------------ */

const GUJARAT_DISTRICTS: Row[] = [
  ["Ahmedabad", "Ahmedabad", "Gujarat", 23.0225, 72.5714, "India Metro"],
  ["Gandhinagar", "Gandhinagar", "Gujarat", 23.2156, 72.6369, "India City"],
  ["Surat", "Surat", "Gujarat", 21.1702, 72.8311, "India Metro"],
  ["Vadodara", "Vadodara", "Gujarat", 22.3072, 73.1812, "India City"],
  ["Rajkot", "Rajkot", "Gujarat", 22.3039, 70.8022, "India City"],
  ["Bhavnagar", "Bhavnagar", "Gujarat", 21.7645, 72.1519, "India City"],
  ["Jamnagar", "Jamnagar", "Gujarat", 22.4707, 70.0577, "India City"],
  ["Junagadh", "Junagadh", "Gujarat", 21.5222, 70.4579, "India City"],
  ["Kutch (Bhuj)", "Kutch", "Gujarat", 23.2419, 69.6669, "India District"],
  ["Patan", "Patan", "Gujarat", 23.8500, 72.1200, "India District"],
  ["Mehsana", "Mehsana", "Gujarat", 23.5879, 72.3693, "India District"],
  ["Banaskantha (Palanpur)", "Banaskantha", "Gujarat", 24.1724, 72.4387, "India District"],
  ["Sabarkantha (Himatnagar)", "Sabarkantha", "Gujarat", 23.5986, 72.9630, "India District"],
  ["Aravalli (Modasa)", "Aravalli", "Gujarat", 23.3050, 73.2950, "India District"],
  ["Mahisagar (Lunawada)", "Mahisagar", "Gujarat", 23.1280, 73.6100, "India District"],
  ["Panchmahal (Godhra)", "Panchmahal", "Gujarat", 22.7780, 73.6100, "India District"],
  ["Dahod", "Dahod", "Gujarat", 22.8370, 74.2540, "India District"],
  ["Chhota Udepur", "Chhota Udepur", "Gujarat", 22.2980, 73.7480, "India District"],
  ["Vadodara Rural", "Vadodara", "Gujarat", 22.1800, 73.2200, "India District"],
  ["Anand", "Anand", "Gujarat", 22.5645, 72.9289, "India District"],
  ["Kheda (Nadiad)", "Kheda", "Gujarat", 22.6916, 72.8634, "India District"],
  ["Mahesana Rural", "Mahesana", "Gujarat", 23.4320, 72.3750, "India District"],
  ["Morbi", "Morbi", "Gujarat", 22.8173, 70.8377, "India District"],
  ["Surendranagar", "Surendranagar", "Gujarat", 22.7280, 71.6480, "India District"],
  ["Rajkot Rural", "Rajkot", "Gujarat", 22.1000, 70.9000, "India District"],
  ["Amreli", "Amreli", "Gujarat", 21.6032, 71.2221, "India District"],
  ["Botad", "Botad", "Gujarat", 22.1700, 71.6670, "India District"],
  ["Gir Somnath (Veraval)", "Gir Somnath", "Gujarat", 20.9080, 70.3680, "India District"],
  ["Porbandar", "Porbandar", "Gujarat", 21.6417, 69.6293, "India District"],
  ["Devbhumi Dwarka (Khambhalia)", "Devbhumi Dwarka", "Gujarat", 22.7060, 69.6750, "India District"],
  ["Jamnagar Rural", "Jamnagar", "Gujarat", 22.2000, 69.9000, "India District"],
  ["Valsad", "Valsad", "Gujarat", 20.6078, 72.9331, "India District"],
  ["Navsari", "Navsari", "Gujarat", 20.9467, 72.9520, "India District"],
  ["Dang (Ahwa)", "Dang", "Gujarat", 20.7720, 73.6870, "India District"],
  ["Narmada (Rajpipla)", "Narmada", "Gujarat", 21.8720, 73.5030, "India District"],
  ["Bharuch", "Bharuch", "Gujarat", 21.7051, 72.9959, "India District"],
  ["Tapi (Vyara)", "Tapi", "Gujarat", 21.1130, 73.3960, "India District"],
  ["Surat Rural", "Surat", "Gujarat", 21.0000, 73.0000, "India District"],
];

const GUJARAT_TALUKAS: Row[] = [
  ["Dholka", "Ahmedabad", "Gujarat", 22.7833, 72.4333, "Gujarat Taluka"],
  ["Sanand", "Ahmedabad", "Gujarat", 22.9800, 72.3800, "Gujarat Taluka"],
  ["Daskroi", "Ahmedabad", "Gujarat", 23.0500, 72.6800, "Gujarat Taluka"],
  ["Viramgam", "Ahmedabad", "Gujarat", 23.1200, 72.0500, "Gujarat Taluka"],
  ["Bavla", "Ahmedabad", "Gujarat", 22.8700, 72.3700, "Gujarat Taluka"],
  ["Dhandhuka", "Ahmedabad", "Gujarat", 22.3833, 72.2500, "Gujarat Taluka"],
  ["Mandal", "Ahmedabad", "Gujarat", 23.2000, 71.9000, "Gujarat Taluka"],
  ["Barwala", "Ahmedabad", "Gujarat", 22.7167, 72.0000, "Gujarat Taluka"],
  ["Ranpur", "Ahmedabad", "Gujarat", 22.5000, 71.7500, "Gujarat Taluka"],
  ["Kalol (Gandhinagar)", "Gandhinagar", "Gujarat", 23.2500, 72.5000, "Gujarat Taluka"],
  ["Mansa", "Gandhinagar", "Gujarat", 23.4333, 72.6500, "Gujarat Taluka"],
  ["Dehgam", "Gandhinagar", "Gujarat", 23.1667, 72.8167, "Gujarat Taluka"],
  ["Chhota Udepur Taluka", "Chhota Udepur", "Gujarat", 22.3000, 73.7500, "Gujarat Taluka"],
  ["Mangrol", "Surat", "Gujarat", 21.1167, 72.6167, "Gujarat Taluka"],
  ["Choryasi", "Surat", "Gujarat", 21.1700, 72.8300, "Gujarat Taluka"],
  ["Olpad", "Surat", "Gujarat", 21.3500, 72.7500, "Gujarat Taluka"],
  ["Palsana", "Surat", "Gujarat", 21.1500, 73.0000, "Gujarat Taluka"],
  ["Bardoli", "Surat", "Gujarat", 21.1333, 73.1167, "Gujarat Taluka"],
  ["Mahuva (Surat)", "Surat", "Gujarat", 21.0833, 73.1500, "Gujarat Taluka"],
  ["Vyara", "Tapi", "Gujarat", 21.1130, 73.3960, "Gujarat Taluka"],
  ["Songadh", "Tapi", "Gujarat", 21.2333, 73.5667, "Gujarat Taluka"],
  ["Valsad Taluka", "Valsad", "Gujarat", 20.6100, 72.9300, "Gujarat Taluka"],
  ["Dharampur", "Valsad", "Gujarat", 20.5333, 73.1667, "Gujarat Taluka"],
  ["Pardi", "Valsad", "Gujarat", 20.5167, 72.9500, "Gujarat Taluka"],
  ["Kaprada", "Valsad", "Gujarat", 20.4833, 73.2000, "Gujarat Taluka"],
  ["Umargam", "Valsad", "Gujarat", 20.1667, 72.7667, "Gujarat Taluka"],
  ["Vapi", "Valsad", "Gujarat", 20.3893, 72.9106, "Gujarat Taluka"],
  ["Navsari Taluka", "Navsari", "Gujarat", 20.9500, 72.9300, "Gujarat Taluka"],
  ["Jalalpore", "Navsari", "Gujarat", 20.9000, 72.9300, "Gujarat Taluka"],
  ["Gandevi", "Navsari", "Gujarat", 20.8167, 72.9833, "Gujarat Taluka"],
  ["Chikhli (Navsari)", "Navsari", "Gujarat", 20.7333, 73.0833, "Gujarat Taluka"],
  ["Bansda", "Navsari", "Gujarat", 20.7333, 73.3500, "Gujarat Taluka"],
  ["Vadodara City", "Vadodara", "Gujarat", 22.3072, 73.1812, "Gujarat Taluka"],
  ["Savli", "Vadodara", "Gujarat", 22.4667, 73.2333, "Gujarat Taluka"],
  ["Waghodia", "Vadodara", "Gujarat", 22.3000, 73.4500, "Gujarat Taluka"],
  ["Dabhoi", "Vadodara", "Gujarat", 22.1333, 73.4333, "Gujarat Taluka"],
  ["Sankheda", "Vadodara", "Gujarat", 22.1667, 73.0833, "Gujarat Taluka"],
  ["Karjan", "Vadodara", "Gujarat", 22.0500, 73.1333, "Gujarat Taluka"],
  ["Padra", "Vadodara", "Gujarat", 22.2333, 73.0833, "Gujarat Taluka"],
  ["Shinor", "Vadodara", "Gujarat", 22.4833, 73.5333, "Gujarat Taluka"],
  ["Anand Taluka", "Anand", "Gujarat", 22.5645, 72.9289, "Gujarat Taluka"],
  ["Petlad", "Anand", "Gujarat", 22.4833, 72.8167, "Gujarat Taluka"],
  ["Khambhat", "Anand", "Gujarat", 22.3167, 72.6167, "Gujarat Taluka"],
  ["Anklav", "Anand", "Gujarat", 22.4000, 73.0167, "Gujarat Taluka"],
  ["Borsad", "Anand", "Gujarat", 22.4167, 72.9000, "Gujarat Taluka"],
  ["Tarapur", "Anand", "Gujarat", 22.4667, 72.6333, "Gujarat Taluka"],
  ["Nadiad", "Kheda", "Gujarat", 22.6916, 72.8634, "Gujarat Taluka"],
  ["Kheda", "Kheda", "Gujarat", 22.7500, 72.6833, "Gujarat Taluka"],
  ["Matar", "Kheda", "Gujarat", 22.8000, 72.7167, "Gujarat Taluka"],
  ["Mahemdabad", "Kheda", "Gujarat", 22.8167, 72.7667, "Gujarat Taluka"],
  ["Thasra", "Kheda", "Gujarat", 22.8000, 73.0500, "Gujarat Taluka"],
  ["Kapadvanj", "Kheda", "Gujarat", 23.0167, 73.0833, "Gujarat Taluka"],
  ["Balasinor", "Mahisagar", "Gujarat", 23.0333, 73.2000, "Gujarat Taluka"],
  ["Lunawada", "Mahisagar", "Gujarat", 23.1280, 73.6100, "Gujarat Taluka"],
  ["Godhra", "Panchmahal", "Gujarat", 22.7780, 73.6100, "Gujarat Taluka"],
  ["Halol", "Panchmahal", "Gujarat", 22.5000, 73.4667, "Gujarat Taluka"],
  ["Kalol (Panchmahal)", "Panchmahal", "Gujarat", 22.5667, 73.3667, "Gujarat Taluka"],
  ["Shehra", "Panchmahal", "Gujarat", 22.6500, 73.7000, "Gujarat Taluka"],
  ["Dahod Taluka", "Dahod", "Gujarat", 22.8370, 74.2540, "Gujarat Taluka"],
  ["Jhalod", "Dahod", "Gujarat", 23.1000, 74.1500, "Gujarat Taluka"],
  ["Limkheda", "Dahod", "Gujarat", 22.8500, 73.7500, "Gujarat Taluka"],
  ["Modasa", "Aravalli", "Gujarat", 23.3050, 73.2950, "Gujarat Taluka"],
  ["Bhiloda", "Aravalli", "Gujarat", 23.5500, 73.2333, "Gujarat Taluka"],
  ["Bayad", "Aravalli", "Gujarat", 23.3500, 73.1500, "Gujarat Taluka"],
  ["Dhansura", "Aravalli", "Gujarat", 23.4500, 73.3000, "Gujarat Taluka"],
  ["Himatnagar", "Sabarkantha", "Gujarat", 23.5986, 72.9630, "Gujarat Taluka"],
  ["Idar", "Sabarkantha", "Gujarat", 23.8333, 73.0000, "Gujarat Taluka"],
  ["Khedbrahma", "Sabarkantha", "Gujarat", 24.0333, 73.0333, "Gujarat Taluka"],
  ["Prantij", "Sabarkantha", "Gujarat", 23.4333, 72.8500, "Gujarat Taluka"],
  ["Mehsana Taluka", "Mahesana", "Gujarat", 23.5879, 72.3693, "Gujarat Taluka"],
  ["Unjha", "Mahesana", "Gujarat", 23.8000, 72.3833, "Gujarat Taluka"],
  ["Visnagar", "Mahesana", "Gujarat", 23.7000, 72.5500, "Gujarat Taluka"],
  ["Vadnagar", "Mahesana", "Gujarat", 23.7833, 72.6333, "Gujarat Taluka"],
  ["Vijapur", "Mahesana", "Gujarat", 23.5667, 72.6167, "Gujarat Taluka"],
  ["Kadi", "Mahesana", "Gujarat", 23.3000, 72.3333, "Gujarat Taluka"],
  ["Kheralu", "Mahesana", "Gujarat", 23.8833, 72.3333, "Gujarat Taluka"],
  ["Becharaji", "Mahesana", "Gujarat", 23.5000, 72.1333, "Gujarat Taluka"],
  ["Satlasana", "Mahesana", "Gujarat", 23.9667, 72.2000, "Gujarat Taluka"],
  ["Radhanpur", "Patan", "Gujarat", 23.8333, 71.6167, "Gujarat Taluka"],
  ["Patan Taluka", "Patan", "Gujarat", 23.8500, 72.1200, "Gujarat Taluka"],
  ["Sidhpur", "Patan", "Gujarat", 23.9167, 72.3667, "Gujarat Taluka"],
  ["Chanasma", "Patan", "Gujarat", 23.7167, 72.1667, "Gujarat Taluka"],
  ["Harij", "Patan", "Gujarat", 23.7000, 71.9000, "Gujarat Taluka"],
  ["Sami", "Patan", "Gujarat", 23.7000, 71.7500, "Gujarat Taluka"],
  ["Santalpur", "Patan", "Gujarat", 23.7500, 71.2167, "Gujarat Taluka"],
  ["Sarpatan", "Banaskantha", "Gujarat", 24.0500, 72.6167, "Gujarat Taluka"],
  ["Palanpur", "Banaskantha", "Gujarat", 24.1724, 72.4387, "Gujarat Taluka"],
  ["Deesa", "Banaskantha", "Gujarat", 24.2500, 72.1833, "Gujarat Taluka"],
  ["Dhanera", "Banaskantha", "Gujarat", 24.5000, 72.0000, "Gujarat Taluka"],
  ["Tharad", "Banaskantha", "Gujarat", 24.4000, 71.7000, "Gujarat Taluka"],
  ["Vav", "Banaskantha", "Gujarat", 24.1667, 71.1000, "Gujarat Taluka"],
  ["Vadgam", "Banaskantha", "Gujarat", 24.0833, 72.4833, "Gujarat Taluka"],
  ["Amirgadh", "Banaskantha", "Gujarat", 24.1667, 72.5167, "Gujarat Taluka"],
  ["Danta", "Banaskantha", "Gujarat", 24.2000, 72.7500, "Gujarat Taluka"],
  ["Kankrej", "Banaskantha", "Gujarat", 24.0667, 71.6833, "Gujarat Taluka"],
  ["Lakhani", "Banaskantha", "Gujarat", 24.1000, 71.9167, "Gujarat Taluka"],
  ["Bhuj", "Kutch", "Gujarat", 23.2419, 69.6669, "Gujarat Taluka"],
  ["Anjar", "Kutch", "Gujarat", 23.1133, 70.0198, "Gujarat Taluka"],
  ["Mandvi (Kutch)", "Kutch", "Gujarat", 22.8392, 69.3526, "Gujarat Taluka"],
  ["Mundra", "Kutch", "Gujarat", 22.8392, 69.6755, "Gujarat Taluka"],
  ["Abdasa (Naliya)", "Kutch", "Gujarat", 22.9440, 68.8300, "Gujarat Taluka"],
  ["Nakhatrana", "Kutch", "Gujarat", 23.3000, 68.9833, "Gujarat Taluka"],
  ["Gandhidham", "Kutch", "Gujarat", 23.0800, 70.1300, "Gujarat Taluka"],
  ["Rapar", "Kutch", "Gujarat", 23.5667, 70.6333, "Gujarat Taluka"],
  ["Bhachau", "Kutch", "Gujarat", 23.3000, 70.3500, "Gujarat Taluka"],
  ["Lakhpat", "Kutch", "Gujarat", 23.5833, 68.7833, "Gujarat Taluka"],
  ["Morbi Taluka", "Morbi", "Gujarat", 22.8173, 70.8377, "Gujarat Taluka"],
  ["Tankara", "Morbi", "Gujarat", 22.8333, 70.8000, "Gujarat Taluka"],
  ["Wankaner", "Morbi", "Gujarat", 22.6167, 70.9333, "Gujarat Taluka"],
  ["Halvad", "Morbi", "Gujarat", 22.9833, 71.1000, "Gujarat Taluka"],
  ["Maliya", "Morbi", "Gujarat", 22.9000, 70.7000, "Gujarat Taluka"],
  ["Rajkot Taluka", "Rajkot", "Gujarat", 22.3039, 70.8022, "Gujarat Taluka"],
  ["Gondal", "Rajkot", "Gujarat", 21.9333, 70.8000, "Gujarat Taluka"],
  ["Jetpur", "Rajkot", "Gujarat", 21.7500, 70.6167, "Gujarat Taluka"],
  ["Dhoraji", "Rajkot", "Gujarat", 21.7333, 70.4500, "Gujarat Taluka"],
  ["Upleta", "Rajkot", "Gujarat", 21.7333, 70.2833, "Gujarat Taluka"],
  ["Jamkandorna", "Rajkot", "Gujarat", 21.8333, 70.4667, "Gujarat Taluka"],
  ["Kotda Sangani", "Rajkot", "Gujarat", 21.9833, 70.6667, "Gujarat Taluka"],
  ["Lodhika", "Rajkot", "Gujarat", 22.2000, 70.6500, "Gujarat Taluka"],
  ["Paddhari", "Rajkot", "Gujarat", 22.4500, 70.6000, "Gujarat Taluka"],
  ["Jasdan", "Rajkot", "Gujarat", 22.5000, 71.2000, "Gujarat Taluka"],
  ["Surendranagar (Wadhwan)", "Surendranagar", "Gujarat", 22.7280, 71.6480, "Gujarat Taluka"],
  ["Dhrangadhra", "Surendranagar", "Gujarat", 22.9833, 71.5000, "Gujarat Taluka"],
  ["Halvad (Saurashtra)", "Surendranagar", "Gujarat", 22.9833, 71.1000, "Gujarat Taluka"],
  ["Sayla", "Surendranagar", "Gujarat", 22.5667, 71.8000, "Gujarat Taluka"],
  ["Chotila", "Surendranagar", "Gujarat", 22.4333, 71.7833, "Gujarat Taluka"],
  ["Limbdi", "Surendranagar", "Gujarat", 22.5667, 71.8000, "Gujarat Taluka"],
  ["Dasada", "Surendranagar", "Gujarat", 23.2500, 71.3500, "Gujarat Taluka"],
  ["Lakhtar", "Surendranagar", "Gujarat", 22.7500, 71.7500, "Gujarat Taluka"],
  ["Muli", "Surendranagar", "Gujarat", 22.5500, 71.5333, "Gujarat Taluka"],
  ["Botad Taluka", "Botad", "Gujarat", 22.1700, 71.6670, "Gujarat Taluka"],
  ["Gadhada", "Botad", "Gujarat", 22.0833, 71.5833, "Gujarat Taluka"],
  ["Barvala", "Botad", "Gujarat", 22.3833, 71.9500, "Gujarat Taluka"],
  ["Ranpur (Botad)", "Botad", "Gujarat", 22.5000, 71.7500, "Gujarat Taluka"],
  ["Bhavnagar Taluka", "Bhavnagar", "Gujarat", 21.7645, 72.1519, "Gujarat Taluka"],
  ["Bhavnagar Rural", "Bhavnagar", "Gujarat", 21.8000, 72.1000, "Gujarat Taluka"],
  ["Talaja", "Bhavnagar", "Gujarat", 21.3500, 72.0333, "Gujarat Taluka"],
  ["Mahuva (Bhavnagar)", "Bhavnagar", "Gujarat", 21.0833, 72.0000, "Gujarat Taluka"],
  ["Palitana", "Bhavnagar", "Gujarat", 21.5167, 71.8333, "Gujarat Taluka"],
  ["Gariadhar", "Bhavnagar", "Gujarat", 21.4833, 71.5833, "Gujarat Taluka"],
  ["Ghogha", "Bhavnagar", "Gujarat", 21.6833, 72.2667, "Gujarat Taluka"],
  ["Sihor", "Bhavnagar", "Gujarat", 21.7167, 71.9667, "Gujarat Taluka"],
  ["Vallabhipur", "Bhavnagar", "Gujarat", 22.0333, 71.8833, "Gujarat Taluka"],
  ["Umrala", "Bhavnagar", "Gujarat", 21.8333, 71.8000, "Gujarat Taluka"],
  ["Amreli Taluka", "Amreli", "Gujarat", 21.6032, 71.2221, "Gujarat Taluka"],
  ["Bagasara", "Amreli", "Gujarat", 21.4833, 70.9500, "Gujarat Taluka"],
  ["Dhari", "Amreli", "Gujarat", 21.3833, 71.0167, "Gujarat Taluka"],
  ["Lathi", "Amreli", "Gujarat", 21.7167, 71.2667, "Gujarat Taluka"],
  ["Lilia", "Amreli", "Gujarat", 21.5167, 71.2833, "Gujarat Taluka"],
  ["Rajula", "Amreli", "Gujarat", 21.0333, 71.4333, "Gujarat Taluka"],
  ["Jafrabad", "Amreli", "Gujarat", 20.9167, 71.3333, "Gujarat Taluka"],
  ["Kunkavav Vadia", "Amreli", "Gujarat", 21.4667, 70.9167, "Gujarat Taluka"],
  ["Khambha", "Amreli", "Gujarat", 21.3333, 70.8500, "Gujarat Taluka"],
  ["Jamnagar Taluka", "Jamnagar", "Gujarat", 22.4707, 70.0577, "Gujarat Taluka"],
  ["Dwarka", "Devbhumi Dwarka", "Gujarat", 22.2394, 68.9678, "Gujarat Taluka"],
  ["Khambhalia", "Devbhumi Dwarka", "Gujarat", 22.7060, 69.6750, "Gujarat Taluka"],
  ["Kalyanpur", "Devbhumi Dwarka", "Gujarat", 22.4833, 69.6500, "Gujarat Taluka"],
  ["Bhanvad", "Devbhumi Dwarka", "Gujarat", 22.0167, 69.6000, "Gujarat Taluka"],
  ["Kalavad", "Jamnagar", "Gujarat", 22.2333, 70.3500, "Gujarat Taluka"],
  ["Lalpur", "Jamnagar", "Gujarat", 22.1833, 69.9667, "Gujarat Taluka"],
  ["Dhrol", "Jamnagar", "Gujarat", 22.5667, 70.7667, "Gujarat Taluka"],
  ["Jodia", "Jamnagar", "Gujarat", 22.5667, 69.8833, "Gujarat Taluka"],
  ["Porbandar Taluka", "Porbandar", "Gujarat", 21.6417, 69.6293, "Gujarat Taluka"],
  ["Ranavav", "Porbandar", "Gujarat", 21.6833, 69.6167, "Gujarat Taluka"],
  ["Kutiyana", "Porbandar", "Gujarat", 21.5333, 69.6000, "Gujarat Taluka"],
  ["Junagadh Taluka", "Junagadh", "Gujarat", 21.5222, 70.4579, "Gujarat Taluka"],
  ["Keshod", "Junagadh", "Gujarat", 21.3000, 70.2333, "Gujarat Taluka"],
  ["Mangrol (Junagadh)", "Junagadh", "Gujarat", 21.1000, 70.3333, "Gujarat Taluka"],
  ["Mendarda", "Junagadh", "Gujarat", 21.4167, 70.4500, "Gujarat Taluka"],
  ["Vanthali", "Junagadh", "Gujarat", 21.4833, 70.3167, "Gujarat Taluka"],
  ["Manavadar", "Junagadh", "Gujarat", 21.5167, 70.1667, "Gujarat Taluka"],
  ["Veraval", "Gir Somnath", "Gujarat", 20.9080, 70.3680, "Gujarat Taluka"],
  ["Somnath", "Gir Somnath", "Gujarat", 20.8880, 70.4010, "Gujarat Taluka"],
  ["Kodinar", "Gir Somnath", "Gujarat", 20.7833, 70.7000, "Gujarat Taluka"],
  ["Una (Gir Somnath)", "Gir Somnath", "Gujarat", 20.8167, 71.0000, "Gujarat Taluka"],
  ["Talala", "Gir Somnath", "Gujarat", 21.0500, 70.5500, "Gujarat Taluka"],
  ["Sutrapada", "Gir Somnath", "Gujarat", 20.8333, 70.5000, "Gujarat Taluka"],
  ["Gir Gadhada", "Gir Somnath", "Gujarat", 21.2000, 70.9500, "Gujarat Taluka"],
  ["Narmada Rajpipla", "Narmada", "Gujarat", 21.8720, 73.5030, "Gujarat Taluka"],
  ["Dediapada", "Narmada", "Gujarat", 21.6500, 73.6000, "Gujarat Taluka"],
  ["Sagbara", "Narmada", "Gujarat", 21.6500, 73.4500, "Gujarat Taluka"],
  ["Tilakwada", "Narmada", "Gujarat", 22.0500, 73.5000, "Gujarat Taluka"],
  ["Bharuch Taluka", "Bharuch", "Gujarat", 21.7051, 72.9959, "Gujarat Taluka"],
  ["Ankleshwar", "Bharuch", "Gujarat", 21.6167, 73.0000, "Gujarat Taluka"],
  ["Hansot", "Bharuch", "Gujarat", 21.7333, 72.9167, "Gujarat Taluka"],
  ["Jambusar", "Bharuch", "Gujarat", 22.0500, 72.8000, "Gujarat Taluka"],
  ["Amod", "Bharuch", "Gujarat", 22.0333, 72.8667, "Gujarat Taluka"],
  ["Vagra", "Bharuch", "Gujarat", 21.9833, 72.9167, "Gujarat Taluka"],
  ["Netrang", "Bharuch", "Gujarat", 21.6833, 73.4333, "Gujarat Taluka"],
  ["Jhagadia", "Bharuch", "Gujarat", 21.7000, 73.1500, "Gujarat Taluka"],
  ["Valia", "Bharuch", "Gujarat", 21.7500, 73.3000, "Gujarat Taluka"],
  ["Dang Ahwa", "Dang", "Gujarat", 20.7720, 73.6870, "Gujarat Taluka"],
  ["Waghai", "Dang", "Gujarat", 20.8167, 73.5833, "Gujarat Taluka"],
  ["Subir", "Dang", "Gujarat", 20.8333, 73.7500, "Gujarat Taluka"],
];

/* ------------------------------------------------------------------ */
/* REST OF INDIA — metros, cities, district HQs                        */
/* ------------------------------------------------------------------ */

const OTHER_INDIA: Row[] = [
  ["Mumbai", "Mumbai", "Maharashtra", 19.0760, 72.8777, "India Metro"],
  ["Delhi", "Delhi", "Delhi", 28.6139, 77.2090, "India Metro"],
  ["Bengaluru", "Bengaluru Urban", "Karnataka", 12.9716, 77.5946, "India Metro"],
  ["Hyderabad", "Hyderabad", "Telangana", 17.3850, 78.4867, "India Metro"],
  ["Chennai", "Chennai", "Tamil Nadu", 13.0827, 80.2707, "India Metro"],
  ["Kolkata", "Kolkata", "West Bengal", 22.5726, 88.3639, "India Metro"],
  ["Pune", "Pune", "Maharashtra", 18.5204, 73.8567, "India City"],
  ["Nashik", "Nashik", "Maharashtra", 19.9975, 73.7898, "India City"],
  ["Nagpur", "Nagpur", "Maharashtra", 21.1458, 79.0882, "India City"],
  ["Aurangabad (Maharashtra)", "Aurangabad", "Maharashtra", 19.8762, 75.3433, "India District"],
  ["Thane", "Thane", "Maharashtra", 19.2183, 72.9781, "India City"],
  ["Navi Mumbai", "Thane", "Maharashtra", 19.0330, 73.0297, "India City"],
  ["Kolhapur", "Kolhapur", "Maharashtra", 16.7050, 74.2433, "India District"],
  ["Solapur", "Solapur", "Maharashtra", 17.6599, 75.9064, "India District"],
  ["Amravati", "Amravati", "Maharashtra", 20.9374, 77.7796, "India District"],
  ["Jabalpur", "Jabalpur", "Madhya Pradesh", 23.1815, 79.9864, "India District"],
  ["Gwalior", "Gwalior", "Madhya Pradesh", 26.2183, 78.1828, "India City"],
  ["Ujjain", "Ujjain", "Madhya Pradesh", 23.1793, 75.7849, "India District"],
  ["Jaipur", "Jaipur", "Rajasthan", 26.9124, 75.7873, "India Metro"],
  ["Jodhpur", "Jodhpur", "Rajasthan", 26.2389, 73.0243, "India City"],
  ["Udaipur", "Udaipur", "Rajasthan", 24.5854, 73.7125, "India City"],
  ["Kota", "Kota", "Rajasthan", 25.2138, 75.8648, "India District"],
  ["Ajmer", "Ajmer", "Rajasthan", 26.4499, 74.6399, "India District"],
  ["Bikaner", "Bikaner", "Rajasthan", 28.0229, 73.3119, "India District"],
  ["Lucknow", "Lucknow", "Uttar Pradesh", 26.8467, 80.9462, "India City"],
  ["Varanasi", "Varanasi", "Uttar Pradesh", 25.3176, 82.9739, "India District"],
  ["Agra", "Agra", "Uttar Pradesh", 27.1767, 78.0081, "India District"],
  ["Kanpur", "Kanpur Nagar", "Uttar Pradesh", 26.4499, 80.3319, "India District"],
  ["Prayagraj", "Prayagraj", "Uttar Pradesh", 25.4358, 81.8463, "India District"],
  ["Mathura", "Mathura", "Uttar Pradesh", 27.4924, 77.6737, "India District"],
  ["Ayodhya", "Ayodhya", "Uttar Pradesh", 26.7990, 82.2040, "India District"],
  ["Noida", "Gautam Buddha Nagar", "Uttar Pradesh", 28.5355, 77.3910, "India City"],
  ["Chandigarh", "Chandigarh", "Chandigarh", 30.7333, 76.7794, "India City"],
  ["Amritsar", "Amritsar", "Punjab", 31.6340, 74.8723, "India District"],
  ["Ludhiana", "Ludhiana", "Punjab", 30.9010, 75.8573, "India District"],
  ["Jalandhar", "Jalandhar", "Punjab", 31.3260, 75.5762, "India District"],
  ["Shimla", "Shimla", "Himachal Pradesh", 31.1048, 77.1734, "India District"],
  ["Haridwar", "Haridwar", "Uttarakhand", 29.9457, 78.1642, "India District"],
  ["Dehradun", "Dehradun", "Uttarakhand", 30.3165, 78.0322, "India City"],
  ["Patna", "Patna", "Bihar", 25.5941, 85.1376, "India City"],
  ["Gaya", "Gaya", "Bihar", 24.7914, 85.0002, "India District"],
  ["Bhagalpur", "Bhagalpur", "Bihar", 25.2425, 86.9842, "India District"],
  ["Ranchi", "Ranchi", "Jharkhand", 23.3441, 85.3096, "India City"],
  ["Jamshedpur", "East Singhbhum", "Jharkhand", 22.8046, 86.2029, "India City"],
  ["Bhopal", "Bhopal", "Madhya Pradesh", 23.2599, 77.4126, "India City"],
  ["Indore", "Indore", "Madhya Pradesh", 22.7196, 75.8577, "India City"],
  ["Raipur", "Raipur", "Chhattisgarh", 21.2514, 81.6296, "India City"],
  ["Bilaspur (Chhattisgarh)", "Bilaspur", "Chhattisgarh", 22.0797, 82.1409, "India District"],
  ["Bhubaneswar", "Khordha", "Odisha", 20.2961, 85.8245, "India City"],
  ["Cuttack", "Cuttack", "Odisha", 20.4625, 85.8828, "India District"],
  ["Puri", "Puri", "Odisha", 19.8135, 85.8312, "India District"],
  ["Guwahati", "Kamrup Metropolitan", "Assam", 26.1445, 91.7362, "India City"],
  ["Siliguri", "Darjeeling", "West Bengal", 26.7271, 88.3953, "India City"],
  ["Darjeeling", "Darjeeling", "West Bengal", 27.0410, 88.2663, "India District"],
  ["Panaji", "North Goa", "Goa", 15.4909, 73.8278, "India City"],
  ["Margao", "South Goa", "Goa", 15.2674, 73.9570, "India City"],
  ["Thiruvananthapuram", "Thiruvananthapuram", "Kerala", 8.5241, 76.9366, "India City"],
  ["Kochi", "Ernakulam", "Kerala", 9.9312, 76.2673, "India City"],
  ["Kozhikode", "Kozhikode", "Kerala", 11.2588, 75.7804, "India District"],
  ["Guruvayur", "Thrissur", "Kerala", 10.5945, 76.0390, "India City"],
  ["Coimbatore", "Coimbatore", "Tamil Nadu", 11.0168, 76.9558, "India City"],
  ["Madurai", "Madurai", "Tamil Nadu", 9.9252, 78.1198, "India District"],
  ["Tiruchirappalli", "Tiruchirappalli", "Tamil Nadu", 10.7905, 78.7047, "India District"],
  ["Rameswaram", "Ramanathapuram", "Tamil Nadu", 9.2876, 79.3129, "India City"],
  ["Kanyakumari", "Kanyakumari", "Tamil Nadu", 8.0883, 77.5385, "India District"],
  ["Vijayawada", "Krishna", "Andhra Pradesh", 16.5062, 80.6480, "India City"],
  ["Visakhapatnam", "Visakhapatnam", "Andhra Pradesh", 17.6868, 83.2185, "India City"],
  ["Tirupati", "Tirupati", "Andhra Pradesh", 13.6288, 79.4192, "India District"],
  ["Srinagar", "Srinagar", "Jammu and Kashmir", 34.0837, 74.7973, "India City"],
  ["Jammu", "Jammu", "Jammu and Kashmir", 32.7266, 74.8570, "India City"],
  ["Leh", "Leh", "Ladakh", 34.1526, 77.5771, "India District"],
  ["Port Blair", "South Andaman", "Andaman and Nicobar Islands", 11.6234, 92.7265, "India City"],
  ["Kavaratti", "Lakshadweep", "Lakshadweep", 10.5669, 72.6420, "India District"],
];

/* ------------------------------------------------------------------ */
/* FOREIGN — cities with local standard time zones                     */
/* ------------------------------------------------------------------ */

const FOREIGN: [name: string, country: string, lat: number, lon: number, tz: string][] = [
  ["Kathmandu", "Nepal", 27.7172, 85.3240, "Asia/Kathmandu"],
  ["Pokhara", "Nepal", 28.2096, 83.9856, "Asia/Kathmandu"],
  ["Colombo", "Sri Lanka", 6.9271, 79.8612, "Asia/Colombo"],
  ["Kandy", "Sri Lanka", 7.2906, 80.6337, "Asia/Colombo"],
  ["Thimphu", "Bhutan", 27.4728, 89.6390, "Asia/Thimphu"],
  ["Dhaka", "Bangladesh", 23.8103, 90.4125, "Asia/Dhaka"],
  ["Chittagong", "Bangladesh", 22.3569, 91.7832, "Asia/Dhaka"],
  ["Karachi", "Pakistan", 24.8607, 67.0011, "Asia/Karachi"],
  ["Lahore", "Pakistan", 31.5204, 74.3587, "Asia/Karachi"],
  ["Islamabad", "Pakistan", 33.6844, 73.0479, "Asia/Karachi"],
  ["Kabul", "Afghanistan", 34.5553, 69.2075, "Asia/Kabul"],
  ["Dubai", "United Arab Emirates", 25.2048, 55.2708, "Asia/Dubai"],
  ["Abu Dhabi", "United Arab Emirates", 24.4539, 54.3773, "Asia/Dubai"],
  ["Sharjah", "United Arab Emirates", 25.3463, 55.4209, "Asia/Dubai"],
  ["Doha", "Qatar", 25.2854, 51.5310, "Asia/Qatar"],
  ["Riyadh", "Saudi Arabia", 24.7136, 46.6753, "Asia/Riyadh"],
  ["Jeddah", "Saudi Arabia", 21.4858, 39.1925, "Asia/Riyadh"],
  ["Muscat", "Oman", 23.5880, 58.3829, "Asia/Muscat"],
  ["Manama", "Bahrain", 26.2285, 50.5860, "Asia/Bahrain"],
  ["Kuwait City", "Kuwait", 29.3759, 47.9774, "Asia/Kuwait"],
  ["Tehran", "Iran", 35.6892, 51.3890, "Asia/Tehran"],
  ["London", "United Kingdom", 51.5074, -0.1278, "Europe/London"],
  ["Manchester", "United Kingdom", 53.4808, -2.2426, "Europe/London"],
  ["Leicester", "United Kingdom", 52.6369, -1.1398, "Europe/London"],
  ["Birmingham", "United Kingdom", 52.4862, -1.8904, "Europe/London"],
  ["New York", "United States", 40.7128, -74.0060, "America/New_York"],
  ["Chicago", "United States", 41.8781, -87.6298, "America/Chicago"],
  ["Los Angeles", "United States", 34.0522, -118.2437, "America/Los_Angeles"],
  ["San Francisco", "United States", 37.7749, -122.4194, "America/Los_Angeles"],
  ["Houston", "United States", 29.7604, -95.3698, "America/Chicago"],
  ["Toronto", "Canada", 43.6532, -79.3832, "America/Toronto"],
  ["Vancouver", "Canada", 49.2827, -123.1207, "America/Vancouver"],
  ["Singapore", "Singapore", 1.3521, 103.8198, "Asia/Singapore"],
  ["Kuala Lumpur", "Malaysia", 3.1390, 101.6869, "Asia/Kuala_Lumpur"],
  ["Bangkok", "Thailand", 13.7563, 100.5018, "Asia/Bangkok"],
  ["Jakarta", "Indonesia", -6.2088, 106.8456, "Asia/Jakarta"],
  ["Tokyo", "Japan", 35.6762, 139.6503, "Asia/Tokyo"],
  ["Seoul", "South Korea", 37.5665, 126.9780, "Asia/Seoul"],
  ["Sydney", "Australia", -33.8688, 151.2093, "Australia/Sydney"],
  ["Melbourne", "Australia", -37.8136, 144.9631, "Australia/Melbourne"],
  ["Auckland", "New Zealand", -36.8485, 174.7633, "Pacific/Auckland"],
  ["Nairobi", "Kenya", -1.2921, 36.8219, "Africa/Nairobi"],
  ["Johannesburg", "South Africa", -26.2041, 28.0473, "Africa/Johannesburg"],
  ["Paris", "France", 48.8566, 2.3522, "Europe/Paris"],
  ["Frankfurt", "Germany", 50.1109, 8.6821, "Europe/Berlin"],
  ["Moscow", "Russia", 55.7558, 37.6173, "Europe/Moscow"],
  ["Moscow Region", "Russia", 55.7558, 37.6173, "Europe/Moscow"],
];

function buildPlaces(): Place[] {
  const list: Place[] = [];
  for (const row of GUJARAT_DISTRICTS) list.push(toPlace(row, "India", INDIA_TZ));
  for (const row of GUJARAT_TALUKAS) list.push(toPlace(row, "India", INDIA_TZ));
  for (const row of OTHER_INDIA) list.push(toPlace(row, "India", INDIA_TZ));
  for (const [name, country, lat, lon, tz] of FOREIGN) {
    const place = toPlace([name, name, country, lat, lon, "Foreign City"], country, tz);
    list.push(place);
  }
  return list;
}

export const PLACES: Place[] = buildPlaces();

/** Used when a gazetteer match is unavailable and coordinates are entered manually. */
export const INDIAN_PLACE_FALLBACK = PLACES.filter((p) => p.country === "India").map((p) => ({
  name: p.name,
  category: p.category,
  lat: p.lat,
  lon: p.lon,
}));

export function placeById(id: string): Place | undefined {
  return PLACES.find((p) => p.id === id);
}

export function searchPlaces(query: string, limit = 60): Place[] {
  const q = query.trim().toLowerCase();
  if (!q) {
    return PLACES.filter((p) => p.country === "India").slice(0, limit);
  }
  const scored = PLACES.map((p) => {
    const haystack = `${p.name} ${p.district} ${p.state} ${p.country} ${p.category}`.toLowerCase();
    const nameLower = p.name.toLowerCase();
    let score = 0;
    if (nameLower === q) score = 100;
    else if (nameLower.startsWith(q)) score = 80;
    else if (nameLower.includes(q)) score = 60;
    else if (haystack.includes(q)) score = 40;
    return { p, score };
  })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || a.p.name.localeCompare(b.p.name));

  return scored.slice(0, limit).map((x) => x.p);
}

export function placeLabel(place: Place): string {
  const region = place.state && place.state !== place.country ? place.state : place.district;
  return `${place.name} — ${region}, ${place.country} (${place.category})`;
}

export function lookupPlaceTimezone(placeId: string): GeoResult | undefined {
  const place = placeById(placeId);
  if (!place) return undefined;
  return makeGeo(placeLabel(place), place.category, place.lat, place.lon, place.timezone);
}
