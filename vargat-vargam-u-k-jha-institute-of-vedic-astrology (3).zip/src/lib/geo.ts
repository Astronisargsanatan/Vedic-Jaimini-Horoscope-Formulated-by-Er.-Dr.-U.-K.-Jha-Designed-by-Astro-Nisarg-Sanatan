export type GeoResult = {
  displayName: string;
  category: string;
  lat: number;
  lon: number;
  roundedLat: number;
  roundedLon: number;
  timezone: string;
};

export function makeGeo(
  displayName: string,
  category: string,
  lat: number,
  lon: number,
  timezone: string,
): GeoResult {
  return {
    displayName,
    category,
    lat,
    lon,
    roundedLat: Math.round(lat * 60) / 60,
    roundedLon: Math.round(lon * 60) / 60,
    timezone,
  };
}
