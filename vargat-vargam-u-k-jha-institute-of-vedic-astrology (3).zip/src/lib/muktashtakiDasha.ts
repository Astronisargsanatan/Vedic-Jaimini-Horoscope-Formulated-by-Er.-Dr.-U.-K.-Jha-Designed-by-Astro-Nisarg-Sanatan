import { computeAshtakavarga } from "./ashtakavarga";
import { houseOf, rashiName, type Chart } from "./astro";

export type MuktashtakiPeriod = {
  order: number;
  sign: number;
  bindus: number;
  years: number;
  start: Date;
  end: Date;
  children: MuktashtakiPeriod[];
};

export type MuktashtakiResult = {
  method: string;
  totalBindus: number;
  sequence: number[];
  periods: MuktashtakiPeriod[];
  activeMaha?: MuktashtakiPeriod;
  activeAntar?: MuktashtakiPeriod;
  activePratyantar?: MuktashtakiPeriod;
};

const YEAR_MS = 365.25 * 86400000;

/**
 * Institutional configurable default:
 * - sequence: SAV bindus high → low, tie by house from Lagna
 * - sign tenure: max(1, bindus - 24) years
 * - sub-period shares: child sign's SAV bindus / total 386
 *
 * This method is deliberately identified in the UI and is not presented as a
 * universally standardized classical formula. It can be replaced when the
 * institute supplies its exact Muktashtaki source table.
 */
export function computeMuktashtakiDasha(
  chart: Chart,
  birth: Date,
  now = new Date(),
): MuktashtakiResult {
  const av = computeAshtakavarga(chart);
  const sequence = Array.from({ length: 12 }, (_, index) => index + 1).sort(
    (a, b) =>
      av.sarva[b - 1] - av.sarva[a - 1] ||
      houseOf(a, chart.Lagna.sign) - houseOf(b, chart.Lagna.sign),
  );

  let cursor = birth.getTime();
  const periods = sequence.map((sign, index): MuktashtakiPeriod => {
    const bindus = av.sarva[sign - 1];
    const years = Math.max(1, bindus - 24);
    const start = new Date(cursor);
    const end = new Date(cursor + years * YEAR_MS);
    const children = buildChildren(sequence, av.sarva, start, end, 2);
    cursor = end.getTime();
    return { order: index + 1, sign, bindus, years, start, end, children };
  });

  const activeMaha = periods.find((period) => now >= period.start && now < period.end);
  const activeAntar = activeMaha?.children.find((period) => now >= period.start && now < period.end);
  const activePratyantar = activeAntar?.children.find(
    (period) => now >= period.start && now < period.end,
  );

  return {
    method: "Institutional SAV Bindu-Ranked Muktashtaki (configurable)",
    totalBindus: av.sarvaTotal,
    sequence,
    periods,
    activeMaha,
    activeAntar,
    activePratyantar,
  };
}

function buildChildren(
  sequence: number[],
  bindus: number[],
  parentStart: Date,
  parentEnd: Date,
  depth: number,
): MuktashtakiPeriod[] {
  const parentMs = parentEnd.getTime() - parentStart.getTime();
  const total = bindus.reduce((sum, value) => sum + value, 0);
  let cursor = parentStart.getTime();
  return sequence.map((sign, index) => {
    const share = bindus[sign - 1] / total;
    const duration = index === sequence.length - 1 ? parentEnd.getTime() - cursor : parentMs * share;
    const start = new Date(cursor);
    const end = new Date(cursor + duration);
    cursor = end.getTime();
    const node: MuktashtakiPeriod = {
      order: index + 1,
      sign,
      bindus: bindus[sign - 1],
      years: duration / YEAR_MS,
      start,
      end,
      children: [],
    };
    if (depth < 3) node.children = buildChildren(sequence, bindus, start, end, depth + 1);
    return node;
  });
}

export function addPratyantar(period: MuktashtakiPeriod, sequence: number[], bindus: number[]) {
  return buildChildren(sequence, bindus, period.start, period.end, 3);
}

export function formatMuktashtakiDate(date: Date, timezone?: string) {
  const zone = (timezone ?? "").split(" (")[0];
  try {
    return new Intl.DateTimeFormat("en-GB", {
      timeZone: zone.includes("/") ? zone : undefined,
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23",
    })
      .format(date)
      .replace(",", "");
  } catch {
    return date.toISOString().slice(0, 19).replace("T", " ") + " UTC";
  }
}

export function muktashtakiLabel(period: MuktashtakiPeriod) {
  return `${period.sign}. ${rashiName(period.sign)}`;
}
