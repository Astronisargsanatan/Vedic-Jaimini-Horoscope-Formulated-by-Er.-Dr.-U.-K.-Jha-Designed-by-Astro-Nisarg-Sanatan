import { SunPosition } from "astronomy-engine";
import { calculateChartAtInstant, lahiriAyanamsha } from "./birthCalc";
import {
  PLANETS,
  degWithinSign,
  formatDMS,
  houseOf,
  rashiName,
  type Chart,
  type PlanetKey,
} from "./astro";
import type { NativeInfo } from "../state/ChartContext";

export type VarshPlanet = {
  key: PlanetKey;
  sign: number;
  rashi: string;
  longitude: string;
  house: number;
  motion: "D" | "R";
  natalSign: number;
};

export type VarshPraveshResult = {
  targetYear: number;
  completedAge: number;
  runningYear: number;
  birthInstant: Date;
  praveshInstant: Date;
  natalSunSidereal: number;
  returnSunSidereal: number;
  differenceArcSeconds: number;
  chart: Chart;
  planets: VarshPlanet[];
};

function normalize(value: number): number {
  return ((value % 360) + 360) % 360;
}

function signedDifference(value: number, target: number): number {
  return ((value - target + 540) % 360) - 180;
}

function siderealSun(date: Date): number {
  return normalize(SunPosition(date).elon - lahiriAyanamsha(date));
}

export function birthInstantFromNative(native: NativeInfo): Date {
  if (native.birthUtc) {
    const exact = new Date(native.birthUtc);
    if (!Number.isNaN(exact.getTime())) return exact;
  }
  const date = native.date.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const time = native.time.match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  if (!date) throw new Error("Valid Date of Birth is required on Home.");
  return new Date(
    Date.UTC(
      Number(date[3]),
      Number(date[2]) - 1,
      Number(date[1]),
      time ? Number(time[1]) : 12,
      time ? Number(time[2]) : 0,
      time ? Number(time[3] ?? 0) : 0,
    ) - 330 * 60000,
  );
}

/** Find the exact Lahiri sidereal Sun return in a target Gregorian year. */
export function findNirayanaSolarReturn(birth: Date, targetYear: number): Date {
  const target = siderealSun(birth);
  // Start 16 days before the Gregorian anniversary; Sun is safely before target.
  const anniversary = Date.UTC(
    targetYear,
    birth.getUTCMonth(),
    Math.min(birth.getUTCDate(), daysInMonth(targetYear, birth.getUTCMonth())),
    birth.getUTCHours(),
    birth.getUTCMinutes(),
    birth.getUTCSeconds(),
  );
  let low = anniversary - 16 * 86400000;
  let high = anniversary + 16 * 86400000;
  let fLow = signedDifference(siderealSun(new Date(low)), target);
  let fHigh = signedDifference(siderealSun(new Date(high)), target);

  // Defensive wider bracket for unusual historical dates.
  if (!(fLow <= 0 && fHigh >= 0)) {
    low = anniversary - 32 * 86400000;
    high = anniversary + 32 * 86400000;
    fLow = signedDifference(siderealSun(new Date(low)), target);
    fHigh = signedDifference(siderealSun(new Date(high)), target);
  }
  if (!(fLow <= 0 && fHigh >= 0)) {
    throw new Error(`Unable to bracket the solar return for ${targetYear}.`);
  }

  // Refine to better than one second.
  while (high - low > 500) {
    const middle = Math.floor((low + high) / 2);
    const fMiddle = signedDifference(siderealSun(new Date(middle)), target);
    if (fMiddle < 0) low = middle;
    else high = middle;
  }
  return new Date(high);
}

function daysInMonth(year: number, zeroBasedMonth: number): number {
  return new Date(Date.UTC(year, zeroBasedMonth + 1, 0)).getUTCDate();
}

export function computeVarshPravesh(
  natal: Chart,
  native: NativeInfo,
  targetYear: number,
): VarshPraveshResult {
  if (native.lat == null || native.lon == null) {
    throw new Error("Birth latitude and longitude are required. Calculate the Home horoscope first.");
  }
  const birthInstant = birthInstantFromNative(native);
  const praveshInstant = findNirayanaSolarReturn(birthInstant, targetYear);
  const chart = calculateChartAtInstant(praveshInstant, native.lat, native.lon);
  const birthYear = birthInstant.getUTCFullYear();
  const natalSunSidereal = (natal.Surya.sign - 1) * 30 + degWithinSign(natal.Surya);
  const returnSunSidereal = siderealSun(praveshInstant);

  const planets = PLANETS.map((planet): VarshPlanet => {
    const position = chart[planet.key];
    return {
      key: planet.key,
      sign: position.sign,
      rashi: rashiName(position.sign),
      longitude: formatDMS(position),
      house: houseOf(position.sign, chart.Lagna.sign),
      motion: position.motion ?? "D",
      natalSign: natal[planet.key].sign,
    };
  });

  return {
    targetYear,
    completedAge: targetYear - birthYear,
    runningYear: targetYear - birthYear + 1,
    birthInstant,
    praveshInstant,
    natalSunSidereal,
    returnSunSidereal,
    differenceArcSeconds: Math.abs(signedDifference(returnSunSidereal, natalSunSidereal)) * 3600,
    chart,
    planets,
  };
}

export function formatVarshDate(date: Date, timezone?: string): string {
  const zone = (timezone ?? "").split(" (")[0];
  try {
    return new Intl.DateTimeFormat("en-GB", {
      timeZone: zone.includes("/") ? zone : undefined,
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23",
    })
      .format(date)
      .replace(",", "");
  } catch {
    return date.toISOString().replace("T", " ").slice(0, 19) + " UTC";
  }
}
