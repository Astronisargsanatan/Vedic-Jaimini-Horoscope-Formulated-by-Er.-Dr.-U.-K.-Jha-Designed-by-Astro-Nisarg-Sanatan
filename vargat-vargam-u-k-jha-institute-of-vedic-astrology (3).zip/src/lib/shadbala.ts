import {
  RASHI_LORDS,
  degWithinSign,
  houseOf,
  rashiName,
  type Chart,
  type PlanetKey,
  type Position,
} from "./astro";
import { computePanchang } from "./panchang";
import type { NativeInfo } from "../state/ChartContext";

export const SHADBALA_PLANETS: PlanetKey[] = [
  "Surya",
  "Chandra",
  "Mangal",
  "Budh",
  "Guru",
  "Shukra",
  "Shani",
];

export type ShadbalaComponent = {
  name: string;
  sanskrit: string;
  virupas: number;
  note: string;
};

export type ShadbalaPlanetResult = {
  planet: PlanetKey;
  components: ShadbalaComponent[];
  sthanaSub: ShadbalaComponent[];
  totalVirupas: number;
  requiredVirupas: number;
  ratio: number;
  rupas: number;
  status: "Strong" | "Adequate" | "Weak";
  summary: string;
};

export type ShadbalaResult = {
  planets: ShadbalaPlanetResult[];
  strongest: ShadbalaPlanetResult;
  weakest: ShadbalaPlanetResult;
  notes: string[];
};

export const SHADBALA_EXPLANATION = [
  {
    component: "Sthana Bala / स्थान बल",
    formula: "Uchcha + Saptavargaja + Ojayugma + Kendradi + Drekkana",
    english: "Measures positional power: exaltation distance, dignity in seven divisions, odd/even placement, angular placement and drekkana suitability.",
    hindi: "स्थिति-जन्य शक्ति: उच्च-बिंदु दूरी, सप्तवर्ग की गरिमा, ओज/युग्म स्थिति, केन्द्रादि स्थिति और द्रेष्काण योग्यता को जोड़ता है।",
  },
  {
    component: "Dig Bala / दिग् बल",
    formula: "Distance from powerless direction ÷ 3",
    english: "Measures directional strength. A planet gains maximum strength near its preferred directional point and zero near its powerless point.",
    hindi: "दिशा-बल। ग्रह अपनी अनुकूल दिशा के निकट अधिक बल और निर्बल दिशा के निकट कम बल पाता है।",
  },
  {
    component: "Kala Bala / काल बल",
    formula: "Diva/Ratri factor + Paksha factor",
    english: "Measures time strength from day/night suitability and lunar phase support. The app uses transparent available-chart proxies.",
    hindi: "जन्म-काल का बल: दिन/रात्रि अनुकूलता और चन्द्र-पक्ष समर्थन से निकला योग। यहाँ उपलब्ध chart-data पर आधारित transparent proxy है।",
  },
  {
    component: "Cheshta Bala / चेष्ट बल",
    formula: "Motion status based score",
    english: "Measures motional strength. Retrograde planets receive higher cheshta; direct planets receive ordinary motion strength.",
    hindi: "गति-बल। वक्री ग्रह को उच्च चेष्टा-बल, मार्गी ग्रह को सामान्य गति-बल दिया गया है।",
  },
  {
    component: "Naisargika Bala / नैसर्गिक बल",
    formula: "Fixed natural luminosity values",
    english: "Permanent inherent strength: Sun highest, Saturn lowest, following the standard natural strength sequence.",
    hindi: "स्वाभाविक स्थायी बल: सूर्य सर्वाधिक और शनि न्यूनतम, शास्त्रीय नैसर्गिक क्रम के अनुसार।",
  },
  {
    component: "Drik Bala / दृक् बल",
    formula: "Benefic full aspects − malefic full aspects",
    english: "Measures aspectual support or affliction received from other planets. Benefic aspects add, malefic aspects subtract.",
    hindi: "दृष्टि-बल। शुभ ग्रहों की पूर्ण दृष्टि बल बढ़ाती है और पाप ग्रहों की पूर्ण दृष्टि घटाती है।",
  },
];

const EXALTATION: Record<PlanetKey, number> = {
  Surya: 10,
  Chandra: 33,
  Mangal: 298,
  Budh: 165,
  Guru: 95,
  Shukra: 357,
  Shani: 200,
  Lagna: 0,
  Rahu: 0,
  Ketu: 0,
};

const NATURAL_STRENGTH: Record<PlanetKey, number> = {
  Surya: 60,
  Chandra: 51.43,
  Shukra: 42.86,
  Guru: 34.29,
  Budh: 25.71,
  Mangal: 17.14,
  Shani: 8.57,
  Lagna: 0,
  Rahu: 0,
  Ketu: 0,
};

const REQUIRED: Record<PlanetKey, number> = {
  Surya: 390,
  Chandra: 360,
  Mangal: 300,
  Budh: 420,
  Guru: 390,
  Shukra: 330,
  Shani: 300,
  Lagna: 0,
  Rahu: 0,
  Ketu: 0,
};

const FRIENDS: Record<PlanetKey, PlanetKey[]> = {
  Surya: ["Chandra", "Mangal", "Guru"],
  Chandra: ["Surya", "Budh"],
  Mangal: ["Surya", "Chandra", "Guru"],
  Budh: ["Surya", "Shukra"],
  Guru: ["Surya", "Chandra", "Mangal"],
  Shukra: ["Budh", "Shani"],
  Shani: ["Budh", "Shukra"],
  Lagna: [],
  Rahu: [],
  Ketu: [],
};

const ENEMIES: Record<PlanetKey, PlanetKey[]> = {
  Surya: ["Shukra", "Shani"],
  Chandra: [],
  Mangal: ["Budh"],
  Budh: ["Chandra"],
  Guru: ["Budh", "Shukra"],
  Shukra: ["Surya", "Chandra"],
  Shani: ["Surya", "Chandra", "Mangal"],
  Lagna: [],
  Rahu: [],
  Ketu: [],
};

const MOOLATRIKONA: Partial<Record<PlanetKey, number[]>> = {
  Surya: [5],
  Chandra: [2],
  Mangal: [1],
  Budh: [6],
  Guru: [9],
  Shukra: [7],
  Shani: [11],
};

const OWN_SIGNS: Partial<Record<PlanetKey, number[]>> = {
  Surya: [5],
  Chandra: [4],
  Mangal: [1, 8],
  Budh: [3, 6],
  Guru: [9, 12],
  Shukra: [2, 7],
  Shani: [10, 11],
};

function normalize(value: number): number {
  return ((value % 360) + 360) % 360;
}

function absLon(position: Position): number {
  return (position.sign - 1) * 30 + degWithinSign(position);
}

function angularDistance(a: number, b: number): number {
  const diff = Math.abs(normalize(a - b));
  return diff > 180 ? 360 - diff : diff;
}

function signAt(position: Position, division: number, startSign?: number): number {
  const part = Math.min(division - 1, Math.floor(degWithinSign(position) / (30 / division)));
  return ((startSign ?? position.sign) - 1 + part) % 12 + 1;
}

function d7Sign(position: Position): number {
  const start = position.sign % 2 === 1 ? position.sign : ((position.sign + 5) % 12) + 1;
  return signAt(position, 7, start);
}

function d12Sign(position: Position): number {
  return signAt(position, 12, position.sign);
}

function d30Sign(position: Position): number {
  const d = degWithinSign(position);
  const odd = position.sign % 2 === 1;
  if (odd) {
    if (d < 5) return 1;
    if (d < 10) return 11;
    if (d < 18) return 9;
    if (d < 25) return 3;
    return 7;
  }
  if (d < 5) return 2;
  if (d < 12) return 6;
  if (d < 20) return 12;
  if (d < 25) return 10;
  return 8;
}

function horaSign(position: Position): number {
  const firstHalf = degWithinSign(position) < 15;
  const odd = position.sign % 2 === 1;
  return odd === firstHalf ? 5 : 4; // Leo for Sun Hora, Cancer for Moon Hora.
}

function drekkanaSign(position: Position): number {
  return signAt(position, 3, position.sign);
}

function navamsaSign(position: Position): number {
  const group = position.sign % 4;
  const start = group === 1 ? 1 : group === 2 ? 10 : group === 3 ? 7 : 4;
  return signAt(position, 9, start);
}

function compoundRelation(chart: Chart, planet: PlanetKey, sign: number): string {
  const lord = RASHI_LORDS[sign];
  if (lord === planet) return "own";
  const natural = FRIENDS[planet].includes(lord)
    ? "friend"
    : ENEMIES[planet].includes(lord)
      ? "enemy"
      : "neutral";
  const fromPlanet = houseOf(sign, chart[planet].sign);
  const temporalFriend = [2, 3, 4, 10, 11, 12].includes(fromPlanet);
  if (natural === "friend" && temporalFriend) return "greatFriend";
  if (natural === "enemy" && !temporalFriend) return "greatEnemy";
  if (natural === "friend" || (natural === "neutral" && temporalFriend)) return "friend";
  if (natural === "enemy" || (natural === "neutral" && !temporalFriend)) return "enemy";
  return "neutral";
}

function dignityScore(chart: Chart, planet: PlanetKey, sign: number): number {
  if (MOOLATRIKONA[planet]?.includes(sign)) return 45;
  if (OWN_SIGNS[planet]?.includes(sign)) return 30;
  const relation = compoundRelation(chart, planet, sign);
  if (relation === "greatFriend") return 22.5;
  if (relation === "friend") return 15;
  if (relation === "neutral") return 7.5;
  if (relation === "enemy") return 3.75;
  return 1.875;
}

function saptavargaja(chart: Chart, planet: PlanetKey): ShadbalaComponent {
  const p = chart[planet];
  const signs = [p.sign, horaSign(p), drekkanaSign(p), d7Sign(p), navamsaSign(p), d12Sign(p), d30Sign(p)];
  const value = signs.reduce((sum, sign) => sum + dignityScore(chart, planet, sign), 0);
  return {
    name: "Saptavargaja Bala",
    sanskrit: "सप्तवर्गज बल",
    virupas: value,
    note: `Rashi/Hora/Drekkana/D7/D9/D12/D30 signs: ${signs.map((s) => `${s}-${rashiName(s)}`).join(", ")}.`,
  };
}

function uchcha(chart: Chart, planet: PlanetKey): ShadbalaComponent {
  const debility = normalize(EXALTATION[planet] + 180);
  const distance = angularDistance(absLon(chart[planet]), debility);
  return {
    name: "Uchcha Bala",
    sanskrit: "उच्च बल",
    virupas: distance / 3,
    note: `Distance from debility point ${debility.toFixed(2)}° = ${distance.toFixed(2)}°; /3.`,
  };
}

function ojaYugma(chart: Chart, planet: PlanetKey): ShadbalaComponent {
  const d1Odd = chart[planet].sign % 2 === 1;
  const d9Odd = navamsaSign(chart[planet]) % 2 === 1;
  const male = ["Surya", "Mangal", "Guru"].includes(planet);
  const female = ["Chandra", "Shukra"].includes(planet);
  const ok = (odd: boolean) => (male ? odd : female ? !odd : false);
  const value = (ok(d1Odd) ? 15 : 0) + (ok(d9Odd) ? 15 : 0);
  return {
    name: "Ojayugma Bala",
    sanskrit: "ओजयुग्म बल",
    virupas: value,
    note: "Male planets gain in odd Rashi/Navamsha; female planets in even. Mercury/Saturn neutral here.",
  };
}

function kendradi(chart: Chart, planet: PlanetKey): ShadbalaComponent {
  const house = houseOf(chart[planet].sign, chart.Lagna.sign);
  const value = [1, 4, 7, 10].includes(house) ? 60 : [2, 5, 8, 11].includes(house) ? 30 : 15;
  return { name: "Kendradi Bala", sanskrit: "केन्द्रादि बल", virupas: value, note: `Planet in house ${house}.` };
}

function drekkanaBala(chart: Chart, planet: PlanetKey): ShadbalaComponent {
  const drekkana = Math.floor(degWithinSign(chart[planet]) / 10) + 1;
  const male = ["Surya", "Mangal", "Guru"].includes(planet);
  const female = ["Chandra", "Shukra"].includes(planet);
  const neutral = ["Budh", "Shani"].includes(planet);
  const good = (male && drekkana === 1) || (female && drekkana === 2) || (neutral && drekkana === 3);
  return { name: "Drekkana Bala", sanskrit: "द्रेष्काण बल", virupas: good ? 15 : 0, note: `Planet in ${drekkana}rd/nd/st Drekkana.` };
}

function digBala(chart: Chart, planet: PlanetKey): ShadbalaComponent {
  const relative = normalize(absLon(chart[planet]) - absLon(chart.Lagna));
  const strongOffset = ["Surya", "Mangal"].includes(planet)
    ? 270
    : ["Chandra", "Shukra"].includes(planet)
      ? 90
      : ["Budh", "Guru"].includes(planet)
        ? 0
        : 180;
  const powerless = normalize(strongOffset + 180);
  const value = angularDistance(relative, powerless) / 3;
  return { name: "Dig Bala", sanskrit: "दिग् बल", virupas: value, note: `Relative longitude ${relative.toFixed(2)}°, powerless point ${powerless}°.` };
}

function kalaBala(chart: Chart, native: NativeInfo | null, planet: PlanetKey): ShadbalaComponent {
  const panchang = computePanchang(chart, native);
  const sunHouse = houseOf(chart.Surya.sign, chart.Lagna.sign);
  const dayBirth = sunHouse >= 7 && sunHouse <= 12;
  const dayGroup = ["Surya", "Guru", "Shukra"];
  const nightGroup = ["Chandra", "Mangal", "Shani"];
  const nata = planet === "Budh" ? 60 : dayBirth === dayGroup.includes(planet) ? 60 : nightGroup.includes(planet) ? 30 : 15;
  const elong = (absLon(chart.Chandra) - absLon(chart.Surya) + 360) % 360;
  const bright = elong <= 180 ? elong : 360 - elong;
  const paksha = ["Chandra", "Budh", "Guru", "Shukra"].includes(planet) ? bright / 3 : 60 - bright / 3;
  const value = nata + paksha;
  return {
    name: "Kala Bala",
    sanskrit: "काल बल",
    virupas: value,
    note: `Diva/Ratri proxy from Sun house H${sunHouse}: ${dayBirth ? "day" : "night"}; Nathonnata ${nata.toFixed(2)} + Paksha ${paksha.toFixed(2)}. Vara: ${panchang.vara}.`,
  };
}

function chestaBala(chart: Chart, planet: PlanetKey): ShadbalaComponent {
  const value = chart[planet].motion === "R" ? 60 : ["Surya", "Chandra"].includes(planet) ? 30 : 20;
  return { name: "Cheshta Bala", sanskrit: "चेष्ट बल", virupas: value, note: `Motion status ${chart[planet].motion ?? "D"}.` };
}

function naisargika(planet: PlanetKey): ShadbalaComponent {
  return { name: "Naisargika Bala", sanskrit: "नैसर्गिक बल", virupas: NATURAL_STRENGTH[planet], note: "Fixed natural luminosity ranking." };
}

function aspectTargets(chart: Chart, planet: PlanetKey): number[] {
  const aspects = planet === "Mangal" ? [4, 7, 8] : planet === "Guru" ? [5, 7, 9] : planet === "Shani" ? [3, 7, 10] : [7];
  return aspects.map((h) => ((chart[planet].sign - 1 + h - 1) % 12) + 1);
}

function drikBala(chart: Chart, planet: PlanetKey): ShadbalaComponent {
  let value = 0;
  const notes: string[] = [];
  for (const source of SHADBALA_PLANETS) {
    if (source === planet) continue;
    if (aspectTargets(chart, source).includes(chart[planet].sign)) {
      const benefic = ["Guru", "Shukra", "Budh", "Chandra"].includes(source);
      value += benefic ? 15 : -15;
      notes.push(`${source} ${benefic ? "+" : "-"}15`);
    }
  }
  return { name: "Drik Bala", sanskrit: "दृक् बल", virupas: value, note: notes.length ? notes.join(", ") : "No full classical aspect received." };
}

export function computeShadbala(chart: Chart, native: NativeInfo | null): ShadbalaResult {
  const planets = SHADBALA_PLANETS.map((planet): ShadbalaPlanetResult => {
    const sthanaSub = [
      uchcha(chart, planet),
      saptavargaja(chart, planet),
      ojaYugma(chart, planet),
      kendradi(chart, planet),
      drekkanaBala(chart, planet),
    ];
    const sthana = {
      name: "Sthana Bala",
      sanskrit: "स्थान बल",
      virupas: sthanaSub.reduce((sum, item) => sum + item.virupas, 0),
      note: "Sum of Uchcha, Saptavargaja, Ojayugma, Kendradi and Drekkana Bala.",
    };
    const components = [
      sthana,
      digBala(chart, planet),
      kalaBala(chart, native, planet),
      chestaBala(chart, planet),
      naisargika(planet),
      drikBala(chart, planet),
    ];
    const totalVirupas = components.reduce((sum, item) => sum + item.virupas, 0);
    const requiredVirupas = REQUIRED[planet];
    const ratio = totalVirupas / requiredVirupas;
    const status = ratio >= 1.1 ? "Strong" : ratio >= 0.9 ? "Adequate" : "Weak";
    return {
      planet,
      components,
      sthanaSub,
      totalVirupas,
      requiredVirupas,
      ratio,
      rupas: totalVirupas / 60,
      status,
      summary: `${planet} has ${totalVirupas.toFixed(2)} virupas (${(totalVirupas / 60).toFixed(2)} rupas), ${(ratio * 100).toFixed(1)}% of its required Raman/BPHS threshold.`
    };
  }).sort((a, b) => b.totalVirupas - a.totalVirupas);
  return {
    planets,
    strongest: planets[0],
    weakest: planets[planets.length - 1],
    notes: [
      "This worksheet follows the B.V. Raman / Parashari sixfold Shadbala structure in Virupas. / यह worksheet B.V. Raman / पाराशरी षड्बल के छह अंगों को Virupa में जोड़ती है।",
      "Final Total = Sthana + Dig + Kala + Cheshta + Naisargika + Drik Bala. / अंतिम योग = स्थान + दिग् + काल + चेष्टा + नैसर्गिक + दृक् बल।",
      "Full Swiss-Ephemeris-grade Kala, Ayana and exact aspect arc refinements are represented by transparent computational proxies where the browser chart model has limited data. / जहाँ browser-data सीमित है वहाँ Kala/Ayana/Drik के लिए स्पष्ट proxy उपयोग किए गए हैं।",
      "Use totals comparatively with Dasha, Varga, Ashtakavarga and Bhava strength, not as isolated benefic/malefic judgement. / इसे दशा, वर्ग, अष्टकवर्ग और भावबल के साथ तुलनात्मक रूप से पढ़ें।",
    ],
  };
}

export function rupa(value: number): string {
  return `${(value / 60).toFixed(2)} R`;
}
