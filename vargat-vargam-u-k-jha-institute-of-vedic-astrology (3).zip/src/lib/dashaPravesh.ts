import { calculateChartAtInstant } from "./birthCalc";
import { RASHI_LORDS, computeVarga, type Chart, type PlanetKey } from "./astro";
import type { NativeInfo } from "../state/ChartContext";

export type PraveshLevel = "Mahadasha" | "Antardasha" | "Pratyantar Dasha" | "Bhukti";

export type PraveshAnchor = {
  level: PraveshLevel;
  name: string;
  start: Date;
};

export type DashaPraveshRequest = {
  system: string;
  selected: PraveshAnchor;
  path: PraveshAnchor[];
};

export type EcpMetric = {
  code: "ECPM" | "ECPA" | "ECPP";
  label: string;
  periodName: string;
  start: Date;
  lagnaSign: number;
  controller: PlanetKey;
};

export function canCalculatePravesh(native: NativeInfo | null): boolean {
  return native?.lat != null && native?.lon != null;
}

export function calculatePraveshChart(native: NativeInfo, instant: Date): Chart {
  if (native.lat == null || native.lon == null) {
    throw new Error("Birth latitude and longitude are required for Dasha Pravesh Chart.");
  }
  return calculateChartAtInstant(instant, native.lat, native.lon);
}

function codeFor(level: PraveshLevel): EcpMetric["code"] | null {
  if (level === "Mahadasha") return "ECPM";
  if (level === "Antardasha" || level === "Bhukti") return "ECPA";
  if (level === "Pratyantar Dasha") return "ECPP";
  return null;
}

/** Calculate ECPM/ECPA/ECPP independently at each corresponding entry instant. */
export function calculateEcpMetrics(
  native: NativeInfo,
  path: PraveshAnchor[],
): EcpMetric[] {
  return path.flatMap((anchor) => {
    const code = codeFor(anchor.level);
    if (!code) return [];
    const chart = calculatePraveshChart(native, anchor.start);
    const lagnaSign = chart.Lagna.sign;
    return [{
      code,
      label:
        code === "ECPM"
          ? "Event Controlling Planet of Mahadasha"
          : code === "ECPA"
            ? "Event Controlling Planet of Antardasha"
            : "Event Controlling Planet of Pratyantar Dasha",
      periodName: anchor.name,
      start: anchor.start,
      lagnaSign,
      controller: RASHI_LORDS[lagnaSign],
    }];
  });
}

export function praveshSigns(chart: Chart) {
  return computeVarga(chart, "D1");
}