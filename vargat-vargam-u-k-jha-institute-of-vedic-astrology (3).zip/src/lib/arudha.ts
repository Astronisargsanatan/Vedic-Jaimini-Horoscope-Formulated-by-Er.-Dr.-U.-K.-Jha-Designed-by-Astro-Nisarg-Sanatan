import {
  RASHI_LORDS,
  houseOf,
  rashiName,
  type Chart,
  type PlanetKey,
} from "./astro";

export type ArudhaLabel = "AL" | "A2" | "A3" | "A4" | "A5" | "A6" | "A7" | "A8" | "A9" | "A10" | "A11" | "A12";

export type LordRelation =
  | "own"
  | "panaphara"
  | "apoklima"
  | "kendra4"
  | "kendra7"
  | "kendra10";

export type ArudhaResult = {
  bhava: number; // 1..12
  label: ArudhaLabel;
  bhavaSign: number;
  lord: PlanetKey;
  lordSign: number;
  lordFromBhava: number; // 1..12
  relation: LordRelation;
  ruleApplied: string;
  tentativeHouse: number;
  arudhaHouse: number;
  arudhaSign: number;
  exceptionTriggered: boolean;
};

export const ARUDHA_LABELS: ArudhaLabel[] = [
  "AL",
  "A2",
  "A3",
  "A4",
  "A5",
  "A6",
  "A7",
  "A8",
  "A9",
  "A10",
  "A11",
  "A12",
];

function normalizeHouse(n: number): number {
  return ((n - 1) % 12 + 12) % 12 + 1;
}

function houseToSign(lagnaSign: number, house: number): number {
  return ((lagnaSign - 1 + (house - 1)) % 12) + 1;
}

function classifyRelation(lordFromBhava: number): LordRelation {
  if (lordFromBhava === 1) return "own";
  if ([2, 5, 8, 11].includes(lordFromBhava)) return "panaphara";
  if ([3, 6, 9, 12].includes(lordFromBhava)) return "apoklima";
  if (lordFromBhava === 4) return "kendra4";
  if (lordFromBhava === 7) return "kendra7";
  return "kendra10";
}

/**
 * Bhaveshat Bhavam → Arudha of Evolution
 *
 * General (Panaphara 2/5/8/11 and Apoklima 3/6/9/12):
 *   Count the same number of houses from the Bhavesh as the Bhavesh is
 *   from the Bhava. That landing house is the Arudha.
 *
 * Special when Bhavesh is in Kendra from the Bhava:
 *   A bhava and its 7th can never become its own Arudha.
 *   - Own house (1): tentative = same bhava → exception → 10th from bhava (Bhavesh se 10th)
 *   - 4th: tentative = 7th → exception → 4th (Bhavesh jahan baitha hai)
 *   - 7th: tentative = same bhava → exception → 4th from bhava (Bhavesh se 10th)
 *   - 10th: tentative = 7th → exception → 10th (Bhavesh jahan baitha hai)
 */
export function computeArudhaPadas(chart: Chart): ArudhaResult[] {
  const lagnaSign = chart.Lagna.sign;
  const results: ArudhaResult[] = [];

  for (let bhava = 1; bhava <= 12; bhava++) {
    const bhavaSign = houseToSign(lagnaSign, bhava);
    const lord = RASHI_LORDS[bhavaSign];
    const lordSign = chart[lord].sign;
    const lordFromBhava = houseOf(lordSign, bhavaSign);
    const relation = classifyRelation(lordFromBhava);

    // Always count the same distance again from the lord
    const tentativeHouse = normalizeHouse(bhava + (lordFromBhava - 1) * 2);
    let arudhaHouse = tentativeHouse;
    let exceptionTriggered = false;
    let ruleApplied = "";

    if (relation === "panaphara" || relation === "apoklima") {
      ruleApplied =
        relation === "panaphara"
          ? `General Panaphara rule: Bhavesh is ${lordFromBhava}th from bhava → count ${lordFromBhava} from Bhavesh`
          : `General Apoklima rule: Bhavesh is ${lordFromBhava}th from bhava → count ${lordFromBhava} from Bhavesh`;
      arudhaHouse = tentativeHouse;
    } else if (relation === "own") {
      // tentative lands on same bhava — forbidden → 10th from bhava
      exceptionTriggered = true;
      arudhaHouse = normalizeHouse(bhava + 9); // 10th
      ruleApplied =
        "Kendra special (own house): same bhava cannot be Arudha → 10th from bhava (Bhavesh se 10th)";
    } else if (relation === "kendra4") {
      // tentative lands on 7th — forbidden → keep 4th (lord seat)
      exceptionTriggered = true;
      arudhaHouse = normalizeHouse(bhava + 3); // 4th
      ruleApplied =
        "Kendra special (4th): 7th cannot be Arudha → 4th from bhava (Bhavesh jahan baitha hai)";
    } else if (relation === "kendra7") {
      // tentative lands on same bhava — forbidden → 4th from bhava
      exceptionTriggered = true;
      arudhaHouse = normalizeHouse(bhava + 3); // 4th
      ruleApplied =
        "Kendra special (7th): same bhava cannot be Arudha → 4th from bhava (Bhavesh se 10th)";
    } else {
      // kendra10 — tentative lands on 7th — forbidden → keep 10th (lord seat)
      exceptionTriggered = true;
      arudhaHouse = normalizeHouse(bhava + 9); // 10th
      ruleApplied =
        "Kendra special (10th): 7th cannot be Arudha → 10th from bhava (Bhavesh jahan baitha hai)";
    }

    results.push({
      bhava,
      label: ARUDHA_LABELS[bhava - 1],
      bhavaSign,
      lord,
      lordSign,
      lordFromBhava,
      relation,
      ruleApplied,
      tentativeHouse,
      arudhaHouse,
      arudhaSign: houseToSign(lagnaSign, arudhaHouse),
      exceptionTriggered,
    });
  }

  return results;
}

/** Group Arudha labels by the house they fall in (for kundali overlay). */
export function arudhaByHouse(results: ArudhaResult[]): Record<number, ArudhaLabel[]> {
  const map: Record<number, ArudhaLabel[]> = {};
  for (let h = 1; h <= 12; h++) map[h] = [];
  for (const r of results) {
    map[r.arudhaHouse].push(r.label);
  }
  return map;
}

export function relationLabel(relation: LordRelation): string {
  switch (relation) {
    case "own":
      return "Kendra · Own (1)";
    case "panaphara":
      return "Panaphara (2/5/8/11)";
    case "apoklima":
      return "Apoklima (3/6/9/12)";
    case "kendra4":
      return "Kendra · 4th";
    case "kendra7":
      return "Kendra · 7th";
    case "kendra10":
      return "Kendra · 10th";
  }
}

export function formatArudhaReport(results: ArudhaResult[], lagnaSign: number): string {
  const lines = [
    "==================================================",
    "  BHAVESHAT BHAVAM — ARUDHA OF EVOLUTION (आरूढ़)",
    "==================================================",
    `Lagna: ${lagnaSign}. ${rashiName(lagnaSign)}`,
    "",
  ];
  for (const r of results) {
    lines.push(
      `${r.label} (Bhava ${r.bhava}): Sign ${r.arudhaSign}. ${rashiName(r.arudhaSign)} · House ${r.arudhaHouse}`,
    );
    lines.push(
      `  Bhava sign ${r.bhavaSign}. ${rashiName(r.bhavaSign)} · Lord ${r.lord} in ${r.lordSign}. ${rashiName(r.lordSign)} (${r.lordFromBhava}th from bhava)`,
    );
    lines.push(`  Relation: ${relationLabel(r.relation)}`);
    lines.push(`  Rule: ${r.ruleApplied}`);
    if (r.exceptionTriggered) {
      lines.push(`  Tentative house ${r.tentativeHouse} blocked → final ${r.arudhaHouse}`);
    }
    lines.push("");
  }
  return lines.join("\n");
}
