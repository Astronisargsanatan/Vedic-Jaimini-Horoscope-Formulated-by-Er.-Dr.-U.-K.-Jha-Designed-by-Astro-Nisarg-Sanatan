/**
 * ================================================================================
 * VIMSHOTTARI DASHA (प्रचलित यवन विंशोत्तरी दशा)
 * Calculated from the Moon's exact longitude (Nakshatra + traversed portion).
 * 5 levels: Mahadasha → Antardasha → Pratyantar → Sukshma → Pran.
 * Total cycle = 120 years. Vedic year length = 365.25 days.
 * ================================================================================
 */

import { degWithinSign, type Chart, type PlanetKey } from "./astro";

export type DashaLord =
  | "Ketu"
  | "Shukra"
  | "Surya"
  | "Chandra"
  | "Mangal"
  | "Rahu"
  | "Guru"
  | "Shani"
  | "Budh";

export const DASHA_SEQUENCE: { lord: DashaLord; years: number }[] = [
  { lord: "Ketu", years: 7 },
  { lord: "Shukra", years: 20 },
  { lord: "Surya", years: 6 },
  { lord: "Chandra", years: 10 },
  { lord: "Mangal", years: 7 },
  { lord: "Rahu", years: 18 },
  { lord: "Guru", years: 16 },
  { lord: "Shani", years: 19 },
  { lord: "Budh", years: 17 },
];

export const TOTAL_YEARS = 120;
export const YEAR_DAYS = 365.25;
export const YEAR_MS = YEAR_DAYS * 24 * 3600 * 1000;
export const NAKSHATRA_SPAN = 360 / 27; // 13°20'

export const NAKSHATRAS: { name: string; lord: DashaLord }[] = [
  { name: "Ashwini", lord: "Ketu" },
  { name: "Bharani", lord: "Shukra" },
  { name: "Krittika", lord: "Surya" },
  { name: "Rohini", lord: "Chandra" },
  { name: "Mrigashira", lord: "Mangal" },
  { name: "Ardra", lord: "Rahu" },
  { name: "Punarvasu", lord: "Guru" },
  { name: "Pushya", lord: "Shani" },
  { name: "Ashlesha", lord: "Budh" },
  { name: "Magha", lord: "Ketu" },
  { name: "Purva Phalguni", lord: "Shukra" },
  { name: "Uttara Phalguni", lord: "Surya" },
  { name: "Hasta", lord: "Chandra" },
  { name: "Chitra", lord: "Mangal" },
  { name: "Swati", lord: "Rahu" },
  { name: "Vishakha", lord: "Guru" },
  { name: "Anuradha", lord: "Shani" },
  { name: "Jyeshtha", lord: "Budh" },
  { name: "Mula", lord: "Ketu" },
  { name: "Purva Ashadha", lord: "Shukra" },
  { name: "Uttara Ashadha", lord: "Surya" },
  { name: "Shravana", lord: "Chandra" },
  { name: "Dhanishta", lord: "Mangal" },
  { name: "Shatabhisha", lord: "Rahu" },
  { name: "Purva Bhadrapada", lord: "Guru" },
  { name: "Uttara Bhadrapada", lord: "Shani" },
  { name: "Revati", lord: "Budh" },
];

export const LORD_HINDI: Record<DashaLord, string> = {
  Ketu: "केतु",
  Shukra: "शुक्र",
  Surya: "सूर्य",
  Chandra: "चन्द्र",
  Mangal: "मंगल",
  Rahu: "राहु",
  Guru: "गुरु",
  Shani: "शनि",
  Budh: "बुध",
};

export const LEVEL_NAMES: Record<number, string> = {
  1: "महादशा (Mahadasha)",
  2: "अंतर्दशा (Antardasha)",
  3: "प्रत्यंतर दशा (Pratyantar)",
  4: "सूक्ष्म दशा (Sukshma)",
  5: "प्राण दशा (Pran)",
};

export type DashaLevel = 1 | 2 | 3 | 4 | 5;

export type DashaPeriod = {
  lord: DashaLord;
  level: DashaLevel;
  start: Date;
  end: Date;
  durationMs: number;
  children?: DashaPeriod[];
};

export type MoonNakshatraInfo = {
  moonLongitude: number;
  nakshatraIndex: number;
  nakshatraName: string;
  nakshatraLord: DashaLord;
  pada: number;
  traversedFraction: number;
  balanceYears: number;
};

export function moonNakshatra(chart: Chart): MoonNakshatraInfo {
  const moon = chart.Chandra;
  const moonLongitude = (moon.sign - 1) * 30 + degWithinSign(moon);
  const nakshatraIndex = Math.floor(moonLongitude / NAKSHATRA_SPAN) % 27;
  const withinNak = moonLongitude - nakshatraIndex * NAKSHATRA_SPAN;
  const traversedFraction = withinNak / NAKSHATRA_SPAN;
  const pada = Math.floor(withinNak / (NAKSHATRA_SPAN / 4)) + 1;
  const nak = NAKSHATRAS[nakshatraIndex];
  const totalYears = DASHA_SEQUENCE.find((d) => d.lord === nak.lord)!.years;
  const balanceYears = totalYears * (1 - traversedFraction);

  return {
    moonLongitude,
    nakshatraIndex,
    nakshatraName: nak.name,
    nakshatraLord: nak.lord,
    pada,
    traversedFraction,
    balanceYears,
  };
}

export function sequenceFrom(lord: DashaLord): { lord: DashaLord; years: number }[] {
  const idx = DASHA_SEQUENCE.findIndex((d) => d.lord === lord);
  return DASHA_SEQUENCE.map((_, i) => DASHA_SEQUENCE[(idx + i) % 9]);
}

export function buildDashaChildren(
  parentLord: DashaLord,
  parentStart: Date,
  parentMs: number,
  parentLevel: DashaLevel,
): DashaPeriod[] {
  if (parentLevel >= 5) return [];
  const seq = sequenceFrom(parentLord);
  const children: DashaPeriod[] = [];
  let cursor = parentStart.getTime();
  const childLevel = (parentLevel + 1) as DashaLevel;

  for (const item of seq) {
    const portion = (item.years / TOTAL_YEARS) * parentMs;
    const start = new Date(cursor);
    const end = new Date(cursor + portion);
    const node: DashaPeriod = {
      lord: item.lord,
      level: childLevel,
      start,
      end,
      durationMs: portion,
    };
    if (childLevel < 5) {
      node.children = buildDashaChildren(item.lord, start, portion, childLevel);
    }
    children.push(node);
    cursor = end.getTime();
  }
  return children;
}

export type VimshottariResult = {
  moon: MoonNakshatraInfo;
  birth: Date;
  /** Dasha chain starting from the Moon's nakshatra lord, anchored at birth. */
  mahadashas: DashaPeriod[];
  /** Sequence of periods running at `now` (Maha → Pran). */
  activePath: DashaPeriod[];
  /** Elapsed part of the first Mahadasha before birth (Bhukta kal). */
  bhuktaAtBirthMs: number;
  /** Remaining part of the first Mahadasha at birth (Bhogya kal). */
  bhogyaAtBirthMs: number;
};

/**
 * VIMSHOTTARI GANANA — विधि:
 *
 * 1) देखिए चन्द्रमा किस नक्षत्र में है।
 * 2) उस नक्षत्र का स्वामी ही जन्म की पहली महादशा का स्वामी होगा।
 * 3) चन्द्रमा अपने नक्षत्र से कितना आगे बढ़ चुका है, उसी अनुपात से उस
 *    महादशा का **भुक्त काल** (बीता हुआ) निकलता है और शेष **भोग्य काल**:
 *        bhukta = total × (traversed / 13°20′)
 *        bhogya = total − bhukta
 * 4) **भोग्य काल को जन्म-तिथि में जोड़ा जाता है** — अर्थात् पहली महादशा का
 *    अंत = DOB + bhogya. इसी से आगे की सभी महादशाएँ क्रम में चलती हैं।
 *    (DOB में केवल शेष/भोग्य काल जुड़ता है, पूरी दशा नहीं।)
 */
export function computeVimshottari(chart: Chart, birth: Date, now = new Date()): VimshottariResult {
  const moon = moonNakshatra(chart);
  const seq = sequenceFrom(moon.nakshatraLord);

  const firstLord = seq[0].lord; // = Moon's nakshatra lord
  const firstTotalMs = seq[0].years * YEAR_MS;

  // Step 3 — Bhukta & Bhogya from how far Moon has moved into its nakshatra.
  const bhuktaAtBirthMs = firstTotalMs * moon.traversedFraction;
  const bhogyaAtBirthMs = firstTotalMs - bhuktaAtBirthMs;

  // Step 4 — Bhogya kal is ADDED to the date of birth.
  const firstEndMs = birth.getTime() + bhogyaAtBirthMs;
  // The first Mahadasha therefore began BEFORE birth by the Bhukta amount.
  const firstStartMs = firstEndMs - firstTotalMs;

  const mahadashas: DashaPeriod[] = [];

  // First (partial) Mahadasha — children anchored from its own start.
  mahadashas.push({
    lord: firstLord,
    level: 1,
    start: new Date(firstStartMs),
    end: new Date(firstEndMs),
    durationMs: firstTotalMs,
    children: buildDashaChildren(firstLord, new Date(firstStartMs), firstTotalMs, 1),
  });

  // Remaining Mahadashas follow in sequence from the first lord's end.
  let cursor = firstEndMs;
  for (let i = 1; i < seq.length; i++) {
    const item = seq[i];
    const ms = item.years * YEAR_MS;
    const start = new Date(cursor);
    const end = new Date(cursor + ms);
    mahadashas.push({
      lord: item.lord,
      level: 1,
      start,
      end,
      durationMs: ms,
      children: buildDashaChildren(item.lord, start, ms, 1),
    });
    cursor = end.getTime();
  }

  const activePath: DashaPeriod[] = [];
  let level: DashaPeriod[] | undefined = mahadashas;
  while (level) {
    const active: DashaPeriod | undefined = level.find((p) => now >= p.start && now < p.end);
    if (!active) break;
    activePath.push(active);
    level = active.children;
  }

  return {
    moon,
    birth,
    mahadashas,
    activePath,
    bhuktaAtBirthMs,
    bhogyaAtBirthMs,
  };
}

/* ------------------------------ formatting ------------------------------ */

export function formatDate(d: Date): string {
  const dd = String(d.getUTCDate()).padStart(2, "0");
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const yyyy = d.getUTCFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

export function formatDuration(ms: number): string {
  const totalDays = ms / (24 * 3600 * 1000);
  const years = Math.floor(totalDays / YEAR_DAYS);
  const afterYears = totalDays - years * YEAR_DAYS;
  const months = Math.floor(afterYears / (YEAR_DAYS / 12));
  const days = Math.round(afterYears - months * (YEAR_DAYS / 12));
  const parts: string[] = [];
  if (years) parts.push(`${years} वर्ष`);
  if (months) parts.push(`${months} माह`);
  parts.push(`${Math.max(0, days)} दिन`);
  return parts.join(" ");
}

export function bhuktaBhogya(period: DashaPeriod, now: Date) {
  const total = period.durationMs;
  const elapsed = Math.min(Math.max(now.getTime() - period.start.getTime(), 0), total);
  const remaining = total - elapsed;
  return {
    bhuktaMs: elapsed,
    bhogyaMs: remaining,
    bhuktaLabel: formatDuration(elapsed),
    bhogyaLabel: formatDuration(remaining),
    percent: total > 0 ? (elapsed / total) * 100 : 0,
  };
}

export function planetShort(lord: DashaLord): PlanetKey {
  return lord as PlanetKey;
}
