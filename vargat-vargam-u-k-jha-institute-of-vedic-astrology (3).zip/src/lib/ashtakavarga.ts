import { type Chart, type PlanetKey } from "./astro";

/**
 * Bhinnashtakavarga — classical benefic-place (bindu) rules.
 * Each row: contributor reference → set of house positions (1..12)
 * counted from that contributor's natal sign. Verified totals:
 * Sun 48, Moon 49, Mars 39, Mercury 54, Jupiter 56, Venus 52, Saturn 39, Lagna 49.
 * Sarvashtakavarga (including Lagna) = 386.
 */

export type AshtakavargaKey = "Surya" | "Chandra" | "Mangal" | "Budh" | "Guru" | "Shukra" | "Shani" | "Lagna";

const SUN_TABLE: Record<AshtakavargaKey, number[]> = {
  Surya: [1, 2, 4, 7, 8, 9, 10, 11],
  Chandra: [3, 6, 10, 11],
  Mangal: [1, 2, 4, 7, 8, 9, 10, 11],
  Budh: [3, 5, 6, 9, 10, 11, 12],
  Guru: [5, 6, 9, 11],
  Shukra: [6, 7, 12],
  Shani: [1, 2, 4, 7, 8, 9, 10, 11],
  Lagna: [3, 4, 6, 10, 11, 12],
};

const MOON_TABLE: Record<AshtakavargaKey, number[]> = {
  Surya: [3, 6, 7, 8, 10, 11],
  Chandra: [1, 3, 6, 7, 10, 11],
  Mangal: [2, 3, 5, 6, 9, 10, 11],
  Budh: [1, 3, 4, 5, 7, 8, 10, 11],
  Guru: [1, 4, 7, 8, 10, 11, 12],
  Shukra: [3, 4, 5, 7, 9, 10, 11],
  Shani: [3, 5, 6, 11],
  Lagna: [3, 6, 10, 11],
};

const MARS_TABLE: Record<AshtakavargaKey, number[]> = {
  Surya: [3, 5, 6, 10, 11],
  Chandra: [3, 6, 11],
  Mangal: [1, 2, 4, 7, 8, 10, 11],
  Budh: [3, 5, 6, 11],
  Guru: [6, 10, 11, 12],
  Shukra: [6, 8, 11, 12],
  Shani: [1, 4, 7, 8, 9, 10, 11],
  Lagna: [1, 3, 6, 10, 11],
};

const MERCURY_TABLE: Record<AshtakavargaKey, number[]> = {
  Surya: [5, 6, 9, 11, 12],
  Chandra: [2, 4, 6, 8, 10, 11],
  Mangal: [1, 2, 4, 7, 8, 9, 10, 11],
  Budh: [1, 3, 5, 6, 9, 10, 11, 12],
  Guru: [6, 8, 11, 12],
  Shukra: [1, 2, 3, 4, 5, 8, 9, 11],
  Shani: [1, 2, 4, 7, 8, 9, 10, 11],
  Lagna: [1, 2, 4, 6, 8, 10, 11],
};

const JUPITER_TABLE: Record<AshtakavargaKey, number[]> = {
  Surya: [1, 2, 3, 4, 7, 8, 9, 10, 11],
  Chandra: [2, 5, 7, 9, 11],
  Mangal: [1, 2, 4, 7, 8, 10, 11],
  Budh: [1, 2, 4, 5, 6, 9, 10, 11],
  Guru: [1, 2, 3, 4, 7, 8, 10, 11],
  Shukra: [2, 5, 6, 9, 10, 11],
  Shani: [3, 5, 6, 12],
  Lagna: [1, 2, 4, 5, 6, 7, 9, 10, 11],
};

const VENUS_TABLE: Record<AshtakavargaKey, number[]> = {
  Surya: [8, 11, 12],
  Chandra: [1, 2, 3, 4, 5, 8, 9, 11, 12],
  Mangal: [3, 5, 6, 9, 11, 12],
  Budh: [3, 5, 6, 9, 11],
  Guru: [5, 8, 9, 10, 11],
  Shukra: [1, 2, 3, 4, 5, 8, 9, 10, 11],
  Shani: [3, 4, 5, 8, 9, 10, 11],
  Lagna: [1, 2, 3, 4, 5, 8, 9, 11],
};

const SATURN_TABLE: Record<AshtakavargaKey, number[]> = {
  Surya: [1, 2, 4, 7, 8, 10, 11],
  Chandra: [3, 6, 11],
  Mangal: [3, 5, 6, 10, 11, 12],
  Budh: [6, 8, 9, 10, 11, 12],
  Guru: [5, 6, 11, 12],
  Shukra: [6, 11, 12],
  Shani: [3, 5, 6, 11],
  Lagna: [1, 3, 4, 6, 10, 11],
};

const LAGNA_TABLE: Record<AshtakavargaKey, number[]> = {
  Surya: [3, 4, 6, 10, 11, 12],
  Chandra: [3, 6, 10, 11, 12],
  Mangal: [1, 3, 6, 10, 11],
  Budh: [1, 2, 4, 6, 8, 10, 11],
  Guru: [1, 2, 4, 5, 6, 7, 9, 10, 11],
  Shukra: [1, 2, 3, 4, 5, 8, 9],
  Shani: [1, 3, 4, 6, 10, 11],
  Lagna: [3, 6, 10, 11],
};

const TABLES: Record<AshtakavargaKey, Record<AshtakavargaKey, number[]>> = {
  Surya: SUN_TABLE,
  Chandra: MOON_TABLE,
  Mangal: MARS_TABLE,
  Budh: MERCURY_TABLE,
  Guru: JUPITER_TABLE,
  Shukra: VENUS_TABLE,
  Shani: SATURN_TABLE,
  Lagna: LAGNA_TABLE,
};

/** Strict Prastara/Kakshya row order requested for every table. */
export const KAKSHYA_ORDER: AshtakavargaKey[] = [
  "Shani",
  "Guru",
  "Mangal",
  "Surya",
  "Shukra",
  "Budh",
  "Chandra",
  "Lagna",
];

export const CLASSICAL_BAV_TOTALS: Record<AshtakavargaKey, number> = {
  Surya: 48,
  Chandra: 49,
  Mangal: 39,
  Budh: 54,
  Guru: 56,
  Shukra: 52,
  Shani: 39,
  Lagna: 49,
};

export const BAV_KEYS: AshtakavargaKey[] = [
  "Surya",
  "Chandra",
  "Mangal",
  "Budh",
  "Guru",
  "Shukra",
  "Shani",
  "Lagna",
];

/** Reference point key → natal sign number. */
type ReferenceSigns = Record<AshtakavargaKey, number>;

function referenceSigns(chart: Chart): ReferenceSigns {
  return {
    Surya: chart.Surya.sign,
    Chandra: chart.Chandra.sign,
    Mangal: chart.Mangal.sign,
    Budh: chart.Budh.sign,
    Guru: chart.Guru.sign,
    Shukra: chart.Shukra.sign,
    Shani: chart.Shani.sign,
    Lagna: chart.Lagna.sign,
  };
}

/**
 * Compute one Bhinnashtakavarga (12 signs, each 0..8 bindus).
 * result[sign-1] = bindu count in that sign.
 */
export function computeBhinnashtakavarga(chart: Chart, key: AshtakavargaKey): number[] {
  const refs = referenceSigns(chart);
  const table = TABLES[key];
  const out = new Array(12).fill(0);
  (Object.keys(table) as AshtakavargaKey[]).forEach((contributor) => {
    const base = refs[contributor];
    for (const house of table[contributor]) {
      const sign = ((base - 1 + (house - 1)) % 12) + 1;
      out[sign - 1] += 1;
    }
  });
  return out;
}

export type PrastaraTable = {
  target: AshtakavargaKey;
  /** One 12-sign binary row for each of the 8 contributors. */
  rows: Record<AshtakavargaKey, number[]>;
  rowTotals: Record<AshtakavargaKey, number>;
  signTotals: number[];
  grandTotal: number;
  expectedTotal: number;
  verified: boolean;
};

/** Compute the complete 8-contributor binary Prastarashtakavarga matrix. */
export function computePrastarashtakavarga(
  chart: Chart,
  target: AshtakavargaKey,
): PrastaraTable {
  const refs = referenceSigns(chart);
  const rules = TABLES[target];
  const rows = {} as Record<AshtakavargaKey, number[]>;
  const rowTotals = {} as Record<AshtakavargaKey, number>;
  const signTotals = new Array(12).fill(0) as number[];

  for (const contributor of KAKSHYA_ORDER) {
    const row = new Array(12).fill(0) as number[];
    const baseSign = refs[contributor];
    for (const relativeHouse of rules[contributor]) {
      const receivingSign = ((baseSign - 1 + (relativeHouse - 1)) % 12) + 1;
      row[receivingSign - 1] = 1;
    }
    rows[contributor] = row;
    rowTotals[contributor] = row.reduce((sum, value) => sum + value, 0);
    for (let i = 0; i < 12; i++) signTotals[i] += row[i];
  }

  const grandTotal = signTotals.reduce((sum, value) => sum + value, 0);
  const expectedTotal = CLASSICAL_BAV_TOTALS[target];
  return {
    target,
    rows,
    rowTotals,
    signTotals,
    grandTotal,
    expectedTotal,
    verified: grandTotal === expectedTotal,
  };
}

export type AshtakavargaResult = {
  bav: Record<AshtakavargaKey, number[]>;
  prastara: Record<AshtakavargaKey, PrastaraTable>;
  totals: Record<AshtakavargaKey, number>;
  sarva: number[]; // 12 signs, 0..(8*8)
  sarvaTotal: number; // always 386 (337 planets + 49 lagna)
  planetTotal: number; // 337
};

export function computeAshtakavarga(chart: Chart): AshtakavargaResult {
  const bav = {} as Record<AshtakavargaKey, number[]>;
  const prastara = {} as Record<AshtakavargaKey, PrastaraTable>;
  const totals = {} as Record<AshtakavargaKey, number>;
  const sarva = new Array(12).fill(0);

  for (const key of BAV_KEYS) {
    const table = computePrastarashtakavarga(chart, key);
    prastara[key] = table;
    bav[key] = table.signTotals;
    totals[key] = table.grandTotal;
    for (let i = 0; i < 12; i++) sarva[i] += table.signTotals[i];
  }

  return {
    bav,
    prastara,
    totals,
    sarva,
    sarvaTotal: sarva.reduce((a, b) => a + b, 0),
    planetTotal: BAV_KEYS.filter((k) => k !== "Lagna").reduce((a, k) => a + totals[k], 0),
  };
}

export const BAV_LABELS: Record<AshtakavargaKey, string> = {
  Surya: "Surya",
  Chandra: "Chandra",
  Mangal: "Mangal",
  Budh: "Budh",
  Guru: "Guru",
  Shukra: "Shukra",
  Shani: "Shani",
  Lagna: "Lagna",
};

export const BAV_DISPLAY: Record<AshtakavargaKey, string> = {
  Surya: "Surya (Sun)",
  Chandra: "Chandra (Moon)",
  Mangal: "Mangal (Mars)",
  Budh: "Budh (Mercury)",
  Guru: "Guru (Jupiter)",
  Shukra: "Shukra (Venus)",
  Shani: "Shani (Saturn)",
  Lagna: "Lagna (Ascendant)",
};

/** Map planet keys used elsewhere to Ashtakavarga keys. */
export function planetToBavKey(key: PlanetKey): AshtakavargaKey {
  return key as AshtakavargaKey;
}
