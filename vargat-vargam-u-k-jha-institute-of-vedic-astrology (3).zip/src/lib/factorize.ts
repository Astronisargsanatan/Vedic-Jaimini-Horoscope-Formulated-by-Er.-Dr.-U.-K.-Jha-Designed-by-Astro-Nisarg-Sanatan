export const ALLOWED_FACTORS = [2, 3, 4, 5, 6, 8, 9, 10] as const;

export type LayerResult = {
  layer: number;
  total: number;
  combos: number[][];
  truncated: boolean;
};

export type FactorReport = {
  input: number;
  valid: boolean;
  error?: string;
  layers: LayerResult[];
  grandTotal: number;
  maxLayer: number;
  totalGenerated: number;
};

/** Exact count of ordered factorizations of n into exactly k allowed factors. */
function makeCounter() {
  const memo = new Map<string, number>();
  const count = (n: number, k: number): number => {
    if (k === 0) return n === 1 ? 1 : 0;
    if (n === 1) return 0; // no factor equals 1
    const key = n + ":" + k;
    const hit = memo.get(key);
    if (hit !== undefined) return hit;
    let sum = 0;
    for (const f of ALLOWED_FACTORS) {
      if (n % f === 0) sum += count(n / f, k - 1);
    }
    memo.set(key, sum);
    return sum;
  };
  return count;
}

/** Enumerate (up to `cap`) ordered factorizations of n into exactly k factors. */
function enumerate(n: number, k: number, cap: number): { combos: number[][]; truncated: boolean } {
  const out: number[][] = [];
  let truncated = false;
  const path: number[] = [];

  const dfs = (rest: number, depth: number) => {
    if (out.length >= cap) {
      truncated = true;
      return;
    }
    if (depth === k) {
      if (rest === 1) out.push(path.slice());
      return;
    }
    for (const f of ALLOWED_FACTORS) {
      if (rest % f !== 0) continue;
      path.push(f);
      dfs(rest / f, depth + 1);
      path.pop();
      if (out.length >= cap) {
        truncated = true;
        return;
      }
    }
  };

  dfs(n, 0);
  return { combos: out, truncated };
}

export function analyze(input: number, perLayerCap = 400): FactorReport {
  const empty: FactorReport = {
    input,
    valid: false,
    layers: [],
    grandTotal: 0,
    maxLayer: 0,
    totalGenerated: 0,
  };

  if (!Number.isFinite(input) || !Number.isInteger(input)) {
    return { ...empty, error: "Please enter a whole number." };
  }
  if (input < 2) {
    return { ...empty, error: "The smallest reachable product is 2 × 2 = 4." };
  }
  if (input > 50_000_000) {
    return { ...empty, error: "Please keep the number at or below 50,000,000." };
  }

  const count = makeCounter();
  const maxLayer = Math.floor(Math.log2(input) + 1e-9);
  const layers: LayerResult[] = [];
  let grandTotal = 0;
  let totalGenerated = 0;

  for (let k = 2; k <= maxLayer; k++) {
    const total = count(input, k);
    if (total === 0) continue;
    grandTotal += total;
    const { combos, truncated } = enumerate(input, k, perLayerCap);
    totalGenerated += combos.length;
    layers.push({ layer: k, total, combos, truncated: truncated || combos.length < total });
  }

  return {
    input,
    valid: true,
    layers,
    grandTotal,
    maxLayer: layers.length ? layers[layers.length - 1].layer : 0,
    totalGenerated,
  };
}

/** 30° = 30 × 60 × 60 = 108,000 seconds */
export const SECONDS_PER_SIGN = 108000;

export type ExactDivision = {
  possible: boolean;
  total: number;
  quotientSeconds: number;
  remainderSeconds: number;
  display: string;
  reason: string;
};

/**
 * Varga Engineering exactness rule:
 * 30° must divide into the final division (D[Total]) into WHOLE seconds.
 * 30° = 108000″. D[Total] is possible only when 108000 % Total === 0.
 * e.g. D81 → 108000 ÷ 81 = 1333.33″ → 22′ 13″ + ⅓″ remainder → NOT POSSIBLE.
 */
export function exactDivision(total: number): ExactDivision {
  const q = Math.floor(SECONDS_PER_SIGN / total);
  const r = SECONDS_PER_SIGN - q * total;
  const deg = Math.floor(q / 3600);
  const min = Math.floor((q % 3600) / 60);
  const sec = q % 60;
  const display = `${deg}° ${String(min).padStart(2, "0")}′ ${String(sec).padStart(2, "0")}″`;

  return {
    possible: r === 0,
    total,
    quotientSeconds: q,
    remainderSeconds: r,
    display,
    reason:
      r === 0
        ? `30° ÷ D${total} = ${display} — exact to the second.`
        : `30° = 108000″; 108000″ ÷ ${total} = ${display} plus ${r}″ remainder (${(r / total).toFixed(4)}″ each) — cannot divide to a whole second.`,
  };
}

export function primeFactorString(n: number): string {
  let x = n;
  const parts: string[] = [];
  for (let p = 2; p * p <= x; p++) {
    let e = 0;
    while (x % p === 0) {
      x /= p;
      e++;
    }
    if (e) parts.push(e === 1 ? `${p}` : `${p}^${e}`);
  }
  if (x > 1) parts.push(`${x}`);
  return parts.join(" · ");
}

const ORDINAL = (k: number) => `${k}-LAYER`;

export function buildTextReport(report: FactorReport): string {
  const lines: string[] = [];
  lines.push(`**INPUT NUMBER: ${report.input}**`);
  lines.push("");

  if (!report.valid) {
    lines.push(report.error ?? "Invalid input.");
    return lines.join("\n");
  }

  if (report.layers.length === 0) {
    lines.push("No valid combinations exist using only 2, 3, 4, 5, 6, 8, 9, 10.");
    lines.push("");
    lines.push("### FINAL TOTAL");
    lines.push("");
    lines.push("**Total Valid Combinations: 0**");
    return lines.join("\n");
  }

  for (const layer of report.layers) {
    lines.push(`### ${ORDINAL(layer.layer)}`);
    lines.push("");
    layer.combos.forEach((combo, i) => {
      lines.push(`${i + 1}. ${combo.join(" × ")} = ${report.input}`);
    });
    if (layer.truncated) {
      lines.push(`… (${layer.total - layer.combos.length} more not listed)`);
    }
    lines.push("");
    lines.push(`**Total ${layer.layer}-Layer: ${layer.total}**`);
    lines.push("");
  }

  lines.push("### FINAL TOTAL");
  lines.push("");
  lines.push(`**Total Valid Combinations: ${report.grandTotal}**`);
  return lines.join("\n");
}
