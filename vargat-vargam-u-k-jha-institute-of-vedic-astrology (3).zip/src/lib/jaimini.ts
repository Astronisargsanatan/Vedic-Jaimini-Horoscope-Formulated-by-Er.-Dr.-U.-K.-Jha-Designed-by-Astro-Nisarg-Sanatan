import { PLANETS, formatDMS, type Chart, type PlanetKey, type Position } from "./astro";

export const JAIMINI_PLANETS: PlanetKey[] = [
  "Surya",
  "Chandra",
  "Mangal",
  "Budh",
  "Guru",
  "Shukra",
  "Shani",
];

export type KarakaRole = "AK" | "AmK" | "BK" | "MK" | "PK" | "GK" | "DK";

export type KarakaMeta = {
  role: KarakaRole;
  devanagari: string;
  sanskrit: string;
  english: string;
  significance: string;
  color: string;
};

export const KARAKA_HIERARCHY: KarakaMeta[] = [
  {
    role: "AK",
    devanagari: "आत्मकारक",
    sanskrit: "Atmakaraka",
    english: "Self / Soul / Core Destiny",
    significance: "Represents the Soul, self-identity, spiritual purpose and primary destiny.",
    color: "bg-[#7c2d12] text-amber-50 border-[#7c2d12]",
  },
  {
    role: "AmK",
    devanagari: "अमात्यकारक",
    sanskrit: "Amatyakaraka",
    english: "Mind / Career / Advisor",
    significance: "Represents profession, intellect, key advisors, achievements and worldly actions.",
    color: "bg-indigo-800 text-indigo-50 border-indigo-900",
  },
  {
    role: "BK",
    devanagari: "भ्रातृकारक",
    sanskrit: "Bhratrukaraka",
    english: "Siblings / Courage / Mentor",
    significance: "Represents siblings, courage, efforts, mentors, advisors and spiritual guides.",
    color: "bg-amber-700 text-amber-50 border-amber-800",
  },
  {
    role: "MK",
    devanagari: "मातृकारक",
    sanskrit: "Matrukaraka",
    english: "Mother / Home / Comforts",
    significance: "Represents mother, emotional security, landed properties, vehicles and peace of mind.",
    color: "bg-emerald-800 text-emerald-50 border-emerald-900",
  },
  {
    role: "PK",
    devanagari: "पुत्रकारक",
    sanskrit: "Putrakaraka",
    english: "Progeny / Intelligence / Talents",
    significance: "Represents children, wisdom, education, ancient merit (Purva Punya) and creative talents.",
    color: "bg-purple-800 text-purple-50 border-purple-900",
  },
  {
    role: "GK",
    devanagari: "ज्ञातिकारक",
    sanskrit: "Gnatikaraka",
    english: "Kinsmen / Obstacles / Competition",
    significance: "Represents relatives, rivals, disease, debts, struggles and overcoming adversity.",
    color: "bg-rose-800 text-rose-50 border-rose-900",
  },
  {
    role: "DK",
    devanagari: "दाराकारक",
    sanskrit: "Darakaraka",
    english: "Spouse / Partner / Relationships",
    significance: "Represents marriage partner, business associates, public interactions and worldly union.",
    color: "bg-teal-800 text-teal-50 border-teal-900",
  },
];

export type JaiminiPlanetResult = {
  key: PlanetKey;
  label: string;
  short: string;
  position: Position;
  localDMS: string;
  totalSeconds: number;
  navamshaNum: number; // 1 to 9
  navamshaStartSeconds: number;
  navamshaStartDMS: string;
  traversedSeconds: number;
  traversedDMS: string;
  karaka: KarakaMeta;
  rank: number; // 1 to 7
};

export function calculateNavamshaTraversed(pos: Position) {
  const totalSeconds = pos.deg * 3600 + pos.min * 60 + pos.sec;
  const navamshaSpanSeconds = 12000; // 3° 20' 00" = 3*3600 + 20*60 = 12000 seconds
  const navamshaIndex = Math.min(8, Math.floor(totalSeconds / navamshaSpanSeconds));
  const navamshaNum = navamshaIndex + 1;
  const navamshaStartSeconds = navamshaIndex * navamshaSpanSeconds;

  const startDeg = Math.floor(navamshaStartSeconds / 3600);
  const startRem = navamshaStartSeconds % 3600;
  const startMin = Math.floor(startRem / 60);
  const startSec = startRem % 60;
  const navamshaStartDMS = `${startDeg}° ${String(startMin).padStart(2, "0")}′ ${String(
    startSec,
  ).padStart(2, "0")}″`;

  const traversedSeconds = totalSeconds - navamshaStartSeconds;
  const travDeg = Math.floor(traversedSeconds / 3600);
  const travRem = traversedSeconds % 3600;
  const travMin = Math.floor(travRem / 60);
  const travSec = travRem % 60;
  const traversedDMS = `${travDeg}° ${String(travMin).padStart(2, "0")}′ ${String(
    travSec,
  ).padStart(2, "0")}″`;

  return {
    totalSeconds,
    navamshaNum,
    navamshaStartSeconds,
    navamshaStartDMS,
    traversedSeconds,
    traversedDMS,
  };
}

export function computeJaiminiCharKaraka(chart: Chart): JaiminiPlanetResult[] {
  // 1. Extract 7 planets and compute Navamsha traversed for each
  const rawList = JAIMINI_PLANETS.map((key) => {
    const pMeta = PLANETS.find((p) => p.key === key)!;
    const pos = chart[key];
    const calc = calculateNavamshaTraversed(pos);
    return {
      key,
      label: pMeta.label,
      short: pMeta.short,
      position: pos,
      localDMS: formatDMS(pos),
      ...calc,
    };
  });

  // 2. Sort descending by traversedSeconds
  const sorted = [...rawList].sort((a, b) => b.traversedSeconds - a.traversedSeconds);

  // 3. Assign Karaka hierarchy
  return sorted.map((item, index) => ({
    ...item,
    rank: index + 1,
    karaka: KARAKA_HIERARCHY[index],
  }));
}
