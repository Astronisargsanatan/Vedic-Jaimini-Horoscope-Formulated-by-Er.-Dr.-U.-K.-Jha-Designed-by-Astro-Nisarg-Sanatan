import { computeArudhaPadas } from "./arudha";
import {
  RASHI_LORDS,
  degWithinSign,
  rashiName,
  type Chart,
  type PlanetKey,
} from "./astro";

export const VISHAMA_PADA_SIGNS = [1, 2, 3, 7, 8, 9] as const;
export const SAMA_PADA_SIGNS = [4, 5, 6, 10, 11, 12] as const;

export type CharaDirection = "Direct" | "Reverse";

export type CharaDuration = {
  totalDays: number;
  totalSeconds: number;
  years: number;
  months: number;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  label: string;
};

export type CharaPeriod = {
  order: number;
  sign: number;
  signName: string;
  classification: "Vishama Pada" | "Sama Pada";
  lord: PlanetKey;
  madhyaLongitude: number;
  madhyaLongitudeDms: string;
  lordLongitude: number;
  lordLongitudeDms: string;
  difference: number;
  differenceDms: string;
  duration: CharaDuration;
  start: Date;
  end: Date;
  formula: string;
  additionProof: string;
};

export type CharaDashaResult = {
  a1Sign: number;
  a9Sign: number;
  direction: CharaDirection;
  lagnaMadhyaDegree: number;
  lagnaMadhyaDms: string;
  sequence: number[];
  periods: CharaPeriod[];
};

function normalizeLongitude(value: number): number {
  return ((value % 360) + 360) % 360;
}

function absoluteLongitude(chart: Chart, planet: PlanetKey): number {
  const position = chart[planet];
  return (position.sign - 1) * 30 + degWithinSign(position);
}

function dms(value: number): string {
  const normalized = normalizeLongitude(value);
  const sign = Math.floor(normalized / 30) + 1;
  const within = normalized - (sign - 1) * 30;
  const totalSeconds = Math.round(within * 3600);
  const degree = Math.floor(totalSeconds / 3600);
  const minute = Math.floor((totalSeconds % 3600) / 60);
  const second = totalSeconds % 60;
  return `${sign}R ${degree}° ${String(minute).padStart(2, "0")}′ ${String(second).padStart(2, "0")}″`;
}

function arcDms(value: number): string {
  let totalSeconds = Math.round(normalizeLongitude(value) * 3600);
  const signs = Math.floor(totalSeconds / (30 * 3600));
  totalSeconds -= signs * 30 * 3600;
  const degrees = Math.floor(totalSeconds / 3600);
  totalSeconds -= degrees * 3600;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds - minutes * 60;
  return `${signs} Rashi ${degrees}° ${String(minutes).padStart(2, "0")}′ ${String(seconds).padStart(2, "0")}″`;
}

/** 30° = 365.25 days; 1 month = 30.4375 days. */
function durationFromArc(degrees: number): CharaDuration {
  const totalDays = (degrees / 30) * 365.25;
  const exactTotalSeconds = Math.round(totalDays * 86400);
  let totalSeconds = exactTotalSeconds;

  const yearSeconds = Math.round(365.25 * 86400);
  const monthSeconds = Math.round(30.4375 * 86400);
  const years = Math.floor(totalSeconds / yearSeconds);
  totalSeconds -= years * yearSeconds;
  const months = Math.floor(totalSeconds / monthSeconds);
  totalSeconds -= months * monthSeconds;
  const days = Math.floor(totalSeconds / 86400);
  totalSeconds -= days * 86400;
  const hours = Math.floor(totalSeconds / 3600);
  totalSeconds -= hours * 3600;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds - minutes * 60;

  return {
    totalDays,
    totalSeconds: exactTotalSeconds,
    years,
    months,
    days,
    hours,
    minutes,
    seconds,
    label: `${years}y ${months}m ${days}d ${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`,
  };
}

function buildSequence(startSign: number, direction: CharaDirection): number[] {
  return Array.from({ length: 12 }, (_, index) => {
    const offset = direction === "Direct" ? index : -index;
    return ((startSign - 1 + offset) % 12 + 12) % 12 + 1;
  });
}

export function computeCharaDasha(chart: Chart, birth: Date): CharaDashaResult {
  const arudhas = computeArudhaPadas(chart);
  const a1Sign = arudhas.find((item) => item.label === "AL")!.arudhaSign;
  const a9Sign = arudhas.find((item) => item.label === "A9")!.arudhaSign;
  const direction: CharaDirection = VISHAMA_PADA_SIGNS.includes(a1Sign as never)
    ? "Direct"
    : "Reverse";

  const lagnaMadhyaDegree = degWithinSign(chart.Lagna);
  const lagnaMadhyaDms = `${chart.Lagna.deg}° ${String(chart.Lagna.min).padStart(2, "0")}′ ${String(chart.Lagna.sec).padStart(2, "0")}″`;
  const sequence = buildSequence(a9Sign, direction);

  let cursor = birth.getTime();
  const periods = sequence.map((sign, index): CharaPeriod => {
    const lord = RASHI_LORDS[sign];
    const madhyaLongitude = (sign - 1) * 30 + lagnaMadhyaDegree;
    const lordLongitude = absoluteLongitude(chart, lord);
    const vishama = VISHAMA_PADA_SIGNS.includes(sign as never);
    const difference = normalizeLongitude(
      vishama ? lordLongitude - madhyaLongitude : madhyaLongitude - lordLongitude,
    );
    const duration = durationFromArc(difference);
    const start = new Date(cursor);
    // Exact cumulative addition: first starts at birth; every later period
    // starts at the previous period's exact end, including HH:MM:SS.
    const end = new Date(cursor + duration.totalSeconds * 1000);
    cursor = end.getTime();

    return {
      order: index + 1,
      sign,
      signName: rashiName(sign),
      classification: vishama ? "Vishama Pada" : "Sama Pada",
      lord,
      madhyaLongitude,
      madhyaLongitudeDms: dms(madhyaLongitude),
      lordLongitude,
      lordLongitudeDms: dms(lordLongitude),
      difference,
      differenceDms: arcDms(difference),
      duration,
      start,
      end,
      formula: vishama
        ? `Lord (${dms(lordLongitude)}) − Madhya (${dms(madhyaLongitude)})`
        : `Madhya (${dms(madhyaLongitude)}) − Lord (${dms(lordLongitude)})`,
      additionProof:
        index === 0
          ? `Birth instant + ${duration.label} = period end`
          : `Previous dasha end + ${duration.label} = period end`,
    };
  });

  return {
    a1Sign,
    a9Sign,
    direction,
    lagnaMadhyaDegree,
    lagnaMadhyaDms,
    sequence,
    periods,
  };
}

export function formatCharaDate(date: Date): string {
  return `${String(date.getUTCDate()).padStart(2, "0")}/${String(date.getUTCMonth() + 1).padStart(2, "0")}/${date.getUTCFullYear()}`;
}

/** Date + exact time for transparent cumulative verification. */
export function formatCharaDateTime(date: Date, timeZone?: string): string {
  const zone = (timeZone ?? "").split(" (")[0];
  if (zone.includes("/")) {
    try {
      return new Intl.DateTimeFormat("en-GB", {
        timeZone: zone,
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hourCycle: "h23",
      })
        .format(date)
        .replace(",", "");
    } catch {
      // Fall through to UTC when the stored zone is not supported.
    }
  }

  const fixedOffset = (timeZone ?? "").match(/(?:UTC|GMT)([+-])(\d{1,2}):(\d{2})/);
  if (fixedOffset) {
    const offsetMinutes =
      (fixedOffset[1] === "-" ? -1 : 1) *
      (Number(fixedOffset[2]) * 60 + Number(fixedOffset[3]));
    const shifted = new Date(date.getTime() + offsetMinutes * 60000);
    const pad = (value: number) => String(value).padStart(2, "0");
    return `${pad(shifted.getUTCDate())}/${pad(
      shifted.getUTCMonth() + 1,
    )}/${shifted.getUTCFullYear()} ${pad(shifted.getUTCHours())}:${pad(
      shifted.getUTCMinutes(),
    )}:${pad(shifted.getUTCSeconds())} ${fixedOffset[1]}${pad(Number(fixedOffset[2]))}:${fixedOffset[3]}`;
  }

  const pad = (value: number) => String(value).padStart(2, "0");
  return `${pad(date.getUTCDate())}/${pad(date.getUTCMonth() + 1)}/${date.getUTCFullYear()} ${pad(
    date.getUTCHours(),
  )}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())} UTC`;
}