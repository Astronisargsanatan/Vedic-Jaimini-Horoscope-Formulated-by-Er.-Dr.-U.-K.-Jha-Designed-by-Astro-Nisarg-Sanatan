import { computeArudhaPadas } from "./arudha";
import { computeAshtakavarga } from "./ashtakavarga";
import { computeAarshaVimshottari } from "./aarshaVimshottari";
import { computeCharaDasha } from "./charaDasha";
import { computeJaiminiCharKaraka } from "./jaimini";
import { computeMandookDasha } from "./mandookDasha";
import { computeMuktashtakiDasha } from "./muktashtakiDasha";
import { computeVimshottari, LORD_HINDI } from "./vimshottari";
import {
  DASHVARGA_IDS,
  RASHI_LORDS,
  computeVarga,
  houseOf,
  rashiName,
  type Chart,
  type ChartSigns,
  type PlanetKey,
} from "./astro";
import type { NativeInfo } from "../state/ChartContext";

export type PredictionLagna = {
  key: "Janma" | "Chandra" | "Surya" | "Arudha" | "Karakamsha";
  hindi: string;
  sign: number;
  significance: string;
};

export type BhavaPrediction = {
  bhava: number;
  title: string;
  themes: string;
  janmaSign: number;
  lord: PlanetKey;
  lordHouse: number;
  karaka: PlanetKey[];
  arudhaLabel: string;
  arudhaSign: number;
  savBindus: number;
  fiveLagnaSigns: number[];
  supportingLagnas: number;
  vargaRepetition: number;
  strength: "प्रबल" | "मध्यम" | "परिश्रम-साध्य";
  prediction: string;
};

export type ActiveDashaSummary = {
  system: string;
  active: string;
  indication: string;
};

export type PredictionResult = {
  atmakaraka: PlanetKey;
  atmakarakaSign: number;
  atmakarakaText: string;
  lagnas: PredictionLagna[];
  bhavas: BhavaPrediction[];
  dashas: ActiveDashaSummary[];
  dominantSigns: { sign: number; count: number; sources: string[] }[];
  synthesis: string[];
};

const BHAVA_META: Record<number, { title: string; themes: string; karaka: PlanetKey[] }> = {
  1: { title: "तनु भाव", themes: "शरीर, स्वभाव, आत्म-छवि, जीवन-दिशा", karaka: ["Surya"] },
  2: { title: "धन भाव", themes: "धन, कुटुम्ब, वाणी, संचय", karaka: ["Guru", "Budh"] },
  3: { title: "पराक्रम भाव", themes: "साहस, संचार, भाई-बहन, प्रयास", karaka: ["Mangal"] },
  4: { title: "सुख भाव", themes: "माता, गृह, भूमि, शिक्षा, मानसिक सुख", karaka: ["Chandra", "Shukra"] },
  5: { title: "पुत्र भाव", themes: "सन्तान, बुद्धि, विद्या, सृजन, पूर्व-पुण्य", karaka: ["Guru"] },
  6: { title: "षष्ठ भाव", themes: "रोग, ऋण, शत्रु, सेवा, प्रतियोगिता", karaka: ["Mangal", "Shani"] },
  7: { title: "कलत्र भाव", themes: "विवाह, साझेदारी, सार्वजनिक व्यवहार", karaka: ["Shukra", "Guru"] },
  8: { title: "आयु भाव", themes: "आयु, परिवर्तन, रहस्य, उत्तराधिकार", karaka: ["Shani"] },
  9: { title: "भाग्य भाव", themes: "धर्म, भाग्य, गुरु, पिता, उच्च ज्ञान", karaka: ["Guru", "Surya"] },
  10: { title: "कर्म भाव", themes: "कर्म, व्यवसाय, पद, प्रतिष्ठा, उत्तरदायित्व", karaka: ["Surya", "Budh", "Shani"] },
  11: { title: "लाभ भाव", themes: "लाभ, अभिलाषा, मित्र-वृत्त, उपलब्धि", karaka: ["Guru"] },
  12: { title: "व्यय भाव", themes: "व्यय, विदेश, निद्रा, एकान्त, मोक्ष", karaka: ["Shani", "Ketu"] },
};

const AK_TEXT: Partial<Record<PlanetKey, string>> = {
  Surya: "आत्मसम्मान, नेतृत्व, सत्य और अधिकार की साधना जीवन का मूल पाठ बनती है।",
  Chandra: "भावनात्मक परिपक्वता, करुणा, मन की स्थिरता और पोषण आत्म-विकास का केन्द्र है।",
  Mangal: "साहस को संयमित कर्म में बदलना, संघर्ष से कौशल पाना और रक्षा करना आत्म-पथ है।",
  Budh: "विवेक, संवाद, अध्ययन, तर्क और अनुकूलन आत्मा के विकास के प्रमुख साधन हैं।",
  Guru: "धर्म, ज्ञान, मार्गदर्शन, नीति और विस्तार आत्मा की प्रधान प्रेरणा है।",
  Shukra: "सम्बन्ध, सौन्दर्य, सामंजस्य, मूल्य और भोग-वैराग्य का संतुलन आत्म-पाठ है।",
  Shani: "अनुशासन, धैर्य, सेवा, उत्तरदायित्व और समय की परीक्षा आत्म-विकास का मार्ग है।",
};

function signFrom(base: number, bhava: number): number {
  return ((base - 1 + bhava - 1) % 12) + 1;
}

function birthInstant(native: NativeInfo | null): Date {
  if (native?.birthUtc) {
    const exact = new Date(native.birthUtc);
    if (!Number.isNaN(exact.getTime())) return exact;
  }
  const date = (native?.date ?? "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const time = (native?.time ?? "").match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  if (!date) return new Date();
  return new Date(
    Date.UTC(
      Number(date[3]), Number(date[2]) - 1, Number(date[1]),
      time ? Number(time[1]) : 12, time ? Number(time[2]) : 0, time ? Number(time[3] ?? 0) : 0,
    ) - 330 * 60000,
  );
}

function strengthLabel(score: number): BhavaPrediction["strength"] {
  return score >= 6 ? "प्रबल" : score >= 3 ? "मध्यम" : "परिश्रम-साध्य";
}

function bhavaNarrative(
  bhava: number,
  sign: number,
  lord: PlanetKey,
  lordHouse: number,
  sav: number,
  lagnaSupport: number,
  repetition: number,
  strength: BhavaPrediction["strength"],
) {
  const meta = BHAVA_META[bhava];
  const savPhrase = sav >= 32 ? "अष्टकवर्गीय संरक्षण उच्च" : sav >= 28 ? "अष्टकवर्गीय समर्थन संतुलित" : "अष्टकवर्गीय समर्थन को सचेत प्रयास चाहिए";
  const lordPhrase = [1, 4, 7, 10].includes(lordHouse)
    ? "केन्द्र में स्थित भावेश परिणामों को दृश्य और सक्रिय बनाता है"
    : [5, 9].includes(lordHouse)
      ? "त्रिकोणगत भावेश भाग्य और सहज अवसर बढ़ाता है"
      : [6, 8, 12].includes(lordHouse)
        ? "दुष्थानगत भावेश परिणामों को परिवर्तन, सेवा या विलम्ब के बाद देता है"
        : "भावेश क्रमिक प्रयास और सामाजिक व्यवहार से फल देता है";
  return `${meta.title} (${meta.themes}) की राशि ${rashiName(sign)} और भावेश ${lord} जन्म लग्न से ${lordHouse}वें भाव में है। ${lordPhrase}। ${savPhrase} (${sav} बिन्दु)। पाँच लग्नों में ${lagnaSupport} समर्थन और दशवर्ग में ${repetition} पुनरावृत्ति के आधार पर यह क्षेत्र ${strength} है; घटनाएँ सम्बद्ध दशा, गोचर और सक्रिय कारक के समय अधिक स्पष्ट हो सकती हैं।`;
}

export function computePrediction(
  chart: Chart,
  native: NativeInfo | null,
  engineeringSigns: ChartSigns,
): PredictionResult {
  const birth = birthInstant(native);
  const now = new Date();
  const arudhas = computeArudhaPadas(chart);
  const karakas = computeJaiminiCharKaraka(chart);
  const ak = karakas.find((item) => item.karaka.role === "AK")!;
  const d9 = computeVarga(chart, "D9");
  const al = arudhas.find((item) => item.label === "AL")!;
  const lagnas: PredictionLagna[] = [
    { key: "Janma", hindi: "जन्म लग्न", sign: chart.Lagna.sign, significance: "स्थूल जीवन, शरीर और वास्तविक घटनाएँ" },
    { key: "Chandra", hindi: "चन्द्र लग्न", sign: chart.Chandra.sign, significance: "मन, अनुभव और भावनात्मक प्रतिक्रिया" },
    { key: "Surya", hindi: "सूर्य लग्न", sign: chart.Surya.sign, significance: "आत्मबल, अधिकार और सार्वजनिक पहचान" },
    { key: "Arudha", hindi: "आरूढ़ लग्न", sign: al.arudhaSign, significance: "दुनिया में दिखाई देने वाली छवि और प्रक्षेपण" },
    { key: "Karakamsha", hindi: "कारकांश लग्न", sign: d9[ak.key], significance: "D9 में आत्मकारक की राशि को D1 में प्रथम भाव मानकर; ग्रह D1 राशियों में यथावत" },
  ];

  const av = computeAshtakavarga(chart);
  const generated = DASHVARGA_IDS.map((id) => computeVarga(chart, id));
  const bhavas = Array.from({ length: 12 }, (_, index): BhavaPrediction => {
    const bhava = index + 1;
    const janmaSign = signFrom(chart.Lagna.sign, bhava);
    const lord = RASHI_LORDS[janmaSign];
    const lordHouse = houseOf(chart[lord].sign, chart.Lagna.sign);
    const pada = arudhas.find((item) => item.bhava === bhava)!;
    const fiveLagnaSigns = lagnas.map((lagna) => signFrom(lagna.sign, bhava));
    const supportingLagnas = fiveLagnaSigns.filter((value) => value === janmaSign).length;
    const vargaRepetition = [
      ...generated.map((varga) => varga[lord]),
      engineeringSigns[lord],
    ].filter((value) => value === chart[lord].sign).length;
    const savBindus = av.sarva[janmaSign - 1];
    const numericStrength =
      (savBindus >= 32 ? 4 : savBindus >= 28 ? 2 : 0) +
      supportingLagnas +
      Math.min(3, vargaRepetition) +
      ([1, 4, 5, 7, 9, 10].includes(lordHouse) ? 2 : 0);
    const strength = strengthLabel(numericStrength);
    return {
      bhava,
      title: BHAVA_META[bhava].title,
      themes: BHAVA_META[bhava].themes,
      janmaSign,
      lord,
      lordHouse,
      karaka: BHAVA_META[bhava].karaka,
      arudhaLabel: pada.label,
      arudhaSign: pada.arudhaSign,
      savBindus,
      fiveLagnaSigns,
      supportingLagnas,
      vargaRepetition,
      strength,
      prediction: bhavaNarrative(
        bhava, janmaSign, lord, lordHouse, savBindus, supportingLagnas,
        vargaRepetition, strength,
      ),
    };
  });

  const vim = computeVimshottari(chart, birth, now);
  const aarsha = computeAarshaVimshottari(chart, birth, now);
  const chara = computeCharaDasha(chart, birth);
  const mandook = computeMandookDasha(chart, birth, now);
  const mukta = computeMuktashtakiDasha(chart, birth, now);
  const activeChara = chara.periods.find((period) => now >= period.start && now < period.end);
  const dashas: ActiveDashaSummary[] = [
    {
      system: "प्रचलित यवन विंशोत्तरी",
      active: vim.activePath.map((period) => LORD_HINDI[period.lord]).join(" → ") || "चक्र-बाह्य",
      indication: "सक्रिय ग्रहों के भाव, स्वामित्व, कारकत्व और दशवर्ग स्थिति से घटनाएँ परिपक्व होती हैं।",
    },
    {
      system: "ऋषि प्रणीत आर्ष विंशोत्तरी",
      active: aarsha.activePath.map((period) => LORD_HINDI[period.lord]).join(" → ") || "चक्र-बाह्य",
      indication: `${aarsha.cycle} चक्र; triggering planet ${aarsha.triggeringPlanet}, प्रथम दशा ${aarsha.firstDashaLord}।`,
    },
    {
      system: "जैमिनि चर दशा",
      active: activeChara ? `${activeChara.sign}. ${activeChara.signName}` : "चक्र-बाह्य",
      indication: `A9 से ${chara.direction === "Direct" ? "सीधा" : "विपरीत"} क्रम; सक्रिय राशि के ग्रह और आरूढ़ फल प्रमुख।`,
    },
    {
      system: "मण्डूक दशा",
      active: mandook.activeMaha
        ? `${mandook.activeMaha.sign}. ${rashiName(mandook.activeMaha.sign)}${mandook.activeBhukti ? ` / ${mandook.activeBhukti.sign}. ${rashiName(mandook.activeBhukti.sign)}` : ""}`
        : "चक्र-बाह्य",
      indication: "सक्रिय राशि, उसकी त्रिकोण/केन्द्र शक्ति और 6→7 junction परिवर्तनकारी घटनाएँ दिखाते हैं।",
    },
    {
      system: "मुक्ताष्टकी दशा",
      active: mukta.activeMaha
        ? `${mukta.activeMaha.sign}. ${rashiName(mukta.activeMaha.sign)}`
        : "चक्र-बाह्य",
      indication: "SAV bindu-ranked institutional timing; उच्च बिन्दु वाली राशियों के विषय पहले उभरते हैं।",
    },
  ];

  const dominantMap = new Map<number, string[]>();
  for (const lagna of lagnas) {
    dominantMap.set(lagna.sign, [...(dominantMap.get(lagna.sign) ?? []), lagna.hindi]);
  }
  const dominantSigns = Array.from(dominantMap.entries())
    .map(([sign, sources]) => ({ sign, count: sources.length, sources }))
    .sort((a, b) => b.count - a.count || a.sign - b.sign);

  return {
    atmakaraka: ak.key,
    atmakarakaSign: chart[ak.key].sign,
    atmakarakaText: AK_TEXT[ak.key] ?? "आत्मिक विकास ग्रह के कारकत्व के परिष्कार से होता है।",
    lagnas,
    bhavas,
    dashas,
    dominantSigns,
    synthesis: [
      `आत्मकारक ${ak.key} ${rashiName(chart[ak.key].sign)} राशि में है: ${AK_TEXT[ak.key]}`,
      `जन्म लग्न ${rashiName(chart.Lagna.sign)}, चन्द्र लग्न ${rashiName(chart.Chandra.sign)}, सूर्य लग्न ${rashiName(chart.Surya.sign)}, आरूढ़ लग्न ${rashiName(al.arudhaSign)} और कारकांश ${rashiName(d9[ak.key])} का संयुक्त अध्ययन मूल आधार है। कारकांश में केवल D1 भाव-reference बदलता है, ग्रह D1 की मूल राशियों में ही रहते हैं।`,
      "किसी मुख्य घटना का समय तभी पुष्ट माना गया है जब Bhava–Bhavesh–Karaka, संबंधित Arudha Pada, Dashvarga और एक से अधिक सक्रिय Dasha संकेत एक दिशा में हों।",
    ],
  };
}
