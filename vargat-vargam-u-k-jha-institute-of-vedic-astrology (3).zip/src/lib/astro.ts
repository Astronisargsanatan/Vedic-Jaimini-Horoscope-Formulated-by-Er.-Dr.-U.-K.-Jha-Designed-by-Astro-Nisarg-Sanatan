export const RASHIS = [
  { num: 1, name: "Mesha", en: "Aries" },
  { num: 2, name: "Vrishabha", en: "Taurus" },
  { num: 3, name: "Mithuna", en: "Gemini" },
  { num: 4, name: "Karka", en: "Cancer" },
  { num: 5, name: "Simha", en: "Leo" },
  { num: 6, name: "Kanya", en: "Virgo" },
  { num: 7, name: "Tula", en: "Libra" },
  { num: 8, name: "Vrishchika", en: "Scorpio" },
  { num: 9, name: "Dhanu", en: "Sagittarius" },
  { num: 10, name: "Makara", en: "Capricorn" },
  { num: 11, name: "Kumbha", en: "Aquarius" },
  { num: 12, name: "Meena", en: "Pisces" },
] as const;

export const PLANETS = [
  { key: "Lagna", label: "Lagna", short: "La" },
  { key: "Surya", label: "Surya (Sun)", short: "Su" },
  { key: "Chandra", label: "Chandra (Moon)", short: "Ch" },
  { key: "Mangal", label: "Mangal (Mars)", short: "Ma" },
  { key: "Budh", label: "Budh (Mercury)", short: "Bu" },
  { key: "Guru", label: "Guru (Jupiter)", short: "Gu" },
  { key: "Shukra", label: "Shukra (Venus)", short: "Sk" },
  { key: "Shani", label: "Shani (Saturn)", short: "Sa" },
  { key: "Rahu", label: "Rahu", short: "Ra" },
  { key: "Ketu", label: "Ketu", short: "Ke" },
] as const;

export type PlanetKey = (typeof PLANETS)[number]["key"];

export type Position = {
  sign: number; // 1..12
  deg: number; // 0..29
  min: number; // 0..59
  sec: number; // 0..59
  motion?: "D" | "R";
};

export type Chart = Record<PlanetKey, Position>;

export const DEFAULT_CHART: Chart = {
  Lagna: { sign: 1, deg: 12, min: 30, sec: 0 },
  Surya: { sign: 5, deg: 8, min: 15, sec: 0 },
  Chandra: { sign: 9, deg: 22, min: 40, sec: 0 },
  Mangal: { sign: 3, deg: 4, min: 10, sec: 0 },
  Budh: { sign: 5, deg: 19, min: 55, sec: 0 },
  Guru: { sign: 11, deg: 27, min: 5, sec: 0 },
  Shukra: { sign: 6, deg: 2, min: 45, sec: 0 },
  Shani: { sign: 10, deg: 16, min: 20, sec: 0 },
  Rahu: { sign: 2, deg: 11, min: 0, sec: 0 },
  Ketu: { sign: 8, deg: 11, min: 0, sec: 0 },
};

/** Degrees within the sign, 0 <= d < 30 */
export function degWithinSign(p: Position): number {
  return p.deg + p.min / 60 + p.sec / 3600;
}

export function formatDMS(p: Position): string {
  return `${p.deg}° ${String(p.min).padStart(2, "0")}′ ${String(p.sec).padStart(2, "0")}″`;
}

export function rashiName(n: number): string {
  const r = RASHIS.find((x) => x.num === n);
  return r ? r.name : "—";
}

export function rashiFull(n: number): string {
  const r = RASHIS.find((x) => x.num === n);
  return r ? `${r.name} (${r.en})` : "—";
}

/* ------------------------------------------------------------------ */
/* VARGA LOOKUP TABLES — exact ranges as specified                     */
/* ------------------------------------------------------------------ */

/** Pick index from an array of upper bounds (exclusive), value = index of slot. */
function slot(d: number, size: number, count: number): number {
  const i = Math.floor(d / size);
  return Math.min(i, count - 1);
}

/* D2 — HORA, 15° division */
const D2: Record<number, [number, number]> = {
  1: [1, 10],
  2: [8, 11],
  3: [9, 6],
  4: [4, 7],
  5: [5, 2],
  6: [12, 3],
  7: [1, 10],
  8: [8, 11],
  9: [9, 6],
  10: [4, 7],
  11: [5, 2],
  12: [12, 3],
};

/* D3 — DRESHKON, 10° division (by element group) */
const D3: Record<number, number[]> = {
  1: [1, 5, 9], // Agni: 1,5,9
  2: [10, 2, 6], // Prithvi: 2,6,10
  3: [7, 11, 3], // Vayu: 3,7,11
  0: [4, 8, 12], // Jal: 4,8,12
};

/* D4 — CHATURTHAMSHA, 7°30' division */
const D4: Record<number, number[]> = {
  1: [1, 10, 7, 4], // 1,4,7,10
  2: [5, 2, 11, 8], // 2,5,8,11
  0: [9, 6, 3, 12], // 3,6,9,12
};

/* D5 — PANCHAMAMSHA, 6° division */
const D5: Record<number, number[]> = {
  1: [1, 6, 11, 4, 9], // 1,5,9
  2: [10, 3, 8, 1, 6], // 2,6,10
  3: [7, 12, 5, 10, 3], // 3,7,11
  0: [4, 9, 2, 7, 12], // 4,8,12
};

/* D6 — SHASHTAMSHA, 5° division */
const D6: Record<number, number[]> = {
  1: [1, 11, 9, 7, 5, 3],
  2: [4, 2, 12, 10, 8, 6],
  3: [7, 5, 3, 1, 11, 9],
  0: [10, 8, 6, 4, 2, 12],
};

/* D8 — ASHTAMAMSHA, 3°45' division (pairs) */
const D8: Record<number, number[]> = {
  1: [1, 8, 3, 10, 5, 12, 7, 2], // 1,7
  2: [3, 10, 5, 12, 7, 2, 9, 4], // 2,8
  3: [5, 12, 7, 2, 9, 4, 11, 6], // 3,9
  4: [7, 2, 9, 4, 11, 6, 1, 8], // 4,10
  5: [9, 4, 11, 6, 1, 8, 3, 10], // 5,11
  0: [11, 6, 1, 8, 3, 10, 5, 12], // 6,12
};

/* D9 — NAVAMSHA, 3°20' division */
const D9_START: Record<number, number> = { 1: 1, 2: 10, 3: 7, 0: 4 };

/* D10 — DASHAMAMSHA, 3° division */
const D10_ODD = [1, 10, 7, 4, 5, 2, 11, 8, 9, 6];
const D10_EVEN = [5, 8, 11, 2, 1, 4, 7, 10, 9, 12];

export type VargaId = "D1" | "D2" | "D3" | "D4" | "D5" | "D6" | "D8" | "D9" | "D10";

export const VARGAS: {
  id: VargaId;
  name: string;
  sanskrit: string;
  division: string;
  group: string;
  note: string;
}[] = [
  {
    id: "D2",
    name: "Hora",
    sanskrit: "होरा",
    division: "15° division",
    group: "Achar Varga",
    note: "Wealth, resources, sustenance",
  },
  {
    id: "D3",
    name: "Drekkana",
    sanskrit: "द्रेष्काण",
    division: "10° division",
    group: "Achar Varga",
    note: "Siblings, courage, initiative",
  },
  {
    id: "D4",
    name: "Chaturthansh",
    sanskrit: "चतुर्थांश",
    division: "7°30′ division",
    group: "Char Varga",
    note: "Property, fixed assets, home",
  },
  {
    id: "D5",
    name: "Panchamansh",
    sanskrit: "पञ्चमांश",
    division: "6° division",
    group: "Achar Varga",
    note: "Merit, progeny, purva punya",
  },
  {
    id: "D6",
    name: "Shashtamansh",
    sanskrit: "षष्ठांश",
    division: "5° division",
    group: "Char Varga",
    note: "Health, debt, adversity",
  },
  {
    id: "D8",
    name: "Ashtamansh",
    sanskrit: "अष्टमांश",
    division: "3°45′ division",
    group: "Char Varga",
    note: "Longevity, sudden events",
  },
  {
    id: "D9",
    name: "Navamansh",
    sanskrit: "नवमांश",
    division: "3°20′ division",
    group: "Char Varga",
    note: "Marriage, dharma, inner strength",
  },
  {
    id: "D10",
    name: "Dashamansh",
    sanskrit: "दशमांश",
    division: "3° division",
    group: "Char Varga",
    note: "Career, authority, karma",
  },
];

/** Resolve an exact varga sign from a sign and decimal degree within it. */
function vargaSignAt(varga: VargaId, sign: number, degree: number): number {
  const s = sign;
  const d = Math.min(Math.max(degree, 0), 29.999999999);
  switch (varga) {
    case "D1":
      return s;

    case "D2":
      return D2[s][slot(d, 15, 2)];

    case "D3":
      return D3[s % 4 === 1 ? 1 : s % 4 === 2 ? 2 : s % 4 === 3 ? 3 : 0][slot(d, 10, 3)];

    case "D4":
      return D4[s % 3 === 1 ? 1 : s % 3 === 2 ? 2 : 0][slot(d, 7.5, 4)];

    case "D5":
      return D5[s % 4 === 1 ? 1 : s % 4 === 2 ? 2 : s % 4 === 3 ? 3 : 0][slot(d, 6, 5)];

    case "D6":
      return D6[s % 4 === 1 ? 1 : s % 4 === 2 ? 2 : s % 4 === 3 ? 3 : 0][slot(d, 5, 6)];

    case "D8":
      return D8[s % 6][slot(d, 3.75, 8)];

    case "D9": {
      const start = D9_START[s % 4 === 1 ? 1 : s % 4 === 2 ? 2 : s % 4 === 3 ? 3 : 0];
      return ((start - 1 + slot(d, 10 / 3, 9)) % 12) + 1;
    }

    case "D10":
      return (s % 2 === 1 ? D10_ODD : D10_EVEN)[slot(d, 3, 10)];
  }
}

/** Core engine: returns the varga rashi (1..12) for a position. */
export function vargaSign(varga: VargaId, pos: Position): number {
  return vargaSignAt(varga, pos.sign, degWithinSign(pos));
}

/** Human-readable range label for the slot a position falls in. */
export function vargaRange(varga: VargaId, pos: Position): string {
  const d = Math.min(degWithinSign(pos), 29.999999);
  const sizes: Record<VargaId, number> = {
    D1: 30,
    D2: 15,
    D3: 10,
    D4: 7.5,
    D5: 6,
    D6: 5,
    D8: 3.75,
    D9: 10 / 3,
    D10: 3,
  };
  const counts: Record<VargaId, number> = {
    D1: 1,
    D2: 2,
    D3: 3,
    D4: 4,
    D5: 5,
    D6: 6,
    D8: 8,
    D9: 9,
    D10: 10,
  };
  const size = sizes[varga];
  const i = slot(d, size, counts[varga]);
  const fmt = (x: number) => {
    const dd = Math.floor(x);
    const mm = Math.round((x - dd) * 60);
    return mm === 0 ? `${dd}°` : `${dd}°${String(mm).padStart(2, "0")}′`;
  };
  return `${fmt(i * size)}–${fmt(Math.min((i + 1) * size, 30))}`;
}

export type ChartSigns = Record<PlanetKey, number>;

export function computeVarga(chart: Chart, varga: VargaId): ChartSigns {
  const out = {} as ChartSigns;
  for (const p of PLANETS) out[p.key] = vargaSign(varga, chart[p.key]);
  return out;
}

export const ENGINEERING_FACTORS = [2, 3, 4, 5, 6, 8, 9, 10] as const;
export type EngineeringFactor = (typeof ENGINEERING_FACTORS)[number];

const ENGINEERING_VARGA_IDS: Record<EngineeringFactor, VargaId> = {
  2: "D2",
  3: "D3",
  4: "D4",
  5: "D5",
  6: "D6",
  8: "D8",
  9: "D9",
  10: "D10",
};

type EngineeringPoint = { sign: number; degree: number };

/**
 * Apply one varga to an already-derived harmonic point. The residual arc in
 * its occupied division is expanded back to 30 degrees before the next layer.
 */
function transformEngineeringPoint(
  point: EngineeringPoint,
  factor: EngineeringFactor,
): EngineeringPoint {
  const partSize = 30 / factor;
  const safeDegree = Math.min(Math.max(point.degree, 0), 29.999999999);
  const partIndex = Math.min(Math.floor(safeDegree / partSize), factor - 1);
  const residual = safeDegree - partIndex * partSize;

  return {
    sign: vargaSignAt(ENGINEERING_VARGA_IDS[factor], point.sign, safeDegree),
    degree: Math.min(residual * factor, 29.999999999),
  };
}

/** Compute an ordered varga-of-varga chain, applied from left to right. */
export function engineeredVargaSign(pos: Position, factors: readonly number[]): number {
  let point: EngineeringPoint = { sign: pos.sign, degree: degWithinSign(pos) };
  for (const factor of factors) {
    if (!ENGINEERING_FACTORS.includes(factor as EngineeringFactor)) {
      throw new Error(`Unsupported Varga Engineering factor: ${factor}`);
    }
    point = transformEngineeringPoint(point, factor as EngineeringFactor);
  }
  return point.sign;
}

export function computeEngineeredVarga(chart: Chart, factors: readonly number[]): ChartSigns {
  const out = {} as ChartSigns;
  for (const planet of PLANETS) {
    out[planet.key] = engineeredVargaSign(chart[planet.key], factors);
  }
  return out;
}

/**
 * Karakamsha Kundali rule:
 * D9 sign occupied by Atmakaraka becomes the Lagna reference in D1.
 * All planets remain in their original D1 signs; only house reckoning changes.
 */
export function computeKarakamshaD1Chart(chart: Chart, atmakaraka: PlanetKey, d9: ChartSigns): ChartSigns {
  return {
    ...computeVarga(chart, "D1"),
    Lagna: d9[atmakaraka],
  };
}

export const DASHVARGA_IDS: VargaId[] = [
  "D1",
  "D2",
  "D3",
  "D4",
  "D5",
  "D6",
  "D8",
  "D9",
  "D10",
];

/**
 * Sign-level exaltation, Moolatrikona and own-sign dignity sets.
 * Lagna and the lunar nodes are intentionally excluded because their
 * Vaisheshika treatment depends on the lineage and selected node doctrine.
 */
export const VAISHESHIKA_DIGNITY_SIGNS: Partial<Record<PlanetKey, readonly number[]>> = {
  Surya: [1, 5],
  Chandra: [2, 4],
  Mangal: [1, 8, 10],
  Budh: [3, 6],
  Guru: [4, 9, 12],
  Shukra: [2, 7, 12],
  Shani: [7, 10, 11],
};

export const RASHI_LORDS: Record<number, PlanetKey> = {
  1: "Mangal",
  2: "Shukra",
  3: "Budh",
  4: "Chandra",
  5: "Surya",
  6: "Budh",
  7: "Shukra",
  8: "Mangal",
  9: "Guru",
  10: "Shani",
  11: "Shani",
  12: "Guru",
};

const PLANET_OWN_SIGNS: Partial<Record<PlanetKey, readonly number[]>> = {
  Surya: [5],
  Chandra: [4],
  Mangal: [1, 8],
  Budh: [3, 6],
  Guru: [9, 12],
  Shukra: [2, 7],
  Shani: [10, 11],
};

export const VAISHESHIKA_TITLES: Record<number, string> = {
  0: "No classical title",
  1: "No classical title",
  2: "Parijatamsa",
  3: "Uttamamsa",
  4: "Gopuramsa",
  5: "Simhasanamsa",
  6: "Paravatamsa",
  7: "Devalokamsa",
  8: "Brahmalokamsa",
  9: "Airavatamsa",
  10: "Sridhamamsa",
};

/** Lagna uses the requested shifted title scale and can never reach Sridhamamsa. */
export const LAGNA_VAISHESHIKA_TITLES: Record<number, string> = {
  0: "No classical title",
  1: "No classical title",
  2: "No classical title",
  3: "Parijatamsa",
  4: "Uttamamsa",
  5: "Gopuramsa",
  6: "Simhasanamsa",
  7: "Paravatamsa",
  8: "Devalokamsa",
  9: "Brahmalokamsa",
  10: "Airavatamsa",
};

export type VaisheshikaResult = {
  applicable: boolean;
  score: number;
  title: string;
};

/** Count dignified placements across the supplied Dashvarga sign rows. */
export function computeVaisheshika(
  planet: PlanetKey,
  signs: readonly number[],
): VaisheshikaResult {
  const dignities = VAISHESHIKA_DIGNITY_SIGNS[planet];
  if (!dignities) return { applicable: false, score: 0, title: "N/A" };

  const score = signs.filter((sign) => dignities.includes(sign)).length;
  return {
    applicable: true,
    score,
    title: VAISHESHIKA_TITLES[score] ?? "No classical title",
  };
}

export type LagnaVaisheshikaFactors = {
  trikonaSigns: number[];
  lagnaLord: PlanetKey;
  otherLordSign: number | null;
  lordPlacementSign: number;
  qualifyingSigns: number[];
};

/**
 * Lagna's three requested factors are:
 * 1) the natal Lagna trikona signs (1st, 5th and 9th),
 * 2) the Lagna lord's other owned sign (when the lord owns two signs), and
 * 3) the natal sign occupied by the Lagna lord.
 */
export function getLagnaVaisheshikaFactors(chart: Chart): LagnaVaisheshikaFactors {
  const lagna = chart.Lagna.sign;
  const trikonaSigns = [lagna, ((lagna + 3) % 12) + 1, ((lagna + 7) % 12) + 1];
  const lagnaLord = RASHI_LORDS[lagna];
  const otherLordSign = PLANET_OWN_SIGNS[lagnaLord]?.find((sign) => sign !== lagna) ?? null;
  const lordPlacementSign = chart[lagnaLord].sign;
  const qualifyingSigns = Array.from(
    new Set([
      ...trikonaSigns,
      ...(otherLordSign === null ? [] : [otherLordSign]),
      lordPlacementSign,
    ]),
  );

  return {
    trikonaSigns,
    lagnaLord,
    otherLordSign,
    lordPlacementSign,
    qualifyingSigns,
  };
}

export function computeLagnaVaisheshika(
  chart: Chart,
  lagnaSigns: readonly number[],
): VaisheshikaResult & { factors: LagnaVaisheshikaFactors } {
  const factors = getLagnaVaisheshikaFactors(chart);
  const score = lagnaSigns.filter((sign) => factors.qualifyingSigns.includes(sign)).length;
  return {
    applicable: true,
    score,
    title: LAGNA_VAISHESHIKA_TITLES[score] ?? "No classical title",
    factors,
  };
}

/** House number (1..12) of a sign relative to the lagna sign. */
export function houseOf(sign: number, lagnaSign: number): number {
  return ((sign - lagnaSign + 12) % 12) + 1;
}
