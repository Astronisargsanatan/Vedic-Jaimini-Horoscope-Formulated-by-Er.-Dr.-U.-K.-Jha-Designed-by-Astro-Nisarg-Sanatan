import { Body, Observer, SearchRiseSet, SunPosition } from "astronomy-engine";
import { NAKSHATRAS } from "./vimshottari";
import { RASHI_LORDS, degWithinSign, houseOf, rashiName, type Chart } from "./astro";
import type { NativeInfo } from "../state/ChartContext";

const TITHI_NAMES = [
  "Pratipada", "Dwitiya", "Tritiya", "Chaturthi", "Panchami", "Shashthi", "Saptami",
  "Ashtami", "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi", "Purnima",
];

const YOGA_NAMES = [
  "Vishkambha", "Priti", "Ayushman", "Saubhagya", "Shobhana", "Atiganda", "Sukarma",
  "Dhriti", "Shula", "Ganda", "Vriddhi", "Dhruva", "Vyaghata", "Harshana", "Vajra",
  "Siddhi", "Vyatipata", "Variyana", "Parigha", "Shiva", "Siddha", "Sadhya", "Shubha",
  "Shukla", "Brahma", "Indra", "Vaidhriti",
];

const SAMVATSARAS = [
  "Prabhava", "Vibhava", "Shukla", "Pramoda", "Prajapati", "Angirasa", "Shrimukha", "Bhava",
  "Yuva", "Dhata", "Ishvara", "Bahudhanya", "Pramathi", "Vikrama", "Vrisha", "Chitrabhanu",
  "Svabhanu", "Tarana", "Parthiva", "Vyaya", "Sarvajit", "Sarvadhari", "Virodhi", "Vikriti",
  "Khara", "Nandana", "Vijaya", "Jaya", "Manmatha", "Durmukhi", "Hemalamba", "Vilambi",
  "Vikari", "Sharvari", "Plava", "Shubhakrit", "Shobhakrit", "Krodhi", "Vishvavasu", "Parabhava",
  "Plavanga", "Kilaka", "Saumya", "Sadharana", "Virodhikrit", "Paridhavi", "Pramadi", "Ananda",
  "Rakshasa", "Nala", "Pingala", "Kalayukti", "Siddharthi", "Raudra", "Durmati", "Dundubhi",
  "Rudhirodgari", "Raktakshi", "Krodhana", "Akshaya",
];

const MASAS = [
  "Chaitra", "Vaishakha", "Jyeshtha", "Ashadha", "Shravana", "Bhadrapada",
  "Ashwin", "Kartika", "Margashirsha", "Pausha", "Magha", "Phalguna",
];

const RITUS = ["Vasanta", "Grishma", "Varsha", "Sharad", "Hemanta", "Shishira"];
const VARAS = ["Ravivara", "Somavara", "Mangalavara", "Budhavara", "Guruvara", "Shukravara", "Shanivara"];

const GANA = [
  "Deva", "Manushya", "Rakshasa", "Manushya", "Deva", "Manushya", "Deva", "Deva", "Rakshasa",
  "Rakshasa", "Manushya", "Manushya", "Deva", "Rakshasa", "Deva", "Rakshasa", "Deva", "Rakshasa",
  "Rakshasa", "Manushya", "Manushya", "Deva", "Rakshasa", "Rakshasa", "Manushya", "Manushya", "Deva",
];

const YONI = [
  "Ashwa", "Gaja", "Mesha", "Sarpa", "Sarpa", "Shwana", "Marjara", "Mesha", "Marjara",
  "Mushaka", "Mushaka", "Gau", "Mahisha", "Vyaghra", "Mahisha", "Vyaghra", "Mriga", "Mriga",
  "Shwana", "Vanara", "Nakula", "Vanara", "Simha", "Ashwa", "Simha", "Gau", "Gaja",
];

const NADI = [
  "Adi", "Madhya", "Antya", "Antya", "Madhya", "Adi", "Adi", "Madhya", "Antya",
  "Antya", "Madhya", "Adi", "Adi", "Madhya", "Antya", "Antya", "Madhya", "Adi",
  "Adi", "Madhya", "Antya", "Antya", "Madhya", "Adi", "Adi", "Madhya", "Antya",
];

const RAJJU = [
  "Pada", "Kati", "Nabhi", "Kantha", "Shira", "Kantha", "Nabhi", "Kati", "Pada",
  "Pada", "Kati", "Nabhi", "Kantha", "Shira", "Kantha", "Nabhi", "Kati", "Pada",
  "Pada", "Kati", "Nabhi", "Kantha", "Shira", "Kantha", "Nabhi", "Kati", "Pada",
];

const NAKSHATRA_SYLLABLES = [
  ["Chu", "Che", "Cho", "La"], ["Li", "Lu", "Le", "Lo"], ["A", "I", "U", "E"],
  ["O", "Va", "Vi", "Vu"], ["Ve", "Vo", "Ka", "Ki"], ["Ku", "Gha", "Nga", "Chha"],
  ["Ke", "Ko", "Ha", "Hi"], ["Hu", "He", "Ho", "Da"], ["Di", "Du", "De", "Do"],
  ["Ma", "Mi", "Mu", "Me"], ["Mo", "Ta", "Ti", "Tu"], ["Te", "To", "Pa", "Pi"],
  ["Pu", "Sha", "Na", "Tha"], ["Pe", "Po", "Ra", "Ri"], ["Ru", "Re", "Ro", "Ta"],
  ["Ti", "Tu", "Te", "To"], ["Na", "Ni", "Nu", "Ne"], ["No", "Ya", "Yi", "Yu"],
  ["Ye", "Yo", "Bha", "Bhi"], ["Bhu", "Dha", "Pha", "Dha"], ["Bhe", "Bho", "Ja", "Ji"],
  ["Ju", "Je", "Jo", "Gha"], ["Ga", "Gi", "Gu", "Ge"], ["Go", "Sa", "Si", "Su"],
  ["Se", "So", "Da", "Di"], ["Du", "Tha", "Jha", "Na"], ["De", "Do", "Cha", "Chi"],
];

const RASHI_AKSHARA = [
  "Chu, Che, Cho, La, Li, Lu, Le, Lo, A", "I, U, E, O, Va, Vi, Vu, Ve, Vo",
  "Ka, Ki, Ku, Gha, Nga, Chha, Ke, Ko, Ha", "Hi, Hu, He, Ho, Da, Di, Du, De, Do",
  "Ma, Mi, Mu, Me, Mo, Ta, Ti, Tu, Te", "To, Pa, Pi, Pu, Sha, Na, Tha, Pe, Po",
  "Ra, Ri, Ru, Re, Ro, Ta, Ti, Tu, Te", "To, Na, Ni, Nu, Ne, No, Ya, Yi, Yu",
  "Ye, Yo, Bha, Bhi, Bhu, Dha, Pha, Dha, Bhe", "Bho, Ja, Ji, Ju, Je, Jo, Gha, Ga, Gi",
  "Gu, Ge, Go, Sa, Si, Su, Se, So, Da", "Di, Du, Tha, Jha, Na, De, Do, Cha, Chi",
];

const ELEMENTS = ["Agni", "Prithvi", "Vayu", "Jala"];

export type PanchangResult = {
  samvatsara: string;
  vikramSamvat: number;
  shakaSamvat: number;
  masa: string;
  paksha: string;
  ayana: string;
  gola: string;
  ritu: string;
  vara: string;
  tithi: string;
  tithiNumber: number;
  nakshatra: string;
  nakshatraPada: number;
  yoga: string;
  karana: string;
  sunrise: string;
  sunset: string;
  sampatikaKala: string;
  ayanamsha: string;
  divamana: string;
  ratrimana: string;
  varna: string;
  tattva: string;
  hamsaka: string;
  gana: string;
  yoni: string;
  yunja: string;
  nadi: string;
  rajju: string;
  rashi: string;
  rashisha: string;
  rashiAkshara: string;
  nakshatraSyllables: string;
  nameSyllable: string;
  paya: string;
  vashya: string;
};

function absoluteLongitude(chart: Chart, key: "Surya" | "Chandra"): number {
  return (chart[key].sign - 1) * 30 + degWithinSign(chart[key]);
}

function formatClock(date: Date | null, timeZone?: string): string {
  if (!date) return "Not available";
  const zone = (timeZone ?? "").split(" (")[0];
  try {
    return new Intl.DateTimeFormat("en-GB", {
      timeZone: zone.includes("/") ? zone : undefined,
      hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
    }).format(date);
  } catch {
    return date.toISOString().slice(11, 19) + " UTC";
  }
}

function ghatiPala(hours: number): string {
  const totalPala = Math.round(hours * 2.5 * 60);
  return `${Math.floor(totalPala / 60)} Ghati ${totalPala % 60} Pala`;
}

function karanaName(halfTithiIndex: number): string {
  if (halfTithiIndex === 0) return "Kimstughna";
  if (halfTithiIndex >= 57) return ["Shakuni", "Chatushpada", "Naga"][halfTithiIndex - 57];
  return ["Bava", "Balava", "Kaulava", "Taitila", "Gara", "Vanija", "Vishti"][(halfTithiIndex - 1) % 7];
}

function varna(sign: number): string {
  return [4, 8, 12].includes(sign) ? "Brahmin" : [1, 5, 9].includes(sign) ? "Kshatriya" : [2, 6, 10].includes(sign) ? "Vaishya" : "Shudra";
}

function vashya(sign: number): string {
  if ([1, 2, 5, 9, 10].includes(sign)) return "Chatushpada";
  if ([3, 6, 7, 11].includes(sign)) return "Manava";
  if ([4, 12].includes(sign)) return "Jalachara";
  if (sign === 8) return "Keeta";
  return "Vanachara";
}

export function computePanchang(chart: Chart, native: NativeInfo | null): PanchangResult {
  const sun = absoluteLongitude(chart, "Surya");
  const moon = absoluteLongitude(chart, "Chandra");
  const elongation = (moon - sun + 360) % 360;
  const tithiIndex = Math.floor(elongation / 12);
  const paksha = tithiIndex < 15 ? "Shukla Paksha" : "Krishna Paksha";
  const tithiInPaksha = tithiIndex % 15;
  const tithiName = tithiInPaksha === 14 && tithiIndex >= 15 ? "Amavasya" : TITHI_NAMES[tithiInPaksha];
  const nakIndex = Math.floor(moon / (360 / 27));
  const nakWithin = moon - nakIndex * (360 / 27);
  const nakPada = Math.min(4, Math.floor(nakWithin / (360 / 27 / 4)) + 1);
  const yogaIndex = Math.floor(((sun + moon) % 360) / (360 / 27));
  const halfTithiIndex = Math.floor(elongation / 6);
  const moonSign = chart.Chandra.sign;

  const birth = native?.birthUtc ? new Date(native.birthUtc) : new Date();
  const year = birth.getUTCFullYear();
  const krodhiIndex = SAMVATSARAS.indexOf("Krodhi");
  const samvatsara = SAMVATSARAS[((krodhiIndex + year - 2024) % 60 + 60) % 60];
  const sunSign = chart.Surya.sign;
  // Amanta month approximation: Sun in Pisces corresponds to Chaitra, Aries to Vaishakha.
  const masa = MASAS[sunSign % 12];
  const ritu = RITUS[Math.floor(((sunSign + 10) % 12) / 2)];
  const tropicalSun = SunPosition(birth).elon;
  const north = tropicalSun >= 0 && tropicalSun < 180;

  let rise: Date | null = null;
  let set: Date | null = null;
  if (native?.lat != null && native?.lon != null) {
    const observer = new Observer(native.lat, native.lon, 0);
    const searchStart = new Date(birth.getTime() - 18 * 3600000);
    rise = SearchRiseSet(Body.Sun, observer, +1, searchStart, 2)?.date ?? null;
    set = rise ? SearchRiseSet(Body.Sun, observer, -1, rise, 1.5)?.date ?? null : null;
  }
  const dayHours = rise && set ? (set.getTime() - rise.getTime()) / 3600000 : 12;
  const nightHours = 24 - dayHours;
  const moonHouse = houseOf(moonSign, chart.Lagna.sign);
  const paya = [1, 6, 11].includes(moonHouse) ? "Swarna" : [2, 5, 9].includes(moonHouse) ? "Rajata" : [3, 7, 10].includes(moonHouse) ? "Tamra" : "Lauha";
  const yunja = nakIndex < 9 ? "Purva" : nakIndex < 18 ? "Madhya" : "Uttara";

  return {
    samvatsara,
    vikramSamvat: year + 57,
    shakaSamvat: year - 78,
    masa: `${masa} (Amanta reference)`,
    paksha,
    ayana: north ? "Uttarayana" : "Dakshinayana",
    gola: north ? "Uttara Gola" : "Dakshina Gola",
    ritu,
    vara: VARAS[birth.getUTCDay()],
    tithi: `${paksha} ${tithiName}`,
    tithiNumber: tithiIndex + 1,
    nakshatra: NAKSHATRAS[nakIndex].name,
    nakshatraPada: nakPada,
    yoga: YOGA_NAMES[yogaIndex],
    karana: karanaName(halfTithiIndex),
    sunrise: formatClock(rise, native?.tz),
    sunset: formatClock(set, native?.tz),
    sampatikaKala: native?.siderealTime ?? "Not available",
    ayanamsha: native?.ayanamsha ?? "Lahiri / Chitrapaksha",
    divamana: ghatiPala(dayHours),
    ratrimana: ghatiPala(nightHours),
    varna: varna(moonSign),
    tattva: ELEMENTS[(moonSign - 1) % 4],
    hamsaka: [2, 6, 10].includes(moonSign) ? "Bhumi" : [4, 8, 12].includes(moonSign) ? "Jala" : [1, 5, 9].includes(moonSign) ? "Agni" : "Vayu",
    gana: GANA[nakIndex],
    yoni: YONI[nakIndex],
    yunja,
    nadi: NADI[nakIndex],
    rajju: RAJJU[nakIndex],
    rashi: `${moonSign}. ${rashiName(moonSign)}`,
    rashisha: RASHI_LORDS[moonSign],
    rashiAkshara: RASHI_AKSHARA[moonSign - 1],
    nakshatraSyllables: NAKSHATRA_SYLLABLES[nakIndex].join(", "),
    nameSyllable: NAKSHATRA_SYLLABLES[nakIndex][nakPada - 1],
    paya,
    vashya: vashya(moonSign),
  };
}

export { SAMVATSARAS, YOGA_NAMES, TITHI_NAMES };
