import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import {
  DEFAULT_CHART,
  PLANETS,
  type Chart,
  type ChartSigns,
  type PlanetKey,
  type Position,
} from "../lib/astro";

export type NativeInfo = {
  fullName: string;
  date: string;
  time: string;
  place: string;
  lat?: number;
  lon?: number;
  tz?: string;
  ayanamsha?: string;
  lmt?: string;
  siderealTime?: string;
  /** Exact birth instant in UTC (ISO) — used by Vimshottari dasha. */
  birthUtc?: string;
};

const DEFAULT_ENGINEERING_SIGNS = PLANETS.reduce((signs, planet) => {
  signs[planet.key] = DEFAULT_CHART[planet.key].sign;
  return signs;
}, {} as ChartSigns);

type Ctx = {
  chart: Chart;
  native: NativeInfo | null;
  engineeringVargaName: string;
  engineeringSigns: ChartSigns;
  setField: (planet: PlanetKey, field: keyof Position, value: number) => void;
  setChartFromBirth: (chart: Chart, native?: NativeInfo) => void;
  setEngineeringVargaName: (value: string) => void;
  setEngineeringSign: (planet: PlanetKey, sign: number) => void;
  applyEngineeringToDashvarga: (vargaName: string, signs: ChartSigns) => void;
  reset: () => void;
};

const ChartCtx = createContext<Ctx | null>(null);

export function ChartProvider({ children }: { children: ReactNode }) {
  const [chart, setChart] = useState<Chart>(DEFAULT_CHART);
  const [native, setNative] = useState<NativeInfo | null>(null);
  const [engineeringVargaName, setEngineeringVargaNameState] = useState("D12");
  const [engineeringSigns, setEngineeringSigns] = useState<ChartSigns>(
    DEFAULT_ENGINEERING_SIGNS,
  );

  const value = useMemo<Ctx>(
    () => ({
      chart,
      native,
      engineeringVargaName,
      engineeringSigns,
      setField: (planet, field, value) =>
        setChart((c) => ({ ...c, [planet]: { ...c[planet], [field]: value } })),
      setChartFromBirth: (nextChart, nextNative) => {
        setChart(nextChart);
        if (nextNative) setNative(nextNative);
      },
      setEngineeringVargaName: (input) => setEngineeringVargaNameState(input.slice(0, 40)),
      setEngineeringSign: (planet, sign) =>
        setEngineeringSigns((current) => ({
          ...current,
          [planet]: Math.max(1, Math.min(12, sign)),
        })),
      applyEngineeringToDashvarga: (vargaName, signs) => {
        setEngineeringVargaNameState(vargaName.slice(0, 40));
        setEngineeringSigns({ ...signs });
      },
      reset: () => {
        setChart(DEFAULT_CHART);
        setNative(null);
        setEngineeringVargaNameState("D12");
        setEngineeringSigns(DEFAULT_ENGINEERING_SIGNS);
      },
    }),
    [chart, native, engineeringSigns, engineeringVargaName],
  );

  return <ChartCtx.Provider value={value}>{children}</ChartCtx.Provider>;
}

export function useChart() {
  const ctx = useContext(ChartCtx);
  if (!ctx) throw new Error("useChart must be used inside ChartProvider");
  return ctx;
}
