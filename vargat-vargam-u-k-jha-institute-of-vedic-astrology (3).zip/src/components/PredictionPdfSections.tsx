import Logo from "./Logo";
import { computePrediction } from "../lib/prediction";
import { computeJaiminiCharKaraka } from "../lib/jaimini";
import { computeVimshottari, formatDate, LORD_HINDI, NAKSHATRAS } from "../lib/vimshottari";
import { computeAarshaVimshottari } from "../lib/aarshaVimshottari";
import { computeCharaDasha, formatCharaDateTime } from "../lib/charaDasha";
import { computeMandookDasha, formatMandookDate } from "../lib/mandookDasha";
import { computeMuktashtakiDasha, formatMuktashtakiDate } from "../lib/muktashtakiDasha";
import {
  DASHVARGA_IDS,
  PLANETS,
  RASHI_LORDS,
  VARGAS,
  computeVarga,
  degWithinSign,
  houseOf,
  rashiName,
  type Chart,
  type ChartSigns,
  type PlanetKey,
} from "../lib/astro";
import type { NativeInfo } from "../state/ChartContext";

const VARGA_USE: Record<string, string> = {
  D1: "स्थूल जीवन, शरीर और सम्पूर्ण जन्म-प्रतिज्ञा",
  D2: "धन, संसाधन और निर्वाह",
  D3: "पराक्रम, सहोदर और प्रयास",
  D4: "गृह, सम्पत्ति और स्थिर सुख",
  D5: "बुद्धि, सृजन और पूर्व-पुण्य",
  D6: "रोग, ऋण, सेवा और संघर्ष-क्षमता",
  D8: "आयु, परिवर्तन और आकस्मिक घटनाएँ",
  D9: "धर्म, विवाह और ग्रहों की आन्तरिक शक्ति",
  D10: "कर्म, व्यवसाय, पद और सार्वजनिक दायित्व",
};

const GRAHA_KARAKATWA: Partial<Record<PlanetKey, string>> = {
  Surya: "आत्मबल, पिता, सत्ता, प्रतिष्ठा",
  Chandra: "मन, माता, भावनाएँ, लोक-संपर्क",
  Mangal: "साहस, भूमि, ऊर्जा, संघर्ष",
  Budh: "बुद्धि, वाणी, व्यापार, लेखन",
  Guru: "ज्ञान, सन्तान, धर्म, विस्तार",
  Shukra: "विवाह, कला, सुविधा, सम्बन्ध",
  Shani: "श्रम, अनुशासन, विलम्ब, उत्तरदायित्व",
  Rahu: "तीव्र इच्छा, विदेश, असामान्य परिवर्तन",
  Ketu: "वैराग्य, विच्छेद, शोध, अन्तर्दृष्टि",
  Lagna: "शरीर, स्वभाव और जीवन-दिशा",
};

function birthInstant(native: NativeInfo | null) {
  if (native?.birthUtc) {
    const date = new Date(native.birthUtc);
    if (!Number.isNaN(date.getTime())) return date;
  }
  const d = (native?.date ?? "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const t = (native?.time ?? "").match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  if (!d) return new Date();
  return new Date(
    Date.UTC(
      Number(d[3]), Number(d[2]) - 1, Number(d[1]),
      t ? Number(t[1]) : 12, t ? Number(t[2]) : 0, t ? Number(t[3] ?? 0) : 0,
    ) - 330 * 60000,
  );
}

function absoluteLongitude(chart: Chart, key: PlanetKey) {
  return (chart[key].sign - 1) * 30 + degWithinSign(chart[key]);
}

function nakshatraName(chart: Chart, key: PlanetKey) {
  const index = Math.floor(absoluteLongitude(chart, key) / (360 / 27)) % 27;
  const within = absoluteLongitude(chart, key) - index * (360 / 27);
  const pada = Math.floor(within / (360 / 27 / 4)) + 1;
  return `${NAKSHATRAS[index].name} · पद ${pada}`;
}

function aspectHouses(key: PlanetKey): number[] {
  if (key === "Mangal") return [4, 7, 8];
  if (key === "Guru") return [5, 7, 9];
  if (key === "Shani") return [3, 7, 10];
  if (key === "Rahu" || key === "Ketu") return [5, 7, 9];
  return [7];
}

function aspectText(chart: Chart, key: PlanetKey) {
  return aspectHouses(key)
    .map((relative) => {
      const sign = ((chart[key].sign - 1 + relative - 1) % 12) + 1;
      return `${relative}वीं → ${rashiName(sign)} (H${houseOf(sign, chart.Lagna.sign)})`;
    })
    .join("; ");
}

function conjunctionText(chart: Chart, key: PlanetKey) {
  const companions = PLANETS.filter(
    (planet) => planet.key !== key && planet.key !== "Lagna" && chart[planet.key].sign === chart[key].sign,
  ).map((planet) => planet.key);
  return companions.length ? companions.join(", ") : "कोई ग्रह-युति नहीं";
}

function strengthText(chart: Chart, key: PlanetKey) {
  if (key === "Lagna") return "लग्न-बल का पृथक समन्वय";
  const sign = chart[key].sign;
  const own = Object.entries(RASHI_LORDS)
    .filter(([, lord]) => lord === key)
    .map(([value]) => Number(value));
  if (own.includes(sign)) return "स्वराशि — स्थानबल समर्थ";
  const house = houseOf(sign, chart.Lagna.sign);
  if ([1, 4, 5, 7, 9, 10].includes(house)) return "केन्द्र/त्रिकोण स्थिति — संरचनात्मक समर्थन";
  if ([6, 8, 12].includes(house)) return "दुष्थान स्थिति — परिवर्तन/परिश्रम से फल";
  return "मध्यम स्थानबल";
}

function Footer(_props: { page: number; total: number }) {
  return (
    <div className="pdf-foot">
      <span>U K Jha Institute of Vedic Astrology ; Er. Dr. U K Jha & Astro Nisarg Sanatan — (+91) 9998074088</span>
    </div>
  );
}

function Head() {
  return (
    <div className="pdf-head">
      <Logo className="pdf-logo" />
      <div>
        <div className="pdf-inst">U K Jha Institute of Vedic Astrology</div>
        <div className="pdf-by">President · Er. Dr. U K Jha</div>
        <div className="pdf-sub">Vice-President · Astro Nisarg Sanatan · Gujarat Chapter — (+91) 9998074088</div>
      </div>
    </div>
  );
}

export default function PredictionPdfSections({
  chart,
  native,
  engineeringSigns,
  startPage,
  totalPages,
}: {
  chart: Chart;
  native: NativeInfo | null;
  engineeringSigns: ChartSigns;
  startPage: number;
  totalPages: number;
}) {
  const prediction = computePrediction(chart, native, engineeringSigns);
  const birth = birthInstant(native);
  const now = new Date();
  const charKarakas = computeJaiminiCharKaraka(chart);
  const charMap = new Map(charKarakas.map((item) => [item.key, item.karaka.role]));
  const generated = Object.fromEntries(
    DASHVARGA_IDS.map((id) => [id, computeVarga(chart, id)]),
  ) as Record<string, ChartSigns>;
  const vim = computeVimshottari(chart, birth, now);
  const aarsha = computeAarshaVimshottari(chart, birth, now);
  const chara = computeCharaDasha(chart, birth);
  const mandook = computeMandookDasha(chart, birth, now);
  const mukta = computeMuktashtakiDasha(chart, birth, now);
  const activeChara = chara.periods.find((period) => now >= period.start && now < period.end);

  return (
    <>
      {/* 1. समग्र सार */}
      <section className="pdf-page prediction-page">
        <Head />
        <h2 className="pdf-title">1. समग्र सार · Integrated Horoscope Synthesis</h2>
        <table className="pdf-meta">
          <tbody>
            <tr><th>Native</th><td>{native?.fullName || "—"}</td><th>Birth</th><td>{native?.date || "—"} · {native?.time || "—"}</td></tr>
            <tr><th>Janma Lagna</th><td>{chart.Lagna.sign}. {rashiName(chart.Lagna.sign)}</td><th>Chandra</th><td>{chart.Chandra.sign}. {rashiName(chart.Chandra.sign)}</td></tr>
            <tr><th>Atmakaraka</th><td>{prediction.atmakaraka} · {prediction.atmakarakaSign}. {rashiName(prediction.atmakarakaSign)}</td><th>Karakamsha</th><td>{prediction.lagnas.find((l) => l.key === "Karakamsha")?.sign}. {rashiName(prediction.lagnas.find((l) => l.key === "Karakamsha")?.sign ?? 1)}</td></tr>
          </tbody>
        </table>
        <h3 className="pdf-h3">आत्मकारक का मूल संकेत</h3>
        <p className="pdf-prediction-box">{prediction.atmakarakaText}</p>
        <h3 className="pdf-h3">समन्वित निष्कर्ष</h3>
        <ol className="pdf-numbered">
          {prediction.synthesis.map((text, index) => <li key={index}>{text}</li>)}
        </ol>
        <h3 className="pdf-h3">जीवन क्षेत्रों का शक्ति-सार</h3>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>भाव</th><th>विषय</th><th>भावेश</th><th>SAV</th><th>वर्ग पुनरावृत्ति</th><th>बल</th></tr></thead>
          <tbody>
            {prediction.bhavas.map((bhava) => (
              <tr key={bhava.bhava}>
                <td>{bhava.bhava}. {bhava.title}</td><td>{bhava.themes}</td><td>{bhava.lord} · H{bhava.lordHouse}</td>
                <td className="center">{bhava.savBindus}</td><td className="center">{bhava.vargaRepetition}/10</td><td>{bhava.strength}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <Footer page={startPage} total={totalPages} />
      </section>

      {/* 2. पंच लग्न */}
      <section className="pdf-page prediction-page">
        <Head />
        <h2 className="pdf-title">2. पंच लग्न का विस्तृत विश्लेषण</h2>
        <p className="pdf-note">जन्म, चन्द्र, सूर्य, आरूढ़ और कारकांश लग्न — कारकांश में D9 में आत्मकारक की राशि को D1 में प्रथम भाव माना गया है; ग्रह D1 राशियों में यथावत हैं।</p>
        <table className="pdf-table">
          <thead><tr><th>लग्न</th><th>राशि</th><th>विश्लेषण आधार</th><th>राशीश</th><th>राशीश की जन्म-भाव स्थिति</th></tr></thead>
          <tbody>
            {prediction.lagnas.map((lagna) => {
              const lord = RASHI_LORDS[lagna.sign];
              return (
                <tr key={lagna.key}>
                  <td className="font-semibold">{lagna.hindi}</td><td>{lagna.sign}. {rashiName(lagna.sign)}</td>
                  <td>{lagna.significance}</td><td>{lord}</td><td>H{houseOf(chart[lord].sign, chart.Lagna.sign)} · {rashiName(chart[lord].sign)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {prediction.lagnas.map((lagna) => {
          const lord = RASHI_LORDS[lagna.sign];
          const relevant = prediction.bhavas.filter((bhava) => bhava.janmaSign === lagna.sign || bhava.lord === lord).slice(0, 2);
          return (
            <div className="pdf-prediction-section" key={`lagna-detail-${lagna.key}`}>
              <h3>{lagna.hindi} — {lagna.sign}. {rashiName(lagna.sign)}</h3>
              <p>{lagna.significance}। राशीश {lord} जन्म लग्न से {houseOf(chart[lord].sign, chart.Lagna.sign)}वें भाव में है; {strengthText(chart, lord)}। {relevant.map((item) => `${item.title} ${item.strength}`).join("; ")}।</p>
            </div>
          );
        })}
        <Footer page={startPage + 1} total={totalPages} />
      </section>

      {/* 3. वर्ग कुण्डली */}
      <section className="pdf-page prediction-page">
        <Head />
        <h2 className="pdf-title">3. आवश्यक वर्ग-कुण्डलियों का विश्लेषण</h2>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>वर्ग</th><th>लग्न</th><th>विश्लेषण क्षेत्र</th><th>जन्म लग्न से सम्बन्ध</th><th>मुख्य संकेत</th></tr></thead>
          <tbody>
            {["D1", ...VARGAS.map((varga) => varga.id)].map((id) => {
              const varga = generated[id];
              const same = varga.Lagna === chart.Lagna.sign;
              const planetsInLagna = PLANETS.filter((planet) => planet.key !== "Lagna" && varga[planet.key] === varga.Lagna).map((planet) => planet.key);
              return (
                <tr key={id}>
                  <td className="font-semibold">{id}</td><td>{varga.Lagna}. {rashiName(varga.Lagna)}</td>
                  <td>{VARGA_USE[id]}</td><td>{same ? "जन्म लग्न राशि की पुनरावृत्ति" : `${houseOf(varga.Lagna, chart.Lagna.sign)}वाँ संकेत`}</td>
                  <td>{planetsInLagna.length ? `लग्न में ${planetsInLagna.join(", ")}` : "लग्न में कोई ग्रह नहीं"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <h3 className="pdf-h3">Dashvarga Repetition by Graha</h3>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>ग्रह</th><th>D1 राशि</th><th>D1 राशि की 10 rows में पुनरावृत्ति</th><th>Char Karaka</th><th>फलित प्रयोग</th></tr></thead>
          <tbody>
            {PLANETS.map((planet) => {
              const repetition = [...DASHVARGA_IDS.map((id) => generated[id][planet.key]), engineeringSigns[planet.key]].filter((sign) => sign === chart[planet.key].sign).length;
              return (
                <tr key={planet.key}>
                  <td>{planet.key}</td><td>{chart[planet.key].sign}. {rashiName(chart[planet.key].sign)}</td><td className="center">{repetition}/10</td>
                  <td className="center">{charMap.get(planet.key) ?? "—"}</td><td>{repetition >= 3 ? "राशि-संकेत स्थिर और बार-बार पुष्ट" : repetition === 2 ? "मध्यम वर्ग-पुष्टि" : "फल संबंधित वर्ग और दशा पर अधिक निर्भर"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <p className="pdf-note">वर्गफल को D1 से अलग स्वतंत्र प्रतिज्ञा नहीं माना गया; D1 Bhava–Bhavesh के फल को संबंधित सूक्ष्म क्षेत्र में पुष्ट या संशोधित किया गया है।</p>
        <Footer page={startPage + 2} total={totalPages} />
      </section>

      {/* 4–5. बारह भाव */}
      {[prediction.bhavas.slice(0, 6), prediction.bhavas.slice(6)].map((bhavas, pageIndex) => (
        <section className="pdf-page prediction-page" key={`bhava-pred-${pageIndex}`}>
          <Head />
          <h2 className="pdf-title">4. बारहों भावों का विस्तृत फल · भाव {bhavas[0].bhava}–{bhavas[bhavas.length - 1].bhava}</h2>
          {bhavas.map((bhava) => (
            <div className="pdf-bhava-block" key={bhava.bhava}>
              <div className="pdf-bhava-head">
                <strong>{bhava.bhava}. {bhava.title}</strong>
                <span>{bhava.strength} · SAV {bhava.savBindus}</span>
              </div>
              <div className="pdf-bhava-facts">
                राशि {bhava.janmaSign}. {rashiName(bhava.janmaSign)} · भावेश {bhava.lord} H{bhava.lordHouse} · कारक {bhava.karaka.join(", ")} · {bhava.arudhaLabel} {bhava.arudhaSign}. {rashiName(bhava.arudhaSign)} · पंच-लग्न समर्थन {bhava.supportingLagnas}/5
              </div>
              <p>{bhava.prediction}</p>
            </div>
          ))}
          <Footer page={startPage + 3 + pageIndex} total={totalPages} />
        </section>
      ))}

      {/* 6. दशा समय */}
      <section className="pdf-page prediction-page">
        <Head />
        <h2 className="pdf-title">5. दशा-अन्तर्दशा का समयानुसार फल एवं प्रमुख घटना-विषय</h2>
        <table className="pdf-table">
          <thead><tr><th>प्रणाली</th><th>सक्रिय क्रम</th><th>फलित प्रयोग</th></tr></thead>
          <tbody>{prediction.dashas.map((dasha) => <tr key={dasha.system}><td>{dasha.system}</td><td className="font-semibold">{dasha.active}</td><td>{dasha.indication}</td></tr>)}</tbody>
        </table>
        <h3 className="pdf-h3">Active Period Dates</h3>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>System</th><th>Active Level</th><th>Start</th><th>End</th><th>संभावित प्रमुख विषय</th></tr></thead>
          <tbody>
            {vim.activePath.map((period) => <tr key={`vim-${period.level}`}><td>प्रचलित विंशोत्तरी</td><td>L{period.level} · {LORD_HINDI[period.lord]}</td><td>{formatDate(period.start)}</td><td>{formatDate(period.end)}</td><td>{GRAHA_KARAKATWA[period.lord]}; natal H{houseOf(chart[period.lord].sign, chart.Lagna.sign)}</td></tr>)}
            {aarsha.activePath.map((period) => <tr key={`aar-${period.level}`}><td>आर्ष विंशोत्तरी</td><td>L{period.level} · {LORD_HINDI[period.lord]}</td><td>{formatDate(period.start)}</td><td>{formatDate(period.end)}</td><td>{GRAHA_KARAKATWA[period.lord]}; {aarsha.cycle} trigger</td></tr>)}
            {activeChara && <tr><td>चर दशा</td><td>{activeChara.sign}. {activeChara.signName}</td><td>{formatCharaDateTime(activeChara.start, native?.tz)}</td><td>{formatCharaDateTime(activeChara.end, native?.tz)}</td><td>सक्रिय राशि के ग्रह, स्वामी, आरूढ़ और सम्बद्ध भाव</td></tr>}
            {mandook.activeMaha && <tr><td>मण्डूक दशा</td><td>{mandook.activeMaha.sign}. {rashiName(mandook.activeMaha.sign)}</td><td>{formatMandookDate(mandook.activeMaha.start, native?.tz)}</td><td>{formatMandookDate(mandook.activeMaha.end, native?.tz)}</td><td>त्रिकोण/केन्द्र jump और 6→7 junction के विषय</td></tr>}
            {mukta.activeMaha && <tr><td>मुक्ताष्टकी</td><td>{mukta.activeMaha.sign}. {rashiName(mukta.activeMaha.sign)}</td><td>{formatMuktashtakiDate(mukta.activeMaha.start, native?.tz)}</td><td>{formatMuktashtakiDate(mukta.activeMaha.end, native?.tz)}</td><td>SAV {mukta.activeMaha.bindus} बिन्दु वाली राशि के भाव-विषय</td></tr>}
          </tbody>
        </table>
        <p className="pdf-prediction-box">मुख्य घटना का समय तब अधिक पुष्ट है जब सक्रिय दशा-स्वामी/राशि संबंधित भाव, भावेश, कारक, आरूढ़, दशवर्ग और गोचर से एकसमान समर्थन पाए। तालिका केवल उपलब्ध horoscope data से derived event-themes दिखाती है; कोई बाहरी घटना जोड़ी नहीं गई।</p>
        <Footer page={startPage + 5} total={totalPages} />
      </section>

      {/* 7. ग्रह/राशि/नक्षत्र/योग/दृष्टि/बल */}
      <section className="pdf-page prediction-page">
        <Head />
        <h2 className="pdf-title">6. ग्रह, राशि, नक्षत्र, योग, दृष्टि एवं बलाबल का समन्वित निष्कर्ष</h2>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>ग्रह</th><th>राशि / भाव</th><th>नक्षत्र</th><th>Char Karaka</th><th>युति</th><th>पूर्ण दृष्टियाँ</th><th>बल संकेत</th></tr></thead>
          <tbody>
            {PLANETS.filter((planet) => planet.key !== "Lagna").map((planet) => (
              <tr key={planet.key}>
                <td className="font-semibold">{planet.key}{chart[planet.key].motion === "R" ? " (R)" : ""}</td>
                <td>{chart[planet.key].sign}. {rashiName(chart[planet.key].sign)} · H{houseOf(chart[planet.key].sign, chart.Lagna.sign)}</td>
                <td>{nakshatraName(chart, planet.key)}</td><td>{charMap.get(planet.key) ?? "—"}</td>
                <td>{conjunctionText(chart, planet.key)}</td><td>{aspectText(chart, planet.key)}</td><td>{strengthText(chart, planet.key)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <h3 className="pdf-h3">योग / ग्रह-संयोग</h3>
        <ul className="pdf-numbered">
          {PLANETS.filter((planet) => planet.key !== "Lagna")
            .filter((planet, index, list) => list.findIndex((item) => chart[item.key].sign === chart[planet.key].sign) === index)
            .map((planet) => {
              const occupants = PLANETS.filter((item) => item.key !== "Lagna" && chart[item.key].sign === chart[planet.key].sign).map((item) => item.key);
              return occupants.length > 1 ? <li key={planet.key}>{rashiName(chart[planet.key].sign)} में {occupants.join("–")} युति; इसके संयुक्त कारकत्व संबंधित H{houseOf(chart[planet.key].sign, chart.Lagna.sign)} में सक्रिय होते हैं।</li> : null;
            })}
        </ul>
        <h3 className="pdf-h3">अन्तिम समन्वय</h3>
        <p className="pdf-prediction-box">
          आत्मकारक {prediction.atmakaraka}, जन्म लग्न {rashiName(chart.Lagna.sign)}, चन्द्र लग्न {rashiName(chart.Chandra.sign)}, आरूढ़ लग्न {rashiName(prediction.lagnas.find((l) => l.key === "Arudha")?.sign ?? 1)} और कारकांश {rashiName(prediction.lagnas.find((l) => l.key === "Karakamsha")?.sign ?? 1)} इस फलित के मुख्य anchors हैं। कारकांश गणना में AK की D9 राशि को D1 में प्रथम भाव माना गया है और ग्रह D1 की मूल राशियों में ही रखे गए हैं। ग्रहों की राशि/नक्षत्र स्थिति, युति और पाराशरी पूर्ण-दृष्टियाँ ऊपर उपलब्ध horoscope data से निकाली गई हैं। बलाबल में स्वराशि, केन्द्र/त्रिकोण/दुष्थान स्थिति, SAV और दशवर्ग पुनरावृत्ति को साथ पढ़ा गया है। किसी फल को दोहराने के बजाय प्रत्येक section ने अलग स्तर—आत्मिक, लग्न, वर्ग, भाव, दशा और ग्रह-समन्वय—पर निष्कर्ष दिया है।
        </p>
        <p className="pdf-note">निश्चित घटना-घोषणा नहीं: फल देश–काल–पात्र, जन्म-समय शुद्धता और Dasha Pravesh/Gochar पुष्टि के अधीन है।</p>
        <Footer page={startPage + 6} total={totalPages} />
      </section>
    </>
  );
}
