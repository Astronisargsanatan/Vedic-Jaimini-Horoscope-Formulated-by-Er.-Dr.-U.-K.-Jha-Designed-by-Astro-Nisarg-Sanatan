import Logo from "./Logo";
import {
  SHADBALA_EXPLANATION,
  computeShadbala,
  rupa,
} from "../lib/shadbala";
import { rashiName, type Chart } from "../lib/astro";
import type { NativeInfo } from "../state/ChartContext";

function Head() {
  return (
    <div className="pdf-head">
      <Logo className="pdf-logo" />
      <div>
        <div className="pdf-inst">U K Jha Institute of Vedic Astrology</div>
        <div className="pdf-by">President · Er. Dr. U K Jha</div>
        <div className="pdf-sub">Vice-President · Astro Nisarg Sanatan · Gujarat Chapter — (+91) 9998074088</div>
      </div>
    </div>
  );
}

function Footer(_props: { page: number; total: number }) {
  return (
    <div className="pdf-foot">
      <span>U K Jha Institute of Vedic Astrology ; Er. Dr. U K Jha & Astro Nisarg Sanatan — (+91) 9998074088</span>
    </div>
  );
}

export default function ShadbalaPdfSections({
  chart,
  native,
  startPage,
  totalPages,
}: {
  chart: Chart;
  native: NativeInfo | null;
  startPage: number;
  totalPages: number;
}) {
  const result = computeShadbala(chart, native);
  const componentNames = result.planets[0].components.map((item) => item.name);

  return (
    <>
      <section className="pdf-page prediction-page">
        <Head />
        <h2 className="pdf-title">Shadbala · षड्बल · B.V. Raman / Parashari Worksheet</h2>
        <p className="pdf-note">
          Final Total = Sthana + Dig + Kala + Cheshta + Naisargika + Drik Bala. Values are in
          Virupas; 60 Virupas = 1 Rupa. प्रत्येक ग्रह का कुल बल छह घटकों के प्रत्यक्ष योग से निकला है।
        </p>
        <table className="pdf-meta">
          <tbody>
            <tr>
              <th>Strongest Planet</th>
              <td>{result.strongest.planet} · {result.strongest.totalVirupas.toFixed(2)} V</td>
              <th>Weakest Planet</th>
              <td>{result.weakest.planet} · {result.weakest.totalVirupas.toFixed(2)} V</td>
            </tr>
          </tbody>
        </table>
        <h3 className="pdf-h3">Planet Ranking & Required Strength</h3>
        <table className="pdf-table pdf-dense">
          <thead>
            <tr><th>Planet</th><th>D1 Rashi</th><th>Total V</th><th>Rupa</th><th>Required V</th><th>Ratio</th><th>Status</th></tr>
          </thead>
          <tbody>
            {result.planets.map((planet) => (
              <tr key={`pdf-shad-rank-${planet.planet}`}>
                <td className="font-semibold">{planet.planet}</td>
                <td>{chart[planet.planet].sign}. {rashiName(chart[planet.planet].sign)}</td>
                <td className="mono center">{planet.totalVirupas.toFixed(2)}</td>
                <td className="mono center">{rupa(planet.totalVirupas)}</td>
                <td className="mono center">{planet.requiredVirupas}</td>
                <td className="mono center">{(planet.ratio * 100).toFixed(1)}%</td>
                <td>{planet.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <h3 className="pdf-h3">All-Planet Component Matrix</h3>
        <table className="pdf-table pdf-dense shadbala-matrix">
          <thead>
            <tr>
              <th>Planet</th>
              {componentNames.map((name) => <th key={name}>{name}</th>)}
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {result.planets.map((planet) => (
              <tr key={`pdf-shad-matrix-${planet.planet}`}>
                <td className="font-semibold">{planet.planet}</td>
                {planet.components.map((component) => (
                  <td key={component.name} className="mono center">{component.virupas.toFixed(2)}</td>
                ))}
                <td className="mono center font-semibold">{planet.totalVirupas.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <h3 className="pdf-h3">How the Result Came · परिणाम कैसे आया</h3>
        <div className="pdf-two-column-text shadbala-explain">
          {SHADBALA_EXPLANATION.map((item) => (
            <p key={item.component}>
              <strong>{item.component}:</strong> {item.formula}. {item.english} {item.hindi}
            </p>
          ))}
        </div>
        <Footer page={startPage} total={totalPages} />
      </section>

      <section className="pdf-page prediction-page">
        <Head />
        <h2 className="pdf-title">Shadbala Details · Sthana Bala Sub-Workout</h2>
        <p className="pdf-note">
          Sthana Bala = Uchcha + Saptavargaja + Ojayugma + Kendradi + Drekkana. नीचे हर ग्रह का
          स्थान-बल खुला हुआ दिखाया गया है ताकि calculation traceable रहे।
        </p>
        <table className="pdf-table pdf-dense">
          <thead>
            <tr>
              <th>Planet</th>
              <th>Uchcha</th>
              <th>Saptavargaja</th>
              <th>Ojayugma</th>
              <th>Kendradi</th>
              <th>Drekkana</th>
              <th>Sthana Total</th>
            </tr>
          </thead>
          <tbody>
            {result.planets.map((planet) => (
              <tr key={`pdf-sthana-${planet.planet}`}>
                <td className="font-semibold">{planet.planet}</td>
                {planet.sthanaSub.map((sub) => (
                  <td key={sub.name} className="mono center">{sub.virupas.toFixed(2)}</td>
                ))}
                <td className="mono center font-semibold">
                  {planet.sthanaSub.reduce((sum, item) => sum + item.virupas, 0).toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <h3 className="pdf-h3">Selected Formula Data Notes</h3>
        <table className="pdf-table pdf-dense shadbala-notes-table">
          <thead><tr><th>Planet</th><th>Sub-Bala</th><th>Formula / Data Used</th></tr></thead>
          <tbody>
            {result.planets.flatMap((planet) =>
              planet.sthanaSub.map((sub) => (
                <tr key={`${planet.planet}-${sub.name}`}>
                  <td>{planet.planet}</td>
                  <td>{sub.sanskrit}<br /><span>{sub.name}</span></td>
                  <td>{sub.note}</td>
                </tr>
              )),
            )}
          </tbody>
        </table>
        <h3 className="pdf-h3">Method Transparency</h3>
        <ul className="pdf-numbered">
          {result.notes.map((note) => <li key={note}>{note}</li>)}
        </ul>
        <Footer page={startPage + 1} total={totalPages} />
      </section>
    </>
  );
}
