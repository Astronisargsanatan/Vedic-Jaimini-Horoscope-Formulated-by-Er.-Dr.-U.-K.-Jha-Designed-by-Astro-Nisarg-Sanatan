import { useMemo } from "react";
import NorthChart from "./NorthChart";
import {
  DASHVARGA_IDS,
  PLANETS,
  computeLagnaVaisheshika,
  computeKarakamshaD1Chart,
  computeVaisheshika,
  computeVarga,
  formatDMS,
  houseOf,
  rashiName,
  type Chart,
  type ChartSigns,
  type PlanetKey,
  type VaisheshikaResult,
} from "../lib/astro";
import { arudhaByHouse, computeArudhaPadas } from "../lib/arudha";
import { computeJaiminiCharKaraka } from "../lib/jaimini";
import {
  LEVEL_NAMES,
  LORD_HINDI,
  bhuktaBhogya,
  computeVimshottari,
  formatDate,
  formatDuration,
  type DashaPeriod,
} from "../lib/vimshottari";
import Logo from "./Logo";
import ExtendedPdfSections from "./ExtendedPdfSections";
import type { NativeInfo } from "../state/ChartContext";
import { computePanchang } from "../lib/panchang";
import PredictionPdfSections from "./PredictionPdfSections";
import VarshPraveshPdfSections from "./VarshPraveshPdfSections";
import ShadbalaPdfSections from "./ShadbalaPdfSections";
import { calculateEcpMetrics, type PraveshAnchor } from "../lib/dashaPravesh";

const COLUMN_LABELS: Record<PlanetKey, string> = {
  Lagna: "Lagn",
  Surya: "Surya",
  Chandra: "Chandra",
  Mangal: "Mangal",
  Budh: "Budh",
  Guru: "Guru",
  Shukra: "Shukra",
  Shani: "Shani",
  Rahu: "Rahu",
  Ketu: "Ketu",
};

export default function KundaliPdf({
  chart,
  native,
  engineeringVargaName,
  engineeringSigns,
  printDasha = true,
}: {
  chart: Chart;
  native: NativeInfo | null;
  engineeringVargaName: string;
  engineeringSigns: ChartSigns;
  printDasha?: boolean;
}) {
  const d1 = useMemo(() => computeVarga(chart, "D1"), [chart]);
  const arudha = useMemo(() => computeArudhaPadas(chart), [chart]);
  const arudhaHouses = useMemo(() => arudhaByHouse(arudha), [arudha]);
  const karakas = useMemo(() => computeJaiminiCharKaraka(chart), [chart]);
  const karakaMap = useMemo(
    () => new Map(karakas.map((k) => [k.key, k.karaka.role])),
    [karakas],
  );
  const d9 = useMemo(() => computeVarga(chart, "D9"), [chart]);
  const ak = karakas.find((item) => item.karaka.role === "AK");
  const karakamsha = useMemo(
    () => (ak ? computeKarakamshaD1Chart(chart, ak.key, d9) : { ...d1, Lagna: d9.Lagna }),
    [ak, chart, d1, d9],
  );
  const chandraKundali = useMemo(
    () => ({ ...d1, Lagna: d1.Chandra }),
    [d1],
  );
  const suryaKundali = useMemo(
    () => ({ ...d1, Lagna: d1.Surya }),
    [d1],
  );
  const panchang = useMemo(() => computePanchang(chart, native), [chart, native]);
  const generated = useMemo(
    () =>
      DASHVARGA_IDS.reduce(
        (rows, id) => {
          rows[id] = computeVarga(chart, id);
          return rows;
        },
        {} as Record<(typeof DASHVARGA_IDS)[number], ChartSigns>,
      ),
    [chart],
  );
  const vaisheshika = useMemo(
    () =>
      PLANETS.reduce(
        (scores, planet) => {
          const tenSigns = [...DASHVARGA_IDS.map((id) => generated[id][planet.key]), engineeringSigns[planet.key]];
          scores[planet.key] =
            planet.key === "Lagna"
              ? computeLagnaVaisheshika(chart, tenSigns)
              : computeVaisheshika(planet.key, tenSigns);
          return scores;
        },
        {} as Record<PlanetKey, VaisheshikaResult>,
      ),
    [chart, engineeringSigns, generated],
  );
  const repetitionRows = useMemo(() => {
    const rows = PLANETS.flatMap((planet) => {
      const occurrences = new Map<number, string[]>();
      DASHVARGA_IDS.forEach((id) => {
        const sign = generated[id][planet.key];
        occurrences.set(sign, [...(occurrences.get(sign) ?? []), id]);
      });
      const manual = engineeringSigns[planet.key];
      occurrences.set(manual, [
        ...(occurrences.get(manual) ?? []),
        engineeringVargaName || "Manual Varga",
      ]);
      return Array.from(occurrences.entries()).map(([sign, sources]) => ({
        planet: COLUMN_LABELS[planet.key],
        sign,
        sources,
        count: sources.length,
      }));
    });
    return rows
      .filter((row) => row.count > 1)
      .sort((a, b) => b.count - a.count || a.planet.localeCompare(b.planet) || a.sign - b.sign);
  }, [engineeringSigns, engineeringVargaName, generated]);

  const totalPages = printDasha ? 38 : 35;

  return (
    <div id="kundali-pdf" className="kundali-pdf hidden print:block">
      {/* PAGE 1 — MAIN KUNDALI */}
      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Main Kundali · Horoscope (D1 Rashi Chart)</h2>

        <table className="pdf-meta">
          <tbody>
            <tr>
              <th>Name</th>
              <td>{native?.fullName || "—"}</td>
              <th>Date of Birth</th>
              <td>{native?.date || "—"}</td>
            </tr>
            <tr>
              <th>Time of Birth</th>
              <td>{native?.time || "—"}</td>
              <th>Place of Birth</th>
              <td>{native?.place || "—"}</td>
            </tr>
            <tr>
              <th>Latitude / Longitude</th>
              <td>
                {native?.lat != null && native?.lon != null
                  ? `${native.lat.toFixed(2)}° / ${native.lon.toFixed(2)}°`
                  : "—"}
              </td>
              <th>Timezone</th>
              <td>{native?.tz || "IST (GMT+05:30)"}</td>
            </tr>
            <tr>
              <th>Ayanamsha</th>
              <td>{native?.ayanamsha || "Lahiri (Chitrapaksha)"}</td>
              <th>Lagna</th>
              <td>
                {chart.Lagna.sign}. {rashiName(chart.Lagna.sign)} · {formatDMS(chart.Lagna)}
              </td>
            </tr>
          </tbody>
        </table>

        <div className="pdf-chart-wrap">
          <NorthChart
            signs={d1}
            title="D1 · Rashi Kundali"
            subtitle="Lahiri Nirayana · Mean Rahu/Ketu"
            accent="#7c2d12"
          />
        </div>

        <h3 className="pdf-h3">Planetary Positions</h3>
        <table className="pdf-table">
          <thead>
            <tr>
              <th>Graha</th>
              <th>Rashi</th>
              <th>Longitude</th>
              <th>House</th>
              <th>Motion</th>
              <th>Char Karaka</th>
            </tr>
          </thead>
          <tbody>
            {PLANETS.map((p) => {
              const pos = chart[p.key as PlanetKey];
              const isNode = p.key === "Rahu" || p.key === "Ketu";
              return (
                <tr key={p.key}>
                  <td className="font-semibold">{p.label.split(" ")[0]}</td>
                  <td>
                    {pos.sign}. {rashiName(pos.sign)}
                  </td>
                  <td className="mono">{formatDMS(pos)}</td>
                  <td className="center">{houseOf(pos.sign, chart.Lagna.sign)}</td>
                  <td className="center">{pos.motion === "R" ? "R" : "D"}</td>
                  <td className="center">{isNode ? "—" : (karakaMap.get(p.key as PlanetKey) ?? "—")}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <PdfFooter page={1} total={totalPages} />
      </section>

      {/* PAGE 2 — PANCHANG AND AVAKAHADA */}
      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Birth Panchang · Panchanga & Avakahada Details</h2>
        <p className="pdf-note">
          Tithi, Vara, Nakshatra, Yoga, Karana, calendar measures, astronomical values and
          Avakahada Chakra from the Home birth dataset.
        </p>

        <h3 className="pdf-h3">Primary Panchanga Elements</h3>
        <table className="pdf-table">
          <tbody>
            <tr>
              <th>Tithi</th><td>{panchang.tithi}</td>
              <th>Vara</th><td>{panchang.vara}</td>
              <th>Nakshatra</th><td>{panchang.nakshatra} · Pada {panchang.nakshatraPada}</td>
            </tr>
            <tr>
              <th>Yoga</th><td>{panchang.yoga}</td>
              <th>Karana</th><td>{panchang.karana}</td>
              <th>Paksha</th><td>{panchang.paksha}</td>
            </tr>
          </tbody>
        </table>

        <h3 className="pdf-h3">Samvatsara & Calendar Details</h3>
        <table className="pdf-table pdf-dense">
          <tbody>
            <tr><th>Samvatsara</th><td>{panchang.samvatsara}</td><th>Vikram Samvat</th><td>{panchang.vikramSamvat}</td><th>Shaka Samvat</th><td>{panchang.shakaSamvat}</td></tr>
            <tr><th>Masa</th><td>{panchang.masa}</td><th>Ayana</th><td>{panchang.ayana}</td><th>Gola</th><td>{panchang.gola}</td></tr>
            <tr><th>Ritu</th><td>{panchang.ritu}</td><th>Tithi No.</th><td>{panchang.tithiNumber}/30</td><th>Moon Rashi</th><td>{panchang.rashi}</td></tr>
          </tbody>
        </table>

        <h3 className="pdf-h3">Astronomical & Epoch Data</h3>
        <table className="pdf-table pdf-dense">
          <tbody>
            <tr><th>Suryodaya</th><td>{panchang.sunrise}</td><th>Suryasta</th><td>{panchang.sunset}</td><th>Sampatika Kala</th><td>{panchang.sampatikaKala}</td></tr>
            <tr><th>Ayanamsha</th><td>{panchang.ayanamsha}</td><th>Divamana</th><td>{panchang.divamana}</td><th>Ratrimana</th><td>{panchang.ratrimana}</td></tr>
          </tbody>
        </table>

        <h3 className="pdf-h3">Avakahada Chakra Details</h3>
        <table className="pdf-table pdf-dense">
          <tbody>
            <tr><th>Varna</th><td>{panchang.varna}</td><th>Tattva</th><td>{panchang.tattva}</td><th>Hamsaka</th><td>{panchang.hamsaka}</td></tr>
            <tr><th>Gana</th><td>{panchang.gana}</td><th>Yoni</th><td>{panchang.yoni}</td><th>Yunja</th><td>{panchang.yunja}</td></tr>
            <tr><th>Nadi</th><td>{panchang.nadi}</td><th>Rajju</th><td>{panchang.rajju}</td><th>Vashya</th><td>{panchang.vashya}</td></tr>
            <tr><th>Rashi</th><td>{panchang.rashi}</td><th>Rashisha</th><td>{panchang.rashisha}</td><th>Paya</th><td>{panchang.paya}</td></tr>
            <tr><th>Rashi Akshara</th><td colSpan={2}>{panchang.rashiAkshara}</td><th>Nakshatra Akshara</th><td colSpan={2}>{panchang.nakshatraSyllables}</td></tr>
            <tr><th>Name Syllable</th><td>{panchang.nameSyllable}</td><th>Nakshatra</th><td>{panchang.nakshatra}</td><th>Pada</th><td>{panchang.nakshatraPada}</td></tr>
          </tbody>
        </table>
        <PdfFooter page={2} total={totalPages} />
      </section>

      {/* PAGE 3 — ARUDHA, KARAKAMSHA, CHANDRA AND SURYA REFERENCE CHARTS */}
      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Arudha · Karakamsha · Chandra · Surya Kundali</h2>
        <p className="pdf-note">
          Four reference charts: Arudha Padas, Karakamsha Lagna, Chandra Lagna and Surya Lagna.
        </p>

        <div className="pdf-chart-quartet">
          <div>
            <NorthChart
              signs={d1}
              title="Arudha Kundali"
              subtitle="AL · A2 … A12"
              accent="#0f766e"
              arudhaByHouse={arudhaHouses}
              showPlanets
            />
          </div>
          <div>
            <NorthChart
              signs={karakamsha}
              title="Karakamsha Kundali"
              subtitle={ak ? `AK D9 Rashi ${d9[ak.key]} = D1 Karakamsha Lagna` : "D1 signs retained"}
              accent="#3730a3"
            />
          </div>
          <div>
            <NorthChart
              signs={chandraKundali}
              title="Chandra Kundali"
              subtitle={`Chandra Lagna: ${d1.Chandra}. ${rashiName(d1.Chandra)}`}
              accent="#1d4ed8"
            />
          </div>
          <div>
            <NorthChart
              signs={suryaKundali}
              title="Surya Kundali"
              subtitle={`Surya Lagna: ${d1.Surya}. ${rashiName(d1.Surya)}`}
              accent="#92400e"
            />
          </div>
        </div>

        <h3 className="pdf-h3">Arudha Pada Summary</h3>
        <table className="pdf-table pdf-dense">
          <thead>
            <tr>
              <th>Pada</th>
              <th>Bhava</th>
              <th>Bhavesh</th>
              <th>Lord from Bhava</th>
              <th>Arudha Rashi</th>
              <th>Arudha House</th>
            </tr>
          </thead>
          <tbody>
            {arudha.map((a) => (
              <tr key={a.label}>
                <td className="font-semibold">{a.label}</td>
                <td className="center">{a.bhava}</td>
                <td>{a.lord}</td>
                <td className="center">{a.lordFromBhava}th</td>
                <td>
                  {a.arudhaSign}. {rashiName(a.arudhaSign)}
                </td>
                <td className="center">{a.arudhaHouse}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <PdfFooter page={3} total={totalPages} />
      </section>

      {/* PAGE 3 — CHAR KARAKA */}
      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Jaimini 7 Char Karaka · सप्त चरकारक</h2>
        <p className="pdf-note">
          Ranked by Navamsha Traversed Longitude (highest to lowest). Rahu and Ketu are excluded. Nodes have no lordship.
        </p>

        <table className="pdf-table">
          <thead>
            <tr>
              <th>Rank</th>
              <th>Char Karaka</th>
              <th>Role</th>
              <th>Graha</th>
              <th>Local D°M′S″</th>
              <th>Navamsha</th>
              <th>Traversed Arc</th>
            </tr>
          </thead>
          <tbody>
            {karakas.map((k) => (
              <tr key={k.key}>
                <td className="center">{k.rank}</td>
                <td className="font-semibold">{k.karaka.devanagari}</td>
                <td>
                  {k.karaka.role} · {k.karaka.sanskrit}
                </td>
                <td>{k.label.split(" ")[0]}</td>
                <td className="mono">{k.localDMS}</td>
                <td className="center">{k.navamshaNum}</td>
                <td className="mono">{k.traversedDMS}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <h3 className="pdf-h3">Karaka Signification</h3>
        <table className="pdf-table">
          <thead>
            <tr>
              <th>Karaka</th>
              <th>Assigned Graha</th>
              <th>Focus</th>
            </tr>
          </thead>
          <tbody>
            {karakas.map((k) => (
              <tr key={`sig-${k.key}`}>
                <td>
                  {k.karaka.devanagari} ({k.karaka.role})
                </td>
                <td>{k.label.split(" ")[0]}</td>
                <td>{k.karaka.english}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <PdfFooter page={4} total={totalPages} />
      </section>

      {/* PAGE 4 — DASHVARGA + VAISHESHIKA (the separate divisional table was removed) */}
      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Dashvarga Summary · Vaisheshika Amsha</h2>
        <p className="pdf-note">
          Includes manual 10th slot “{engineeringVargaName || "Manual Varga"}” and Vaisheshika Amsha score/title.
        </p>

        <table className="pdf-table pdf-dense">
          <thead>
            <tr>
              <th>Dashvarga</th>
              {PLANETS.map((planet) => (
                <th key={`hdr-${planet.key}`}>{COLUMN_LABELS[planet.key]}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {DASHVARGA_IDS.map((id) => (
              <tr key={id}>
                <td className="font-semibold">{id}</td>
                {PLANETS.map((planet) => (
                  <td key={`${id}-${planet.key}`} className="center mono">
                    {generated[id][planet.key]}
                  </td>
                ))}
              </tr>
            ))}
            <tr>
              <td className="font-semibold">{engineeringVargaName || "Manual Varga"}</td>
              {PLANETS.map((planet) => (
                <td key={`VE-${planet.key}`} className="center mono">
                  {engineeringSigns[planet.key]}
                </td>
              ))}
            </tr>
            <tr>
              <td className="font-semibold">Vaisheshika</td>
              {PLANETS.map((planet) => (
                <td key={`VAI-${planet.key}`} className="center">
                  {vaisheshika[planet.key].applicable
                    ? `${vaisheshika[planet.key].score}/10 ${vaisheshika[planet.key].title}`
                    : "N/A"}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
        <PdfFooter page={5} total={totalPages} />
      </section>

      {/* PAGE 5 — VARGA GRAHA-RASHI REPETITION */}
      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Varga Graha–Rashi Repetition Summary</h2>
        <p className="pdf-note">
          D1, D2, D3, D4, D5, D6, D8, D9, D10 and the selected Varga Engineering slot.
          Only repeated Graha–Rashi pairs are shown, highest repetition first.
        </p>
        <table className="pdf-table pdf-dense">
          <thead>
            <tr>
              <th>Rank</th>
              <th>Graha / Lagn</th>
              <th>Rashi</th>
              <th>Repetition Count</th>
              <th>Found in Vargas</th>
            </tr>
          </thead>
          <tbody>
            {repetitionRows.map((row, index) => (
              <tr key={`${row.planet}-${row.sign}`}>
                <td className="center">{index + 1}</td>
                <td className="font-semibold">{row.planet}</td>
                <td>{row.sign}. {rashiName(row.sign)}</td>
                <td className="center mono font-semibold">{row.count} times</td>
                <td>{row.sources.join(" · ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <PdfFooter page={6} total={totalPages} />
      </section>

      {/* PAGES 6–8 — VIMSHOTTARI DASHA */}
      {printDasha && (
        <VimshottariPages
          chart={chart}
          native={native}
          startIndex={7}
          totalPages={totalPages}
        />
      )}

      <ExtendedPdfSections
        chart={chart}
        native={native}
        startPage={printDasha ? 10 : 7}
        totalPages={totalPages}
      />

      <VarshPraveshPdfSections
        natal={chart}
        native={native}
        startPage={printDasha ? 27 : 24}
        totalPages={totalPages}
      />

      <ShadbalaPdfSections
        chart={chart}
        native={native}
        startPage={printDasha ? 30 : 27}
        totalPages={totalPages}
      />

      <PredictionPdfSections
        chart={chart}
        native={native}
        engineeringSigns={engineeringSigns}
        startPage={printDasha ? 32 : 29}
        totalPages={totalPages}
      />
    </div>
  );
}

function birthInstant(native: NativeInfo | null): Date {
  // Prefer the exact UTC instant resolved by Home (includes IST/local offset).
  if (native?.birthUtc) {
    const d = new Date(native.birthUtc);
    if (!Number.isNaN(d.getTime())) return d;
  }
  const m = (native?.date ?? "").trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!m) return new Date();
  const t = (native?.time ?? "").trim().match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  // Fallback: treat wall-clock DOB/TOB as IST (+05:30).
  return new Date(
    Date.UTC(
      Number(m[3]),
      Number(m[2]) - 1,
      Number(m[1]),
      t ? Number(t[1]) : 12,
      t ? Number(t[2]) : 0,
      t ? Number(t[3] ?? 0) : 0,
    ) - 330 * 60000,
  );
}

function VimshottariPages({
  chart,
  native,
  startIndex,
  totalPages,
}: {
  chart: Chart;
  native: NativeInfo | null;
  startIndex: number;
  totalPages: number;
}) {
  const birth = birthInstant(native);
  const now = new Date();
  const v = computeVimshottari(chart, birth, now);

  // Current Mahadasha → its Antardashas → its Pratyantardashas
  const activeMaha = v.activePath[0] ?? v.mahadashas[0];
  const activeAntar = v.activePath[1];
  const activePraty = v.activePath[2];
  const activeSukshma = v.activePath[3];
  const activePran = v.activePath[4];
  const bb = (p?: DashaPeriod) => (p ? bhuktaBhogya(p, now) : null);
  const activeAnchors: PraveshAnchor[] = [
    ...(activeMaha ? [{ level: "Mahadasha" as const, name: activeMaha.lord, start: activeMaha.start }] : []),
    ...(activeAntar ? [{ level: "Antardasha" as const, name: activeAntar.lord, start: activeAntar.start }] : []),
    ...(activePraty ? [{ level: "Pratyantar Dasha" as const, name: activePraty.lord, start: activePraty.start }] : []),
  ];
  const ecpMetrics = native?.lat != null && native.lon != null
    ? calculateEcpMetrics(native, activeAnchors)
    : [];

  return (
    <>
      {/* PAGE 6 — Vimshottari overview + Mahadasha table */}
      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Vimshottari Dasha · प्रचलित यवन विंशोत्तरी दशा</h2>
        <p className="pdf-note">
          चन्द्रमा की डिग्री (नक्षत्र + traversed भाग) से गणना · 120 वर्ष चक्र · वैदिक वर्ष 365.25 दिन
        </p>

        <table className="pdf-meta">
          <tbody>
            <tr>
              <th>जन्म नक्षत्र</th>
              <td>
                {v.moon.nakshatraName} · पद {v.moon.pada}
              </td>
              <th>नक्षत्र स्वामी</th>
              <td>{LORD_HINDI[v.moon.nakshatraLord]}</td>
            </tr>
            <tr>
              <th>चन्द्र राशि</th>
              <td>
                {chart.Chandra.sign}. {rashiName(chart.Chandra.sign)}
              </td>
              <th>चन्द्र देशान्तर</th>
              <td className="mono">{v.moon.moonLongitude.toFixed(4)}°</td>
            </tr>
            <tr>
              <th>जन्म तिथि / समय</th>
              <td className="mono">
                {native?.date || "—"} · {native?.time || "—"}
              </td>
              <th>भुक्त काल (बीता)</th>
              <td>{formatDuration(v.bhuktaAtBirthMs)}</td>
            </tr>
            <tr>
              <th>भोग्य काल (DOB में जुड़ेगा)</th>
              <td>{formatDuration(v.bhogyaAtBirthMs)}</td>
              <th>
                {LORD_HINDI[v.moon.nakshatraLord]} महादशा अंत (DOB + भोग्य)
              </th>
              <td className="mono">
                {formatDate(new Date(birth.getTime() + v.bhogyaAtBirthMs))}
              </td>
            </tr>
          </tbody>
        </table>

        <p className="pdf-note">
          <strong>विधि:</strong> चन्द्रमा {v.moon.nakshatraName} नक्षत्र ({(v.moon.traversedFraction * 100).toFixed(2)}% traversed) में है;
          नक्षत्र-स्वामी {LORD_HINDI[v.moon.nakshatraLord]} से दशा आरम्भ। भोग्य काल जन्म-तिथि में जोड़ा जाता है।
        </p>

        <h3 className="pdf-h3">वर्तमान चालू दशा (Active)</h3>
        <table className="pdf-table pdf-dense">
          <thead>
            <tr>
              <th>स्तर</th>
              <th>स्वामी</th>
              <th>आरंभ</th>
              <th>अंत</th>
              <th>भुक्त काल</th>
              <th>भोग्य काल</th>
            </tr>
          </thead>
          <tbody>
            {[activeMaha, activeAntar, activePraty, activeSukshma, activePran].map((p, i) =>
              p ? (
                <tr key={`act-${i}`}>
                  <td>{LEVEL_NAMES[p.level]}</td>
                  <td>
                    {LORD_HINDI[p.lord]} · {p.lord}
                  </td>
                  <td className="mono">{formatDate(p.start)}</td>
                  <td className="mono">{formatDate(p.end)}</td>
                  <td className="mono">{bb(p)!.bhuktaLabel}</td>
                  <td className="mono">{bb(p)!.bhogyaLabel}</td>
                </tr>
              ) : null,
            )}
          </tbody>
        </table>

        <h3 className="pdf-h3">Dasha Pravesh · ECPM / ECPA / ECPP</h3>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>Metric</th><th>Period</th><th>Pravesh Lagna</th><th>Controller</th><th>Calculation</th></tr></thead>
          <tbody>
            {ecpMetrics.map((metric) => (
              <tr key={metric.code}>
                <td className="font-semibold">{metric.code}</td><td>{metric.periodName}</td>
                <td>{metric.lagnaSign}. {rashiName(metric.lagnaSign)}</td><td>{metric.controller}</td>
                <td>{metric.code} = {metric.periodName} Pravesh chart Lagna Lord / Lagnesh</td>
              </tr>
            ))}
            {ecpMetrics.length === 0 && <tr><td colSpan={5}>Birth coordinates required for ECP calculation.</td></tr>}
          </tbody>
        </table>

        <h3 className="pdf-h3">महादशा तालिका (जन्म से)</h3>
        <table className="pdf-table pdf-dense">
          <thead>
            <tr>
              <th>महादशा</th>
              <th>आरंभ</th>
              <th>अंत</th>
              <th>अवधि</th>
              <th>वर्ष</th>
            </tr>
          </thead>
          <tbody>
            {v.mahadashas.slice(0, 9).map((m, i) => (
              <tr key={`m-${i}`}>
                <td>
                  {LORD_HINDI[m.lord]} · {m.lord}
                </td>
                <td className="mono">{formatDate(m.start)}</td>
                <td className="mono">{formatDate(m.end)}</td>
                <td className="mono">{formatDuration(m.durationMs)}</td>
                <td className="center">{m.durationMs / (365.25 * 24 * 3600 * 1000)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <PdfFooter page={startIndex} total={totalPages} />
      </section>

      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Compact Mahadasha-Antardasha Tables · 1–5</h2>
        <p className="pdf-note">
          Each Mahadasha block shows only Antardasha, Start and End dates. Dates are DD-MM-YYYY.
        </p>
        <div className="pdf-compact-dasha-stack">
          {v.mahadashas.slice(0, 5).map((maha) => (
            <CompactMahaBlock key={`compact-maha-a-${maha.lord}`} maha={maha} birth={birth} native={native} />
          ))}
        </div>
        <PdfFooter page={startIndex + 1} total={totalPages} />
      </section>

      <section className="pdf-page">
        <PdfLetterhead />
        <h2 className="pdf-title">Compact Mahadasha-Antardasha Tables · 6–9</h2>
        <p className="pdf-note">
          Summary box under each Mahadasha gives Dasha Pravesh, ECPM, ECPA and ECPP.
        </p>
        <div className="pdf-compact-dasha-stack is-four">
          {v.mahadashas.slice(5, 9).map((maha) => (
            <CompactMahaBlock key={`compact-maha-b-${maha.lord}`} maha={maha} birth={birth} native={native} />
          ))}
        </div>
        <PdfFooter page={startIndex + 2} total={totalPages} />
      </section>
    </>
  );
}

function compactDate(date: Date): string {
  return `${String(date.getUTCDate()).padStart(2, "0")}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${date.getUTCFullYear()}`;
}

function ageLabel(birth: Date, date: Date): string {
  return formatDuration(Math.max(0, date.getTime() - birth.getTime()));
}

function compactEcp(native: NativeInfo | null, maha: DashaPeriod) {
  if (!native || native.lat == null || native.lon == null) return { ECPM: "—", ECPA: "—", ECPP: "—" };
  const firstAntar = maha.children?.[0];
  const firstPratyantar = firstAntar?.children?.[0];
  const anchors: PraveshAnchor[] = [
    { level: "Mahadasha", name: maha.lord, start: maha.start },
    ...(firstAntar ? [{ level: "Antardasha" as const, name: firstAntar.lord, start: firstAntar.start }] : []),
    ...(firstPratyantar
      ? [{ level: "Pratyantar Dasha" as const, name: firstPratyantar.lord, start: firstPratyantar.start }]
      : []),
  ];
  const values = calculateEcpMetrics(native, anchors);
  const get = (code: "ECPM" | "ECPA" | "ECPP") => {
    const hit = values.find((item) => item.code === code);
    return hit ? `${hit.controller} (${hit.lagnaSign}. ${rashiName(hit.lagnaSign)})` : "—";
  };
  return { ECPM: get("ECPM"), ECPA: get("ECPA"), ECPP: get("ECPP") };
}

function CompactMahaBlock({ maha, birth, native }: { maha: DashaPeriod; birth: Date; native: NativeInfo | null }) {
  const ecp = compactEcp(native, maha);
  return (
    <section className="pdf-compact-dasha-block">
      <header className="pdf-compact-dasha-head">
        <strong>{LORD_HINDI[maha.lord]} Mahadasha · {maha.lord}</strong>
        <span>Total {formatDuration(maha.durationMs)} · Age {ageLabel(birth, maha.start)} - {ageLabel(birth, maha.end)}</span>
      </header>
      <table className="pdf-table pdf-dasha-mini">
        <thead><tr><th>अन्तर्दशा</th><th>आरम्भ</th><th>अन्त</th></tr></thead>
        <tbody>
          {(maha.children ?? []).map((antar) => (
            <tr key={`${maha.lord}-${antar.lord}`}>
              <td>{LORD_HINDI[antar.lord]} · {antar.lord}</td>
              <td className="mono">{compactDate(antar.start)}</td>
              <td className="mono">{compactDate(antar.end)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="pdf-dasha-summary-box">
        <div><b>दशा प्रवेश</b><span>{compactDate(maha.start)}</span></div>
        <div><b>ECPM</b><span>{ecp.ECPM}</span></div>
        <div><b>ECPA</b><span>{ecp.ECPA}</span></div>
        <div><b>ECPP</b><span>{ecp.ECPP}</span></div>
      </div>
    </section>
  );
}

function PdfLetterhead() {
  return (
    <div className="pdf-head">
      <Logo className="pdf-logo" />
      <div>
        <div className="pdf-inst">U K Jha Institute of Vedic Astrology</div>
        <div className="pdf-by">President · Er. Dr. U K Jha</div>
        <div className="pdf-sub">
          Vice-President · Astro Nisarg Sanatan · Gujarat Chapter — (+91) 9998074088
        </div>
      </div>
    </div>
  );
}

function PdfFooter(_props: { page: number; total: number }) {
  return (
    <div className="pdf-foot">
      <span>U K Jha Institute of Vedic Astrology ; Er. Dr. U K Jha & Astro Nisarg Sanatan — (+91) 9998074088</span>
    </div>
  );
}
