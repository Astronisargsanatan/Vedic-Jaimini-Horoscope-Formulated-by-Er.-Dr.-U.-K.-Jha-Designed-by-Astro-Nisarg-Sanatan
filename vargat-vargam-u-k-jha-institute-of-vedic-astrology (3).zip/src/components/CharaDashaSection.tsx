import { useMemo, useState } from "react";
import {
  SAMA_PADA_SIGNS,
  VISHAMA_PADA_SIGNS,
  computeCharaDasha,
  formatCharaDateTime,
} from "../lib/charaDasha";
import { rashiName } from "../lib/astro";
import { useChart } from "../state/ChartContext";
import DashaPraveshModal from "./DashaPraveshModal";
import type { DashaPraveshRequest } from "../lib/dashaPravesh";

function birthInstant(date?: string, time?: string, birthUtc?: string): Date {
  if (birthUtc) {
    const resolved = new Date(birthUtc);
    if (!Number.isNaN(resolved.getTime())) return resolved;
  }
  const d = (date ?? "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const t = (time ?? "").match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  if (!d) return new Date();
  return new Date(
    Date.UTC(
      Number(d[3]),
      Number(d[2]) - 1,
      Number(d[1]),
      t ? Number(t[1]) : 12,
      t ? Number(t[2]) : 0,
      t ? Number(t[3] ?? 0) : 0,
    ) - (birthUtc ? 0 : 330 * 60000),
  );
}

export default function CharaDashaSection() {
  const { chart, native } = useChart();
  const [pravesh, setPravesh] = useState<DashaPraveshRequest | null>(null);
  const birth = useMemo(
    () => birthInstant(native?.date, native?.time, native?.birthUtc),
    [native],
  );
  const result = useMemo(() => computeCharaDasha(chart, birth), [chart, birth]);
  const now = new Date();
  const active = result.periods.find((period) => now >= period.start && now < period.end);
  const displayTimeZone = native?.tz;

  return (
    <section
      id="char-dasha"
      className="scroll-mt-24 overflow-hidden rounded-3xl border border-amber-800/20 bg-white/85 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.55)]"
    >
      <header className="bg-gradient-to-r from-[#7c2d12] to-[#9a3412] px-5 py-5 text-amber-50 sm:px-6">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-amber-200">
          जैमिनि उपदेश सूत्रम् · Bhagya Pada A9 Based
        </div>
        <h2 className="mt-1 font-serif text-2xl font-black sm:text-3xl">Char Dasha</h2>
        <p className="mt-2 max-w-4xl text-xs leading-relaxed text-amber-100/85">
          प्रथम दशा = 9वें भाव का आरूढ़, A9 (Bhagya Pada)। उसके बाद क्रम की दिशा A1/AL की
          राशि तय करती है: Vishama Pada हो तो direct, Sama Pada हो तो reverse।
        </p>
      </header>

      <div className="space-y-5 p-5 sm:p-6">
        {!native?.date && (
          <div className="rounded-xl border-2 border-amber-500 bg-amber-50 px-4 py-3 text-xs text-amber-900">
            सही दशा तिथियों के लिए पहले Home पर Birth Details calculate करें। अभी sample chart और
            वर्तमान reference date उपयोग हो रही है।
          </div>
        )}

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Info label="Bhagya Pada · A9" value={`${result.a9Sign}. ${rashiName(result.a9Sign)}`} />
          <Info label="Lagna Pada · AL/A1" value={`${result.a1Sign}. ${rashiName(result.a1Sign)}`} />
          <Info
            label="Sequence Direction"
            value={result.direction === "Direct" ? "Direct · आगे" : "Reverse · उल्टा"}
            accent={result.direction === "Direct" ? "emerald" : "rose"}
          />
          <Info label="Uniform Madhya Bindu" value={result.lagnaMadhyaDms} accent="indigo" />
        </div>

        <div className="rounded-2xl border border-indigo-700/15 bg-indigo-50/70 p-4 text-xs leading-relaxed text-indigo-950">
          <strong>Direction Rule:</strong> AL/A1 = {rashiName(result.a1Sign)} ({result.a1Sign}) जो{" "}
          <strong>{result.direction === "Direct" ? "Vishama Pada" : "Sama Pada"}</strong> है। अतः
          A9 {rashiName(result.a9Sign)} से sequence{" "}
          <strong>{result.direction === "Direct" ? "आगे" : "उल्टे"}</strong> क्रम में चलेगा।
          <div className="mt-2 flex flex-wrap gap-1.5">
            {result.sequence.map((sign, index) => (
              <span
                key={`${sign}-${index}`}
                className={`rounded-lg px-2 py-1 font-mono text-[11px] font-bold ${
                  index === 0
                    ? "bg-[#7c2d12] text-white"
                    : "border border-indigo-800/15 bg-white text-indigo-800"
                }`}
              >
                {index + 1}. {sign} {rashiName(sign)}
              </span>
            ))}
          </div>
        </div>

        {active && (
          <div className="rounded-2xl border-2 border-emerald-500/40 bg-emerald-50 px-4 py-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
              Active Char Dasha
            </div>
            <div className="mt-1 font-serif text-xl font-black text-emerald-900">
              {active.sign}. {active.signName}
            </div>
            <div className="mt-0.5 font-mono text-xs text-emerald-800">
              {formatCharaDateTime(active.start, displayTimeZone)} →{" "}
              {formatCharaDateTime(active.end, displayTimeZone)} · {active.duration.label}
            </div>
          </div>
        )}

        <div className="overflow-x-auto rounded-2xl border border-amber-800/15">
          <table className="w-full min-w-[1450px] text-sm">
            <thead>
              <tr className="border-b-2 border-amber-800/20 bg-amber-50 text-left text-[10px] font-bold uppercase tracking-[0.1em] text-amber-900">
                <th className="px-3 py-3 text-center">#</th>
                <th className="px-3 py-3">Dasha Rashi</th>
                <th className="px-3 py-3">Pada Class</th>
                <th className="px-3 py-3">Rashi Lord</th>
                <th className="px-3 py-3">Madhya Bindu</th>
                <th className="px-3 py-3">Lord Longitude</th>
                <th className="px-3 py-3">Angular Difference</th>
                <th className="px-3 py-3">Duration</th>
                <th className="px-3 py-3">Start</th>
                <th className="px-3 py-3">End</th>
                <th className="px-3 py-3">Cumulative Addition Proof</th>
                <th className="px-3 py-3">Pravesh Chart</th>
              </tr>
            </thead>
            <tbody>
              {result.periods.map((period) => {
                const isActive = active === period;
                return (
                  <tr
                    key={period.order}
                    className={`border-b border-stone-200/70 last:border-0 ${
                      isActive ? "bg-emerald-50" : period.order % 2 === 0 ? "bg-[#fdfaf4]" : "bg-white"
                    }`}
                  >
                    <td className="px-3 py-2 text-center font-mono text-stone-400">{period.order}</td>
                    <td className="px-3 py-2 font-serif font-bold text-[#7c2d12]">
                      {period.sign}. {period.signName}
                      {isActive && (
                        <span className="ml-2 rounded-full bg-emerald-600 px-2 py-0.5 text-[9px] font-bold text-white">
                          ACTIVE
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2">
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          period.classification === "Vishama Pada"
                            ? "bg-emerald-100 text-emerald-800"
                            : "bg-rose-100 text-rose-800"
                        }`}
                      >
                        {period.classification}
                      </span>
                    </td>
                    <td className="px-3 py-2 font-semibold text-stone-800">{period.lord}</td>
                    <td className="px-3 py-2 font-mono text-xs text-indigo-700">
                      {period.madhyaLongitudeDms}
                    </td>
                    <td className="px-3 py-2 font-mono text-xs text-stone-600">
                      <div className="font-bold text-[#7c2d12]">{period.lord}</div>
                      <div>{period.lordLongitudeDms}</div>
                    </td>
                    <td className="px-3 py-2">
                      <div className="font-mono text-xs font-bold text-[#9a3412]">{period.differenceDms}</div>
                      <div className="mt-0.5 text-[9px] text-stone-400">{period.formula}</div>
                    </td>
                    <td className="px-3 py-2 font-mono text-xs font-bold text-stone-800">
                      {period.duration.label}
                    </td>
                    <td className="px-3 py-2 font-mono text-xs text-stone-600">
                      {formatCharaDateTime(period.start, displayTimeZone)}
                    </td>
                    <td className="px-3 py-2 font-mono text-xs text-stone-600">
                      {formatCharaDateTime(period.end, displayTimeZone)}
                    </td>
                    <td className="px-3 py-2 text-[10px] leading-relaxed text-stone-600">
                      <div>{period.additionProof}</div>
                      <div className="mt-0.5 font-mono font-semibold text-indigo-700">
                        {formatCharaDateTime(period.start, displayTimeZone)} + {period.duration.label}
                        {" = "}
                        {formatCharaDateTime(period.end, displayTimeZone)}
                      </div>
                    </td>
                    <td className="px-3 py-2">
                      <button
                        type="button"
                        onClick={() =>
                          setPravesh({
                            system: "Jaimini Chara Dasha",
                            selected: {
                              level: "Mahadasha",
                              name: `${period.sign}. ${period.signName}`,
                              start: period.start,
                            },
                            path: [
                              {
                                level: "Mahadasha",
                                name: `${period.sign}. ${period.signName}`,
                                start: period.start,
                              },
                            ],
                          })
                        }
                        className="whitespace-nowrap rounded-lg border border-indigo-700/20 bg-indigo-50 px-2 py-1 text-[9px] font-bold text-indigo-800 hover:bg-indigo-100"
                      >
                        View Dasha Pravesh Chart
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-2xl border border-emerald-700/20 bg-emerald-50 p-4 text-xs leading-relaxed text-emerald-950">
            <strong>Vishama Pada:</strong> {VISHAMA_PADA_SIGNS.map((s) => `${s} ${rashiName(s)}`).join(", ")}।
            Formula = Sign Lord Longitude − उस Rashi का Madhya Bindu।
          </div>
          <div className="rounded-2xl border border-rose-700/20 bg-rose-50 p-4 text-xs leading-relaxed text-rose-950">
            <strong>Sama Pada:</strong> {SAMA_PADA_SIGNS.map((s) => `${s} ${rashiName(s)}`).join(", ")}।
            Formula = उस Rashi का Madhya Bindu − Sign Lord Longitude। Negative हो तो 360° जोड़ें।
          </div>
        </div>

        <div className="rounded-2xl border border-amber-700/20 bg-amber-50 px-4 py-3 text-xs leading-relaxed text-amber-950">
          <strong>Time Base:</strong> 1 Rashi (30°) = 1 Solar Year = 365.25 days; 1° = 12.175 days;
          1 month = 30.4375 days. Duration exact Years, Months, Days, Hours, Minutes, Seconds में है।
        </div>

        <div className="rounded-2xl border-2 border-indigo-500/25 bg-indigo-50 p-4 text-xs leading-relaxed text-indigo-950">
          <strong>Date-Time Addition Check:</strong> पहली दशा का Start Home के exact birth instant
          से होता है। उसकी पूर्ण अवधि (वर्ष-माह-दिन के साथ HH:MM:SS) उसी birth instant में जोड़ी
          जाती है। दूसरी दशा का Start पहली का exact End है; तीसरी का Start दूसरी का exact End —
          इस प्रकार कोई hour/minute/second हटाया नहीं जाता। ऊपर अंतिम column में हर row का
          arithmetic proof दिखाया गया है।
        </div>
        <DashaPraveshModal request={pravesh} native={native} onClose={() => setPravesh(null)} />
      </div>
    </section>
  );
}

function Info({
  label,
  value,
  accent = "amber",
}: {
  label: string;
  value: string;
  accent?: "amber" | "emerald" | "rose" | "indigo";
}) {
  const tones = {
    amber: "border-amber-800/15 bg-amber-50 text-amber-900",
    emerald: "border-emerald-700/20 bg-emerald-50 text-emerald-900",
    rose: "border-rose-700/20 bg-rose-50 text-rose-900",
    indigo: "border-indigo-700/20 bg-indigo-50 text-indigo-900",
  };
  return (
    <div className={`rounded-2xl border px-4 py-3 ${tones[accent]}`}>
      <div className="text-[9px] font-bold uppercase tracking-wider opacity-75">{label}</div>
      <div className="mt-1 font-serif text-lg font-black">{value}</div>
    </div>
  );
}