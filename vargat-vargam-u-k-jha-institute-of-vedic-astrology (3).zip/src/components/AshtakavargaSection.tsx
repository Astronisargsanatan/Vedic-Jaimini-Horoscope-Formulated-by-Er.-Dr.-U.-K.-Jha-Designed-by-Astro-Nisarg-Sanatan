import { useMemo } from "react";
import {
  BAV_DISPLAY,
  BAV_KEYS,
  KAKSHYA_ORDER,
  computeAshtakavarga,
  type AshtakavargaKey,
} from "../lib/ashtakavarga";
import { PLANETS, rashiName, type Chart } from "../lib/astro";
import { useChart } from "../state/ChartContext";

const HOUSE_POS = [
  { x: 150, y: 62 },
  { x: 75, y: 32 },
  { x: 32, y: 75 },
  { x: 62, y: 150 },
  { x: 32, y: 225 },
  { x: 75, y: 268 },
  { x: 150, y: 238 },
  { x: 225, y: 268 },
  { x: 268, y: 225 },
  { x: 238, y: 150 },
  { x: 268, y: 75 },
  { x: 225, y: 32 },
];

const SHORT: Record<AshtakavargaKey, string> = {
  Surya: "Su",
  Chandra: "Ch",
  Mangal: "Ma",
  Budh: "Bu",
  Guru: "Gu",
  Shukra: "Sk",
  Shani: "Sa",
  Lagna: "La",
};

function heat(count: number, sav = false): string {
  if (sav) {
    if (count >= 36) return "bg-emerald-700 text-white";
    if (count >= 32) return "bg-emerald-500 text-white";
    if (count >= 28) return "bg-amber-500 text-white";
    if (count >= 24) return "bg-amber-200 text-amber-950";
    return "bg-rose-100 text-rose-800";
  }
  if (count >= 6) return "bg-emerald-600 text-white";
  if (count >= 4) return "bg-amber-300 text-amber-950";
  if (count >= 2) return "bg-stone-200 text-stone-700";
  return "bg-rose-100 text-rose-700";
}

function BinduKundali({
  chart,
  bindus,
  target,
  allPlanets = false,
}: {
  chart: Chart;
  bindus: number[];
  target?: AshtakavargaKey;
  allPlanets?: boolean;
}) {
  const lagna = chart.Lagna.sign;
  const classical = PLANETS.filter(
    (planet) => planet.key !== "Rahu" && planet.key !== "Ketu",
  );

  return (
    <div>
      <svg viewBox="0 0 300 300" className="mx-auto w-full max-w-[390px]">
        <rect x="0" y="0" width="300" height="300" fill="#fffdf8" stroke="#7c2d12" strokeWidth="2" />
        <line x1="0" y1="0" x2="300" y2="300" stroke="#7c2d12" strokeWidth="1.2" />
        <line x1="300" y1="0" x2="0" y2="300" stroke="#7c2d12" strokeWidth="1.2" />
        <polygon points="150,0 300,150 150,300 0,150" fill="none" stroke="#7c2d12" strokeWidth="1.2" />

        {HOUSE_POS.map((position, index) => {
          const house = index + 1;
          const sign = ((lagna - 1 + index) % 12) + 1;
          const value = bindus[sign - 1];
          const labels = allPlanets
            ? classical
                .filter((planet) => chart[planet.key].sign === sign)
                .map((planet) => (planet.key === "Lagna" ? "La" : planet.short))
            : target
              ? target === "Lagna"
                ? house === 1
                  ? ["La"]
                  : []
                : chart[target].sign === sign
                  ? [SHORT[target]]
                  : []
              : [];

          return (
            <g key={house}>
              <text
                x={position.x}
                y={position.y - 18}
                textAnchor="middle"
                fontSize="9"
                fontWeight="700"
                fill="#b45309"
              >
                {sign}
              </text>
              <circle
                cx={position.x}
                cy={position.y + 2}
                r={allPlanets ? 15 : 14}
                fill={
                  allPlanets
                    ? value >= 32
                      ? "#059669"
                      : value >= 28
                        ? "#d97706"
                        : "#e11d48"
                    : value >= 6
                      ? "#059669"
                      : value >= 4
                        ? "#d97706"
                        : "#78716c"
                }
              />
              <text
                x={position.x}
                y={position.y + 7}
                textAnchor="middle"
                fontSize="12"
                fontWeight="900"
                fill="#fff"
              >
                {value}
              </text>
              {labels.map((label, labelIndex) => (
                <text
                  key={`${label}-${labelIndex}`}
                  x={position.x}
                  y={position.y + 25 + labelIndex * 9}
                  textAnchor="middle"
                  fontSize="8"
                  fontWeight="800"
                  fill="#1e3a8a"
                >
                  {label}
                </text>
              ))}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function PrastaraTable({
  target,
  av,
}: {
  target: AshtakavargaKey;
  av: ReturnType<typeof computeAshtakavarga>;
}) {
  const table = av.prastara[target];
  return (
    <div className="overflow-x-auto rounded-2xl border border-amber-800/15 bg-white">
      <table className="w-full min-w-[980px] border-collapse text-sm">
        <thead>
          <tr className="border-b-2 border-amber-800/20 bg-amber-50 text-[10px] font-bold uppercase tracking-[0.1em] text-amber-900">
            <th className="sticky left-0 z-10 min-w-[135px] bg-amber-50 px-3 py-3 text-left">
              Contributor
            </th>
            {Array.from({ length: 12 }, (_, index) => (
              <th key={index} className="min-w-[57px] border-l border-amber-800/10 px-1 py-2 text-center">
                <div>{index + 1}</div>
                <div className="mt-0.5 text-[8px] font-normal normal-case text-stone-500">
                  {rashiName(index + 1)}
                </div>
              </th>
            ))}
            <th className="border-l border-amber-800/10 px-3 py-2 text-center">Total</th>
          </tr>
        </thead>
        <tbody>
          {KAKSHYA_ORDER.map((contributor, rowIndex) => (
            <tr
              key={contributor}
              className={`border-b border-stone-200/70 ${rowIndex % 2 === 0 ? "bg-white" : "bg-[#fdfaf4]"}`}
            >
              <th
                scope="row"
                className={`sticky left-0 z-10 px-3 py-2 text-left font-serif text-xs font-bold text-stone-800 ${
                  rowIndex % 2 === 0 ? "bg-white" : "bg-[#fdfaf4]"
                }`}
              >
                {BAV_DISPLAY[contributor]}
              </th>
              {table.rows[contributor].map((value, index) => (
                <td
                  key={index}
                  className={`border-l border-stone-200/60 px-1 py-2 text-center font-mono text-sm font-black ${
                    value ? "text-emerald-700" : "text-stone-200"
                  }`}
                >
                  {value ? "1" : "·"}
                </td>
              ))}
              <td className="border-l border-stone-200 px-3 py-2 text-center font-mono font-black text-amber-800">
                {table.rowTotals[contributor]}
              </td>
            </tr>
          ))}
          <tr className="bg-gradient-to-r from-emerald-50 to-amber-50">
            <th className="sticky left-0 z-10 bg-emerald-50 px-3 py-3 text-left font-serif text-sm font-black text-emerald-900">
              Total Bindus
            </th>
            {table.signTotals.map((value, index) => (
              <td key={index} className="border-l border-emerald-800/10 px-1 py-3 text-center">
                <span className={`inline-flex h-7 w-7 items-center justify-center rounded-md font-mono text-xs font-black ${heat(value)}`}>
                  {value}
                </span>
              </td>
            ))}
            <td className="border-l border-emerald-800/10 px-3 py-3 text-center font-mono text-lg font-black text-emerald-800">
              {table.grandTotal}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

function IndividualPart({
  index,
  target,
  chart,
  av,
}: {
  index: number;
  target: AshtakavargaKey;
  chart: Chart;
  av: ReturnType<typeof computeAshtakavarga>;
}) {
  const table = av.prastara[target];
  return (
    <section
      id={`ashtak-part-${index}`}
      className="scroll-mt-24 overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-[0_14px_40px_-28px_rgba(120,53,15,0.5)]"
    >
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-800/15 bg-gradient-to-r from-amber-100 via-amber-50 to-white px-5 py-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#7c2d12] font-mono text-sm font-black text-amber-50">
            {index}
          </span>
          <div>
            <h2 className="font-serif text-xl font-black text-[#7c2d12]">
              {BAV_DISPLAY[target]} Prastarashtakavarga
            </h2>
            <p className="text-xs text-stone-500">
              Part {index} of 9 · 8 Kakshya contributors · Binary bindu matrix
            </p>
          </div>
        </div>
        <span
          className={`rounded-full border px-3 py-1 font-mono text-sm font-black ${
            table.verified
              ? "border-emerald-700/20 bg-emerald-50 text-emerald-800"
              : "border-rose-500 bg-rose-50 text-rose-700"
          }`}
        >
          {table.grandTotal} / {table.expectedTotal} {table.verified ? "✓" : "✗"}
        </span>
      </header>

      <div className="p-5">
        <PrastaraTable target={target} av={av} />
        <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,360px)_1fr] lg:items-center">
          <div className="rounded-2xl border border-amber-800/15 bg-[#fffdf8] p-3">
            <h3 className="mb-2 text-center font-serif text-sm font-bold text-[#7c2d12]">
              {BAV_DISPLAY[target]} BAV Kundali · {table.grandTotal} Bindus
            </h3>
            <BinduKundali chart={chart} bindus={table.signTotals} target={target} />
          </div>
          <div>
            <h3 className="font-serif text-lg font-bold text-[#7c2d12]">Sign-wise Bindu Summary</h3>
            <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4">
              {table.signTotals.map((count, index) => (
                <div key={index} className="rounded-xl border border-stone-200 bg-[#fdfaf4] p-2 text-center">
                  <div className="text-[9px] text-stone-500">{index + 1}. {rashiName(index + 1)}</div>
                  <div className={`mx-auto mt-1 flex h-8 w-8 items-center justify-center rounded-lg font-mono text-sm font-black ${heat(count)}`}>
                    {count}
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs leading-relaxed text-stone-500">
              Kundali में Rashi number, bindu total और केवल target {target === "Lagna" ? "Lagna" : "planet"} की natal placement दिखाई गई है।
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function SarvaPart({
  chart,
  av,
}: {
  chart: Chart;
  av: ReturnType<typeof computeAshtakavarga>;
}) {
  return (
    <section
      id="ashtak-part-9"
      className="scroll-mt-24 overflow-hidden rounded-3xl border-2 border-emerald-600/40 bg-white/90 shadow-[0_16px_44px_-26px_rgba(5,150,105,0.45)]"
    >
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-emerald-700/20 bg-gradient-to-r from-emerald-900 to-emerald-700 px-5 py-5 text-white">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/15 font-mono text-sm font-black ring-1 ring-white/30">
            9
          </span>
          <div>
            <h2 className="font-serif text-xl font-black">Master Sarvashtakavarga</h2>
            <p className="text-xs text-emerald-100">386 System · 7 planets + Lagnashtakavarga</p>
          </div>
        </div>
        <span className="rounded-full border border-white/30 bg-white/15 px-4 py-1 font-mono text-lg font-black">
          {av.sarvaTotal} {av.sarvaTotal === 386 ? "✓" : "✗"}
        </span>
      </header>

      <div className="space-y-5 p-5">
        <div className="overflow-x-auto rounded-2xl border border-emerald-800/15 bg-white">
          <table className="w-full min-w-[930px] border-collapse text-sm">
            <thead>
              <tr className="border-b-2 border-emerald-800/20 bg-emerald-50 text-[10px] font-bold uppercase tracking-[0.1em] text-emerald-900">
                <th className="sticky left-0 z-10 min-w-[155px] bg-emerald-50 px-3 py-3 text-left">
                  Contributor
                </th>
                {Array.from({ length: 12 }, (_, index) => (
                  <th key={index} className="min-w-[56px] border-l border-emerald-800/10 px-1 py-2 text-center">
                    <div>{index + 1}</div>
                    <div className="mt-0.5 text-[8px] font-normal normal-case text-stone-500">
                      {rashiName(index + 1)}
                    </div>
                  </th>
                ))}
                <th className="border-l border-emerald-800/10 px-3 py-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {BAV_KEYS.map((key, rowIndex) => (
                <tr key={key} className={`border-b border-stone-200/70 ${rowIndex % 2 === 0 ? "bg-white" : "bg-[#fdfaf4]"}`}>
                  <th className={`sticky left-0 z-10 px-3 py-2 text-left font-serif text-xs font-bold ${rowIndex % 2 === 0 ? "bg-white" : "bg-[#fdfaf4]"}`}>
                    {BAV_DISPLAY[key]}
                  </th>
                  {av.bav[key].map((count, index) => (
                    <td key={index} className="border-l border-stone-200/60 px-1 py-2 text-center font-mono text-sm text-stone-700">
                      {count}
                    </td>
                  ))}
                  <td className="border-l border-stone-200 px-3 py-2 text-center font-mono font-black text-amber-800">
                    {av.totals[key]}
                  </td>
                </tr>
              ))}
              <tr className="bg-gradient-to-r from-emerald-50 to-amber-50">
                <th className="sticky left-0 z-10 bg-emerald-50 px-3 py-3 text-left font-serif text-sm font-black text-emerald-900">
                  SAV Total
                </th>
                {av.sarva.map((count, index) => (
                  <td key={index} className="border-l border-emerald-800/10 px-1 py-3 text-center">
                    <span className={`inline-flex h-8 w-8 items-center justify-center rounded-lg font-mono text-sm font-black ${heat(count, true)}`}>
                      {count}
                    </span>
                  </td>
                ))}
                <td className="border-l border-emerald-800/10 px-3 py-3 text-center font-mono text-xl font-black text-emerald-800">
                  {av.sarvaTotal}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="grid gap-5 lg:grid-cols-[minmax(0,400px)_1fr] lg:items-center">
          <div className="rounded-2xl border border-emerald-800/15 bg-[#fffdf8] p-3">
            <h3 className="mb-2 text-center font-serif text-sm font-bold text-emerald-900">
              Natal Kundali with SAV Bindus · Total 386
            </h3>
            <BinduKundali chart={chart} bindus={av.sarva} allPlanets />
          </div>
          <div>
            <h3 className="font-serif text-lg font-bold text-emerald-900">Mathematical Verification</h3>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {BAV_KEYS.map((key) => (
                <div key={key} className="rounded-xl border border-stone-200 bg-[#fdfaf4] px-3 py-2">
                  <div className="text-[9px] text-stone-500">{BAV_DISPLAY[key]}</div>
                  <div className="font-mono text-lg font-black text-[#7c2d12]">{av.totals[key]}</div>
                </div>
              ))}
            </div>
            <div className="mt-3 rounded-2xl border-2 border-emerald-500/40 bg-emerald-50 p-4 font-mono text-sm font-black text-emerald-900">
              48 + 49 + 39 + 54 + 56 + 52 + 39 + 49 = {av.sarvaTotal}
              {av.sarvaTotal === 386 ? " ✓ VERIFIED" : " ✗ ERROR"}
            </div>
            <p className="mt-3 text-xs leading-relaxed text-stone-600">
              Complete natal Kundali में Lagna तथा सातों natal planets अपनी exact birth houses में हैं। Rahu/Ketu Ashtakavarga contributors नहीं हैं।
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default function AshtakavargaSection() {
  const { chart } = useChart();
  const av = useMemo(() => computeAshtakavarga(chart), [chart]);

  return (
    <div className="space-y-7">
      <header className="rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-6 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">
          Brihat Parashara Hora Shastra · Classical Bindu Rules
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Ashtakavarga · 9-Part Prastara
        </h1>
        <p className="mt-3 max-w-4xl text-sm leading-relaxed text-stone-600 sm:text-base">
          आठ पूर्ण Prastarashtakavarga tables (Surya, Chandra, Mangal, Budh, Guru, Shukra, Shani,
          Lagna) और अंतिम 386-बिन्दु Sarvashtakavarga। प्रत्येक Prastara में Kakshya क्रम:
          Shani → Guru → Mangal → Surya → Shukra → Budh → Chandra → Lagna।
        </p>
        <div className="mt-5 flex flex-wrap gap-2">
          {BAV_KEYS.map((key, index) => (
            <a
              key={key}
              href={`#ashtak-part-${index + 1}`}
              className="rounded-lg border border-amber-800/15 bg-white px-3 py-1.5 text-xs font-bold text-[#7c2d12] transition hover:bg-amber-50"
            >
              {index + 1}. {BAV_DISPLAY[key]} ({av.totals[key]})
            </a>
          ))}
          <a
            href="#ashtak-part-9"
            className="rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-bold text-white transition hover:bg-emerald-800"
          >
            9. Sarvashtakavarga (386)
          </a>
        </div>
      </header>

      {BAV_KEYS.map((target, index) => (
        <IndividualPart key={target} index={index + 1} target={target} chart={chart} av={av} />
      ))}

      <SarvaPart chart={chart} av={av} />
    </div>
  );
}