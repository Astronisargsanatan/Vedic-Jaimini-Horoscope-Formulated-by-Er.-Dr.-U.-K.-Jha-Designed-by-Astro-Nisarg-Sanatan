export default function GuruVandana() {
  return (
    <section className="relative isolate overflow-hidden rounded-3xl border border-amber-700/20 bg-gradient-to-b from-[#fff8e7] via-[#fffdf7] to-white px-4 py-8 text-center shadow-[0_18px_45px_-28px_rgba(120,53,15,0.6)] sm:px-8 sm:py-12 lg:px-14 lg:py-14">
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-[0.08]"
        style={{ background: "radial-gradient(circle at 50% 0%, #f59e0b 0, transparent 52%)" }}
      />
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-amber-700/25 bg-amber-100 font-serif text-3xl font-black text-[#7c2d12] shadow-sm sm:h-20 sm:w-20 sm:text-4xl">
        ॐ
      </div>
      <div className="mx-auto mt-6 flex max-w-2xl items-center gap-3">
        <span className="h-px flex-1 bg-gradient-to-r from-transparent to-amber-600/40" />
        <span className="text-[10px] font-bold uppercase tracking-[0.28em] text-amber-700 sm:text-xs">
          गुरु वन्दना · Guru Vandana
        </span>
        <span className="h-px flex-1 bg-gradient-to-l from-transparent to-amber-600/40" />
      </div>
      <blockquote className="mx-auto mt-6 max-w-4xl">
        <p className="font-serif text-xl font-bold leading-[1.8] text-[#7c2d12] sm:text-3xl sm:leading-[1.75] lg:text-4xl">
          गुरुर्ब्रह्मा गुरुर्विष्णुः
          <br className="sm:hidden" /> गुरुर्देवो महेश्वरः।
          <br />
          गुरुः साक्षात् परब्रह्म
          <br className="sm:hidden" /> तस्मै श्रीगुरवे नमः॥
        </p>
      </blockquote>
      <p className="mx-auto mt-6 max-w-3xl text-sm leading-7 text-stone-600 sm:text-base sm:leading-8">
        Guru is Brahma, Guru is Vishnu, and Guru is Maheshwara. Guru is the direct manifestation
        of the Supreme Brahman. Salutations to that revered Guru.
      </p>
      <div className="mx-auto mt-7 h-px max-w-xl bg-gradient-to-r from-transparent via-amber-600/40 to-transparent" />
      <p className="mt-5 font-serif text-sm font-semibold tracking-wide text-amber-900 sm:text-base">
        तस्मै श्रीगुरवे नमः
      </p>
    </section>
  );
}