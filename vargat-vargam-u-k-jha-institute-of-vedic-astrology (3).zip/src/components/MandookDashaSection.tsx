import { useMemo, useState } from "react";
import {
  ADARSHA_SIGNS,
  COMMON_SIGNS,
  EVEN_SIGNS,
  FIXED_SIGNS,
  MOVEABLE_SIGNS,
  ODD_SIGNS,
  computeMandookDasha,
  formatMandookDate,
  mandookSignLabel,
  type MandookMaha,
} from "../lib/mandookDasha";
import { rashiName } from "../lib/astro";
import { useChart } from "../state/ChartContext";
import DashaPraveshModal from "./DashaPraveshModal";
import type { DashaPraveshRequest } from "../lib/dashaPravesh";

function resolveBirth(date?: string, time?: string, birthUtc?: string): Date {
  if (birthUtc) {
    const instant = new Date(birthUtc);
    if (!Number.isNaN(instant.getTime())) return instant;
  }
  const d = (date ?? "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const t = (time ?? "").match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  if (!d) return new Date();
  return new Date(
    Date.UTC(
      Number(d[3]),
      Number(d[2]) - 1,
      Number(d[1]),
      t ? Number(t[1]) : 12,
      t ? Number(t[2]) : 0,
      t ? Number(t[3] ?? 0) : 0,
    ) - 330 * 60000,
  );
}

function MahaRow({
  maha,
  timeZone,
  active,
  onOpen,
}: {
  maha: MandookMaha;
  timeZone?: string;
  active: boolean;
  onOpen: (request: DashaPraveshRequest) => void;
}) {
  const [open, setOpen] = useState(active || maha.order === 1);
  return (
    <>
      <tr
        className={`border-b border-stone-200/70 ${
          active ? "bg-emerald-50" : maha.order % 2 === 0 ? "bg-[#fdfaf4]" : "bg-white"
        }`}
      >
        <td className="px-3 py-2 text-center font-mono text-stone-400">{maha.order}</td>
        <td className="px-3 py-2">
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            className="flex items-center gap-2 text-left"
          >
            <span className="font-mono text-xs text-stone-400">{open ? "▾" : "▸"}</span>
            <span className="font-serif font-black text-[#7c2d12]">
              {mandookSignLabel(maha.sign)}
            </span>
            {active && (
              <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-[9px] font-black text-white">
                ACTIVE
              </span>
            )}
            {maha.partialAtBirth && (
              <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[9px] font-bold text-amber-800">
                BALANCE AT BIRTH
              </span>
            )}
          </button>
        </td>
        <td className="px-3 py-2 font-mono text-xs text-stone-600">
          {formatMandookDate(maha.start, timeZone)}
        </td>
        <td className="px-3 py-2 font-mono text-xs text-stone-600">
          {formatMandookDate(maha.end, timeZone)}
        </td>
        <td className="px-3 py-2 font-mono text-xs font-bold text-stone-800">
          {maha.duration.label}
        </td>
        <td className="px-3 py-2 text-center">
          {maha.junctionAfter ? (
            <span className="rounded-full bg-rose-100 px-2 py-0.5 text-[9px] font-black text-rose-700">
              MAJOR JUNCTION → 7th
            </span>
          ) : (
            "—"
          )}
        </td>
        <td className="px-3 py-2">
          <button
            type="button"
            onClick={() =>
              onOpen({
                system: "Jaimini Mandook Dasha",
                selected: { level: "Mahadasha", name: mandookSignLabel(maha.sign), start: maha.start },
                path: [{ level: "Mahadasha", name: mandookSignLabel(maha.sign), start: maha.start }],
              })
            }
            className="whitespace-nowrap rounded-lg border border-indigo-700/20 bg-indigo-50 px-2 py-1 text-[9px] font-bold text-indigo-800"
          >
            View Pravesh Chart
          </button>
        </td>
      </tr>
      {open && (
        <tr className="border-b border-amber-800/10 bg-amber-50/30">
          <td colSpan={7} className="px-4 py-3">
            <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.14em] text-amber-800">
              {rashiName(maha.sign)} Maha Dasha — Bhukti Sequence
            </div>
            <div className="overflow-x-auto rounded-xl border border-amber-800/15 bg-white">
              <table className="w-full min-w-[720px] text-xs">
                <thead>
                  <tr className="bg-amber-50 text-left text-[9px] font-bold uppercase tracking-wide text-amber-900">
                    <th className="px-2 py-2">#</th>
                    <th className="px-2 py-2">Bhukti Sign</th>
                    <th className="px-2 py-2">Start</th>
                    <th className="px-2 py-2">End</th>
                    <th className="px-2 py-2">Duration</th>
                    <th className="px-2 py-2">Junction</th>
                    <th className="px-2 py-2">Pravesh Chart</th>
                  </tr>
                </thead>
                <tbody>
                  {maha.bhuktis.map((bhukti) => (
                    <tr key={`${maha.order}-${bhukti.order}`} className="border-t border-stone-100">
                      <td className="px-2 py-1.5 font-mono text-stone-400">{bhukti.order}</td>
                      <td className="px-2 py-1.5 font-serif font-bold text-stone-800">
                        {mandookSignLabel(bhukti.sign)}
                      </td>
                      <td className="px-2 py-1.5 font-mono text-[10px] text-stone-600">
                        {formatMandookDate(bhukti.start, timeZone)}
                      </td>
                      <td className="px-2 py-1.5 font-mono text-[10px] text-stone-600">
                        {formatMandookDate(bhukti.end, timeZone)}
                      </td>
                      <td className="px-2 py-1.5 font-mono text-[10px]">{bhukti.duration.label}</td>
                      <td className="px-2 py-1.5">
                        {bhukti.junctionAfter ? (
                          <span className="rounded bg-rose-100 px-1.5 py-0.5 text-[9px] font-bold text-rose-700">
                            6→7 INFLECTION
                          </span>
                        ) : (
                          "—"
                        )}
                      </td>
                      <td className="px-2 py-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            onOpen({
                              system: "Jaimini Mandook Dasha",
                              selected: {
                                level: "Bhukti",
                                name: mandookSignLabel(bhukti.sign),
                                start: bhukti.start,
                              },
                              path: [
                                { level: "Mahadasha", name: mandookSignLabel(maha.sign), start: maha.start },
                                { level: "Bhukti", name: mandookSignLabel(bhukti.sign), start: bhukti.start },
                              ],
                            })
                          }
                          className="whitespace-nowrap rounded-lg border border-indigo-700/20 bg-indigo-50 px-2 py-1 text-[9px] font-bold text-indigo-800"
                        >
                          Open Chart
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

export default function MandookDashaSection() {
  const { chart, native } = useChart();
  const [pravesh, setPravesh] = useState<DashaPraveshRequest | null>(null);
  const birth = useMemo(
    () => resolveBirth(native?.date, native?.time, native?.birthUtc),
    [native],
  );
  const result = useMemo(() => computeMandookDasha(chart, birth), [chart, birth]);

  return (
    <section
      id="mandook-dasha"
      className="scroll-mt-24 overflow-hidden rounded-3xl border border-indigo-800/20 bg-white/85 shadow-[0_14px_42px_-28px_rgba(49,46,129,0.45)]"
    >
      <header className="bg-gradient-to-r from-[#312e81] to-[#4338ca] px-5 py-5 text-white sm:px-6">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-indigo-200">
          जैमिनि उपदेश सूत्रम् · Exact Mandook Sequence Tables
        </div>
        <h2 className="mt-1 font-serif text-2xl font-black sm:text-3xl">Mandook Dasha</h2>
        <p className="mt-2 max-w-4xl text-xs leading-relaxed text-indigo-100/85">
          Odd Lagna स्वयं से; Even Lagna अपने Adarsha से शुरू होता है। Starting sign की modality
          7/8/9 वर्ष प्रति राशि और 84/96/108 वर्ष का total cycle तय करती है।
        </p>
      </header>

      <div className="space-y-5 p-5 sm:p-6">
        {!native?.date && (
          <div className="rounded-xl border-2 border-amber-500 bg-amber-50 px-4 py-3 text-xs text-amber-900">
            सही जन्म-balance और dates के लिए पहले Home पर Birth Details calculate करें।
          </div>
        )}

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Info label="Natal Lagna" value={`${mandookSignLabel(result.lagnaSign)} · ${result.polarity}`} />
          <Info
            label="Starting Dasha Sign"
            value={`${mandookSignLabel(result.startingSign)}${result.polarity === "Even" ? " · Adarsha" : " · Lagna"}`}
            tone="indigo"
          />
          <Info
            label="Starting Modality"
            value={`${result.modality} · ${result.yearsPerSign} years/sign`}
            tone="emerald"
          />
          <Info label="Total Cycle" value={`${result.totalCycleYears} Years`} tone="rose" />
        </div>

        <div className="rounded-2xl border border-indigo-700/15 bg-indigo-50/70 p-4 text-xs leading-relaxed text-indigo-950">
          <strong>Start Rule:</strong> Lagna {mandookSignLabel(result.lagnaSign)} is{" "}
          <strong>{result.polarity}</strong>. Therefore first Dasha ={" "}
          <strong>{mandookSignLabel(result.startingSign)}</strong>
          {result.polarity === "Even"
            ? ` (Adarsha of ${rashiName(result.lagnaSign)} = ${rashiName(ADARSHA_SIGNS[result.lagnaSign])}).`
            : " (Odd Lagna starts directly from Lagna)."}
        </div>

        <div className="grid gap-3 md:grid-cols-3">
          <Info
            label="Lagna Absolute Longitude (M)"
            value={`${result.lagnaAbsoluteLongitude.toFixed(6)}°`}
          />
          <Info label="Dasha Consumed (Dc)" value={result.consumed.label} tone="rose" />
          <Info label="Dasha Balance at Birth (Db)" value={result.balance.label} tone="emerald" />
        </div>

        <div className="rounded-2xl border-2 border-emerald-500/25 bg-emerald-50 p-4 text-xs leading-relaxed text-emerald-950">
          <strong>Balance Formula:</strong> M = {result.lagnaAbsoluteLongitude.toFixed(6)}°; N ={" "}
          {result.yearsPerSign} years. Dc = (M ÷ 360) × N = {result.consumed.label}. Db = N − Dc ={" "}
          <strong>{result.balance.label}</strong>. First Dasha End = Birth Instant + Db.
        </div>

        <div className="rounded-2xl border border-rose-500/25 bg-rose-50 p-4">
          <div className="text-[10px] font-black uppercase tracking-wider text-rose-700">
            Critical 6th → 7th Maha Dasha Junction
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            {result.sequence.map((sign, index) => (
              <span key={`${sign}-${index}`} className="contents">
                <span
                  className={`rounded-lg px-2 py-1 font-mono text-[10px] font-bold ${
                    index === 5 || index === 6
                      ? "bg-rose-700 text-white"
                      : index === 0
                        ? "bg-indigo-700 text-white"
                        : "border border-stone-200 bg-white text-stone-700"
                  }`}
                >
                  {index + 1}. {mandookSignLabel(sign)}
                </span>
                {index === 5 && <span className="font-black text-rose-700">⇢ MAJOR JUNCTION ⇢</span>}
              </span>
            ))}
          </div>
          <p className="mt-2 text-xs text-rose-800">
            6th से 7th transition chart strength के अनुसार sudden loss/gain या dramatic rise/fall
            का प्रमुख karmic junction है। यही rule हर Bhukti sequence में भी लागू है।
          </p>
        </div>

        {(result.activeMaha || result.activeBhukti) && (
          <div className="rounded-2xl border-2 border-emerald-500/40 bg-emerald-50 px-4 py-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
              Active Mandook Dasha
            </div>
            <div className="mt-1 font-serif text-xl font-black text-emerald-900">
              {result.activeMaha ? mandookSignLabel(result.activeMaha.sign) : "—"}
              {result.activeBhukti && ` / ${mandookSignLabel(result.activeBhukti.sign)} Bhukti`}
            </div>
          </div>
        )}

        <div className="overflow-x-auto rounded-2xl border border-indigo-800/15">
          <table className="w-full min-w-[1060px] text-sm">
            <thead>
              <tr className="border-b-2 border-indigo-800/20 bg-indigo-50 text-left text-[10px] font-bold uppercase tracking-[0.1em] text-indigo-900">
                <th className="px-3 py-3 text-center">#</th>
                <th className="px-3 py-3">Maha Dasha Sign</th>
                <th className="px-3 py-3">Start</th>
                <th className="px-3 py-3">End</th>
                <th className="px-3 py-3">Duration</th>
                <th className="px-3 py-3 text-center">Junction</th>
                <th className="px-3 py-3">Pravesh Chart</th>
              </tr>
            </thead>
            <tbody>
              {result.mahadashas.map((maha) => (
                <MahaRow
                  key={maha.order}
                  maha={maha}
                  timeZone={native?.tz}
                  active={maha === result.activeMaha}
                  onOpen={setPravesh}
                />
              ))}
            </tbody>
          </table>
        </div>
        <DashaPraveshModal request={pravesh} native={native} onClose={() => setPravesh(null)} />

        <div className="grid gap-3 md:grid-cols-3">
          <RuleBox
            title="Odd / Even"
            text={`Odd: ${ODD_SIGNS.map(rashiName).join(", ")}. Even: ${EVEN_SIGNS.map(rashiName).join(", ")}.`}
          />
          <RuleBox
            title="Modality & Cycle"
            text={`Moveable (${MOVEABLE_SIGNS.map(rashiName).join(", ")}): 7y × 12 = 84y. Fixed (${FIXED_SIGNS.map(rashiName).join(", ")}): 8y × 12 = 96y. Common (${COMMON_SIGNS.map(rashiName).join(", ")}): 9y × 12 = 108y.`}
          />
          <RuleBox
            title="Bhukti Duration"
            text={`Every Bhukti = 1/12 of parent Maha. Here ${result.yearsPerSign}-year Maha gives ${result.yearsPerSign} months per Bhukti.`}
          />
        </div>
      </div>
    </section>
  );
}

function Info({
  label,
  value,
  tone = "amber",
}: {
  label: string;
  value: string;
  tone?: "amber" | "indigo" | "emerald" | "rose";
}) {
  const tones = {
    amber: "border-amber-800/15 bg-amber-50 text-amber-900",
    indigo: "border-indigo-700/20 bg-indigo-50 text-indigo-900",
    emerald: "border-emerald-700/20 bg-emerald-50 text-emerald-900",
    rose: "border-rose-700/20 bg-rose-50 text-rose-900",
  };
  return (
    <div className={`rounded-2xl border p-4 ${tones[tone]}`}>
      <div className="text-[9px] font-bold uppercase tracking-wider opacity-75">{label}</div>
      <div className="mt-1 font-serif text-base font-black sm:text-lg">{value}</div>
    </div>
  );
}

function RuleBox({ title, text }: { title: string; text: string }) {
  return (
    <div className="rounded-2xl border border-stone-200 bg-[#fdfaf4] p-4 text-xs leading-relaxed text-stone-600">
      <h3 className="font-serif text-sm font-bold text-[#7c2d12]">{title}</h3>
      <p className="mt-1.5">{text}</p>
    </div>
  );
}