import { useMemo, useState } from "react";
import {
  DASHVARGA_IDS,
  PLANETS,
  RASHIS,
  VAISHESHIKA_DIGNITY_SIGNS,
  computeLagnaVaisheshika,
  computeVaisheshika,
  computeVarga,
  getLagnaVaisheshikaFactors,
  rashiName,
  type ChartSigns,
  type PlanetKey,
  type VaisheshikaResult,
  type VargaId,
} from "../lib/astro";
import { useChart } from "../state/ChartContext";

const COLUMN_LABELS: Record<PlanetKey, string> = {
  Lagna: "Lagn",
  Surya: "Surya",
  Chandra: "Chandra",
  Mangal: "Mangal",
  Budh: "Budh",
  Guru: "Guru",
  Shukra: "Shukra",
  Shani: "Shani",
  Rahu: "Rahu",
  Ketu: "Ketu",
};

function SignCell({ sign }: { sign: number }) {
  return (
    <div className="min-w-[70px] text-center" title={`${sign}. ${rashiName(sign)}`}>
      <div className="font-mono text-base font-black text-[#7c2d12]">{sign}</div>
      <div className="mt-0.5 text-[10px] text-stone-500">{rashiName(sign)}</div>
    </div>
  );
}

export default function ConsolidatedSummary() {
  const {
    chart,
    engineeringVargaName,
    engineeringSigns,
    setEngineeringVargaName,
    setEngineeringSign,
  } = useChart();
  const [copied, setCopied] = useState(false);
  const [repetitionCopied, setRepetitionCopied] = useState(false);

  const generated = useMemo(() => {
    return DASHVARGA_IDS.reduce(
      (rows, id) => {
        rows[id] = computeVarga(chart, id);
        return rows;
      },
      {} as Record<VargaId, ChartSigns>,
    );
  }, [chart]);

  const vaisheshika = useMemo(() => {
    return PLANETS.reduce(
      (scores, planet) => {
        const tenSigns = [
          ...DASHVARGA_IDS.map((id) => generated[id][planet.key]),
          engineeringSigns[planet.key],
        ];

        scores[planet.key] =
          planet.key === "Lagna"
            ? computeLagnaVaisheshika(chart, tenSigns)
            : computeVaisheshika(planet.key, tenSigns);
        return scores;
      },
      {} as Record<PlanetKey, VaisheshikaResult>,
    );
  }, [chart, engineeringSigns, generated]);

  const lagnaFactors = useMemo(() => getLagnaVaisheshikaFactors(chart), [chart]);

  const repetitionRows = useMemo(() => {
    const manualLabel = engineeringVargaName.trim() || "Manual Varga";
    const planetOrder = new Map(PLANETS.map((planet, index) => [planet.key, index]));

    const rows = PLANETS.flatMap((planet) => {
      const occurrences = new Map<number, string[]>();
      DASHVARGA_IDS.forEach((id) => {
        const sign = generated[id][planet.key];
        occurrences.set(sign, [...(occurrences.get(sign) ?? []), id]);
      });
      const manualSign = engineeringSigns[planet.key];
      occurrences.set(manualSign, [
        ...(occurrences.get(manualSign) ?? []),
        `VE: ${manualLabel}`,
      ]);

      return Array.from(occurrences.entries()).map(([sign, sources]) => ({
        planet: planet.key,
        label: COLUMN_LABELS[planet.key],
        sign,
        count: sources.length,
        sources,
      }));
    });

    return rows.sort(
      (a, b) =>
        b.count - a.count ||
        (planetOrder.get(a.planet) ?? 0) - (planetOrder.get(b.planet) ?? 0) ||
        a.sign - b.sign,
    );
  }, [engineeringSigns, engineeringVargaName, generated]);

  const copySummary = async () => {
    const header = ["Dashvarga", ...PLANETS.map((p) => COLUMN_LABELS[p.key])].join("\t");
    const generatedLines = DASHVARGA_IDS.map((id) =>
      [id, ...PLANETS.map((p) => `${generated[id][p.key]} ${rashiName(generated[id][p.key])}`)].join(
        "\t",
      ),
    );
    const manual = [
      `Varga Engineering (${engineeringVargaName.trim() || "Manual Varga"})`,
      ...PLANETS.map((p) => `${engineeringSigns[p.key]} ${rashiName(engineeringSigns[p.key])}`),
    ].join("\t");
    const scores = [
      "Vaisheshika Amsha",
      ...PLANETS.map((p) => {
        const value = vaisheshika[p.key];
        return value.applicable ? `${value.score}/10 ${value.title}` : "N/A";
      }),
    ].join("\t");

    try {
      await navigator.clipboard.writeText([header, ...generatedLines, manual, scores].join("\n"));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  const copyRepetitionSummary = async () => {
    const header = "Rank\tGraha / Lagn\tRashi\tRepetition\tVarga Sources";
    const lines = repetitionRows.map(
      (row, index) =>
        `${index + 1}\t${row.label}\t${row.sign} ${rashiName(row.sign)}\t${row.count}\t${row.sources.join(
          ", ",
        )}`,
    );
    try {
      await navigator.clipboard.writeText([header, ...lines].join("\n"));
      setRepetitionCopied(true);
      window.setTimeout(() => setRepetitionCopied(false), 1600);
    } catch {
      setRepetitionCopied(false);
    }
  };

  return (
    <div className="space-y-6">
      <section
        id="dashvarga-summary"
        className="scroll-mt-24 overflow-hidden rounded-3xl border border-amber-800/20 bg-white/85 shadow-[0_16px_42px_-26px_rgba(120,53,15,0.65)]"
      >
      <header className="flex flex-wrap items-start justify-between gap-4 border-b border-amber-800/15 bg-gradient-to-r from-[#7c2d12] to-[#9a3412] px-5 py-5 text-amber-50 sm:px-6">
        <div>
          <div className="text-[10px] font-semibold uppercase tracking-[0.22em] text-amber-200">
            Final Consolidated Result
          </div>
          <h3 className="mt-1 font-serif text-2xl font-black">Dashvarga Summary Table</h3>
          <p className="mt-1 max-w-3xl text-xs leading-relaxed text-amber-100/80">
            D1 to D10 output Rashis, one manual Varga Engineering row, and the calculated
            Vaisheshika Amsha dignity score in one view.
          </p>
        </div>
        <button
          type="button"
          onClick={copySummary}
          className="rounded-xl border border-amber-100/25 bg-white/10 px-4 py-2 text-xs font-semibold text-white transition hover:bg-white/20"
        >
          {copied ? "Summary copied" : "Copy summary"}
        </button>
      </header>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[1320px] border-collapse text-sm">
          <caption className="sr-only">
            Consolidated Dashvarga signs and Vaisheshika Amsha scores for Lagna and all planets
          </caption>
          <thead>
            <tr className="border-b-2 border-amber-800/20 bg-amber-50 text-[#7c2d12]">
              <th className="sticky left-0 z-20 min-w-[225px] bg-amber-50 px-4 py-3 text-left font-serif text-sm font-bold">
                Dashvarga
              </th>
              {PLANETS.map((planet) => (
                <th
                  key={planet.key}
                  className="min-w-[96px] border-l border-amber-800/10 px-2 py-3 text-center text-xs font-bold uppercase tracking-wide"
                >
                  {COLUMN_LABELS[planet.key]}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {DASHVARGA_IDS.map((id, rowIndex) => (
              <tr
                key={id}
                className={`border-b border-stone-200 transition hover:bg-amber-50/70 ${
                  rowIndex % 2 === 0 ? "bg-white" : "bg-[#fdfaf4]"
                }`}
              >
                <th
                  scope="row"
                  className={`sticky left-0 z-10 px-4 py-3 text-left font-serif text-base font-black text-[#7c2d12] ${
                    rowIndex % 2 === 0 ? "bg-white" : "bg-[#fdfaf4]"
                  }`}
                >
                  {id}
                </th>
                {PLANETS.map((planet) => (
                  <td key={planet.key} className="border-l border-stone-200/80 px-2 py-2">
                    <SignCell sign={generated[id][planet.key]} />
                  </td>
                ))}
              </tr>
            ))}

            <tr className="border-y-2 border-cyan-800/25 bg-cyan-50/70">
              <th
                scope="row"
                className="sticky left-0 z-10 bg-cyan-50 px-4 py-4 text-left font-serif text-sm font-black leading-tight text-cyan-900"
              >
                Varga Engineering
                <label className="mt-2 block font-sans text-[9px] font-semibold uppercase tracking-wider text-cyan-700">
                  10th Varga Name · Manual
                </label>
                <input
                  type="text"
                  value={engineeringVargaName}
                  onChange={(event) => setEngineeringVargaName(event.target.value)}
                  placeholder="e.g. D12"
                  className="mt-1.5 w-full rounded-lg border border-cyan-800/25 bg-white px-2 py-2 font-mono text-xs font-bold text-cyan-900 outline-none transition placeholder:font-normal placeholder:text-cyan-800/35 focus:border-cyan-600 focus:ring-2 focus:ring-cyan-500/20"
                  title="Enter the name of the manually selected tenth Varga, for example D12"
                />
              </th>
              {PLANETS.map((planet) => (
                <td key={planet.key} className="border-l border-cyan-800/10 px-2 py-3">
                  <label className="sr-only">
                    Manual Varga Rashi for {COLUMN_LABELS[planet.key]}
                  </label>
                  <select
                    value={engineeringSigns[planet.key]}
                    onChange={(event) => setEngineeringSign(planet.key, Number(event.target.value))}
                    className="w-full min-w-[100px] rounded-lg border border-cyan-800/25 bg-white px-1.5 py-2 text-center font-mono text-xs font-bold text-cyan-900 outline-none transition focus:border-cyan-600 focus:ring-2 focus:ring-cyan-500/20"
                    title={`${engineeringSigns[planet.key]}. ${rashiName(engineeringSigns[planet.key])}`}
                  >
                    {RASHIS.map((rashi) => (
                      <option key={rashi.num} value={rashi.num}>
                        {rashi.num} · {rashi.name}
                      </option>
                    ))}
                  </select>
                </td>
              ))}
            </tr>

            <tr className="bg-gradient-to-r from-emerald-50 to-amber-50">
              <th
                scope="row"
                className="sticky left-0 z-10 bg-emerald-50 px-4 py-4 text-left font-serif text-sm font-black leading-tight text-emerald-900"
              >
                Vaisheshika Amsha
                <span className="mt-1 block font-sans text-[10px] font-semibold uppercase tracking-wider text-emerald-700">
                  Score / Title
                </span>
              </th>
              {PLANETS.map((planet) => {
                const score = vaisheshika[planet.key];
                const dignitySigns = VAISHESHIKA_DIGNITY_SIGNS[planet.key];
                return (
                  <td
                    key={planet.key}
                    className="border-l border-emerald-800/10 px-2 py-4 text-center"
                    title={
                      planet.key === "Lagna"
                        ? `Lagna factors: Trikona signs ${lagnaFactors.trikonaSigns.join(
                            ", ",
                          )}; Lagna lord ${lagnaFactors.lagnaLord}'s other sign ${
                            lagnaFactors.otherLordSign ?? "none"
                          }; Lagna lord placement sign ${lagnaFactors.lordPlacementSign}`
                        : dignitySigns
                        ? `Counted when ${COLUMN_LABELS[planet.key]} is in sign ${dignitySigns.join(
                            ", ",
                          )} across the 10 rows`
                        : "Classical score not applied without a lineage-specific rule"
                    }
                  >
                    {score.applicable ? (
                      <div className="min-w-[84px]">
                        <div className="font-mono text-base font-black text-emerald-800">
                          {score.score}/10
                        </div>
                        <div className="mt-0.5 text-[10px] font-semibold leading-tight text-emerald-700">
                          {score.title}
                        </div>
                      </div>
                    ) : (
                      <div className="min-w-[70px]">
                        <div className="font-mono text-sm font-bold text-stone-500">N/A</div>
                        <div className="mt-0.5 text-[9px] leading-tight text-stone-400">
                          School-specific
                        </div>
                      </div>
                    )}
                  </td>
                );
              })}
            </tr>
          </tbody>
        </table>
      </div>

      <div className="space-y-2 border-t border-amber-800/15 bg-[#fdfaf4] px-5 py-4 text-xs leading-relaxed text-stone-600 sm:px-6">
        <p>
          <strong className="text-[#7c2d12]">Manual row:</strong> only the first cell is a free-text
          field for the tenth Varga name, such as <span className="font-mono font-semibold">D12</span>.
          Lagna and all planetary cells are Rashi dropdowns (1–12) and participate in scoring.
        </p>
        <p>
          <strong className="text-emerald-800">Vaisheshika method used:</strong> for Surya through
          Shani, the score counts sign-level exaltation, Moolatrikona, or own-sign placements across
          the nine generated charts plus the Rashi selected in the manual Varga row. Titles are Parijatamsa
          (2), Uttamamsa (3), Gopuramsa (4), Simhasanamsa (5), Paravatamsa (6), Devalokamsa (7),
          Brahmalokamsa (8), Airavatamsa (9), and Sridhamamsa (10).
        </p>
        <p>
          <strong className="text-emerald-800">Special Lagna rule:</strong> each Lagna output is
          counted when it falls in any natal Lagna Trikona Rashi (1st, 5th, 9th), the Lagna lord’s
          other owned Rashi, or the natal Rashi occupied by the Lagna lord. Here the title scale is
          shifted exactly as requested: 3 Parijatamsa, 4 Uttamamsa, 5 Gopuramsa, 6 Simhasanamsa, 7
          Paravatamsa, 8 Devalokamsa, 9 Brahmalokamsa, and 10 Airavatamsa. Lagna is never labeled
          Sridhamamsa.
        </p>
        <p className="text-stone-500">
          Current Lagna factors: Trikona Rashis {lagnaFactors.trikonaSigns.join(", ")}; Lagna lord{" "}
          {lagnaFactors.lagnaLord}; other owned Rashi {lagnaFactors.otherLordSign ?? "none"}; lord’s
          D1 placement Rashi {lagnaFactors.lordPlacementSign}. Rahu and Ketu remain N/A until a
          lineage-specific node rule is supplied.
        </p>
      </div>
      </section>

      <section className="overflow-hidden rounded-3xl border border-indigo-800/15 bg-white/85 shadow-[0_16px_42px_-26px_rgba(49,46,129,0.4)]">
        <header className="flex flex-wrap items-start justify-between gap-4 border-b border-indigo-800/15 bg-gradient-to-r from-[#312e81] to-[#4338ca] px-5 py-5 text-white sm:px-6">
          <div>
            <div className="text-[10px] font-semibold uppercase tracking-[0.22em] text-indigo-200">
              Repetition Analysis · Highest to Lowest
            </div>
            <h3 className="mt-1 font-serif text-2xl font-black">Graha–Rashi Repetition Summary</h3>
            <p className="mt-1 max-w-3xl text-xs leading-relaxed text-indigo-100/80">
              Har Lagn/Graha ki Rashi ko nau generated Vargas aur manual{" "}
              <span className="font-semibold text-white">
                {engineeringVargaName.trim() || "10th Varga"}
              </span>{" "}
              me count karke sabse adhik repetition se sabse kam repetition tak rakha gaya hai.
            </p>
          </div>
          <button
            type="button"
            onClick={copyRepetitionSummary}
            className="rounded-xl border border-indigo-100/25 bg-white/10 px-4 py-2 text-xs font-semibold text-white transition hover:bg-white/20"
          >
            {repetitionCopied ? "Repetition copied" : "Copy repetition table"}
          </button>
        </header>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[880px] border-collapse text-sm">
            <caption className="sr-only">
              Planet and Rashi frequencies across nine calculated Vargas and the manual tenth Varga
            </caption>
            <thead>
              <tr className="border-b-2 border-indigo-800/15 bg-indigo-50 text-[#312e81]">
                <th className="w-16 px-4 py-3 text-center text-xs font-bold uppercase tracking-wide">
                  Rank
                </th>
                <th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wide">
                  Graha / Lagn
                </th>
                <th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wide">
                  Rashi
                </th>
                <th className="min-w-[220px] px-4 py-3 text-left text-xs font-bold uppercase tracking-wide">
                  Repetition
                </th>
                <th className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wide">
                  Found In Vargas
                </th>
              </tr>
            </thead>
            <tbody>
              {repetitionRows.map((row, index) => (
                <tr
                  key={`${row.planet}-${row.sign}`}
                  className={`border-b border-stone-200/80 transition hover:bg-indigo-50/70 ${
                    index % 2 === 0 ? "bg-white" : "bg-[#faf9ff]"
                  }`}
                >
                  <td className="px-4 py-3 text-center font-mono text-xs text-stone-400">
                    {index + 1}
                  </td>
                  <td className="px-4 py-3 font-serif font-bold text-stone-800">{row.label}</td>
                  <td className="px-4 py-3">
                    <span className="font-mono font-black text-[#7c2d12]">{row.sign}</span>
                    <span className="ml-2 text-xs text-stone-500">{rashiName(row.sign)}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <span
                        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg font-mono text-sm font-black ${
                          row.count >= 3
                            ? "bg-emerald-600 text-white"
                            : row.count === 2
                              ? "bg-amber-500 text-white"
                              : "bg-stone-200 text-stone-600"
                        }`}
                      >
                        {row.count}
                      </span>
                      <div className="h-2 flex-1 overflow-hidden rounded-full bg-stone-100">
                        <div
                          className={`h-full rounded-full ${
                            row.count >= 3
                              ? "bg-emerald-500"
                              : row.count === 2
                                ? "bg-amber-500"
                                : "bg-stone-300"
                          }`}
                          style={{ width: `${row.count * 10}%` }}
                        />
                      </div>
                      <span className="w-16 text-right text-[10px] font-semibold uppercase tracking-wide text-stone-500">
                        {row.count > 1 ? `${row.count} times` : "1 time"}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {row.sources.map((source) => (
                        <span
                          key={source}
                          className={`rounded-md border px-1.5 py-0.5 font-mono text-[10px] font-semibold ${
                            source.startsWith("VE:")
                              ? "border-cyan-700/20 bg-cyan-50 text-cyan-800"
                              : "border-indigo-700/15 bg-indigo-50 text-indigo-700"
                          }`}
                        >
                          {source}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="border-t border-indigo-800/10 bg-indigo-50/50 px-5 py-4 text-xs leading-relaxed text-stone-600 sm:px-6">
          Total base: <strong className="text-[#312e81]">10 Varga placements per column</strong> —
          D1, D2, D3, D4, D5, D6, D8, D9, D10, and the manually named tenth Varga. Every
          Graha–Rashi pair appears once in this table and rows are sorted by repetition count.
        </div>
      </section>
    </div>
  );
}