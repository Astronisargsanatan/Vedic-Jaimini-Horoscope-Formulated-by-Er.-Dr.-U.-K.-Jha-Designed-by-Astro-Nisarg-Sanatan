import { useEffect, useMemo } from "react";
import { X } from "lucide-react";
import NorthChart from "./NorthChart";
import {
  PLANETS,
  formatDMS,
  houseOf,
  rashiName,
  type PlanetKey,
} from "../lib/astro";
import {
  calculateEcpMetrics,
  calculatePraveshChart,
  praveshSigns,
  type DashaPraveshRequest,
} from "../lib/dashaPravesh";
import type { NativeInfo } from "../state/ChartContext";

function formatDateTime(date: Date, timezone?: string) {
  const zone = (timezone ?? "").split(" (")[0];
  try {
    return new Intl.DateTimeFormat("en-GB", {
      timeZone: zone.includes("/") ? zone : undefined,
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23",
    })
      .format(date)
      .replace(",", "");
  } catch {
    return date.toISOString().replace("T", " ").slice(0, 19) + " UTC";
  }
}

export default function DashaPraveshModal({
  request,
  native,
  onClose,
}: {
  request: DashaPraveshRequest | null;
  native: NativeInfo | null;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!request) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", close);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", close);
      document.body.style.overflow = "";
    };
  }, [onClose, request]);

  const chart = useMemo(() => {
    if (!request || native?.lat == null || native.lon == null) return null;
    return calculatePraveshChart(native, request.selected.start);
  }, [native, request]);
  const signs = useMemo(() => (chart ? praveshSigns(chart) : null), [chart]);
  const metrics = useMemo(
    () => (request && native?.lat != null && native.lon != null ? calculateEcpMetrics(native, request.path) : []),
    [native, request],
  );
  const metricsByCode = new Map(metrics.map((metric) => [metric.code, metric]));
  const metricSlots = [
    {
      code: "ECPM" as const,
      label: "Event Controlling Planet of Mahadasha",
      level: "Mahadasha",
      explanation: "Mahadasha start second ka D1 Pravesh Lagna → uska Lagnesh.",
    },
    {
      code: "ECPA" as const,
      label: "Event Controlling Planet of Antardasha",
      level: "Antardasha",
      explanation: "Antardasha/Bhukti start second ka D1 Pravesh Lagna → uska Lagnesh.",
    },
    {
      code: "ECPP" as const,
      label: "Event Controlling Planet of Pratyantar Dasha",
      level: "Pratyantar Dasha",
      explanation: "Pratyantar start second ka D1 Pravesh Lagna → uska Lagnesh.",
    },
  ];

  if (!request) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end justify-center bg-stone-950/70 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section className="flex max-h-[96dvh] w-full max-w-5xl flex-col overflow-hidden rounded-t-3xl bg-[#faf3e6] shadow-2xl sm:max-h-[92dvh] sm:rounded-3xl">
        <header className="flex shrink-0 items-start justify-between gap-3 border-b border-amber-800/15 bg-[#7c2d12] px-4 py-4 text-amber-50 sm:px-6">
          <div className="min-w-0">
            <div className="text-[9px] font-bold uppercase tracking-[0.18em] text-amber-200">
              Dasha Pravesh Chart · Fixed Birth Location
            </div>
            <h2 className="mt-1 break-words font-serif text-xl font-black sm:text-2xl">
              {request.system}
            </h2>
            <p className="mt-1 text-xs text-amber-100/80">
              {request.selected.level} · {request.selected.name}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Dasha Pravesh Chart"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/20 bg-white/10 hover:bg-white/20"
          >
            <X className="h-5 w-5" />
          </button>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-3 sm:p-6">
          {!native || native.lat == null || native.lon == null ? (
            <div className="rounded-2xl border-2 border-amber-500 bg-amber-50 p-5 text-sm text-amber-900">
              Birth latitude/longitude is unavailable. Calculate the horoscope from Home first;
              Dasha Pravesh always uses the native's birth place, never current location.
            </div>
          ) : chart && signs ? (
            <>
              <div className="grid gap-2 text-xs sm:grid-cols-2 lg:grid-cols-4">
                <Meta label="Dasha System" value={request.system} />
                <Meta label="Level" value={request.selected.level} />
                <Meta label="Pravesh Date & Time" value={formatDateTime(request.selected.start, native.tz)} />
                <Meta
                  label="Fixed Birth Location"
                  value={`${native.place} · ${native.lat.toFixed(4)}, ${native.lon.toFixed(4)}`}
                />
              </div>

              <div className="mt-4 grid gap-5 lg:grid-cols-[minmax(0,380px)_1fr]">
                <div className="rounded-2xl border border-amber-800/15 bg-white p-3">
                  <NorthChart
                    signs={signs}
                    title={`${request.selected.level} Pravesh D1`}
                    subtitle={formatDateTime(request.selected.start, native.tz)}
                    accent="#7c2d12"
                  />
                </div>

                <div className="min-w-0 overflow-x-auto rounded-2xl border border-amber-800/15 bg-white">
                  <table className="w-full min-w-[560px] text-sm">
                    <thead>
                      <tr className="bg-amber-50 text-left text-[10px] font-bold uppercase tracking-wide text-amber-900">
                        <th className="px-3 py-2">Graha</th>
                        <th className="px-3 py-2">Rashi</th>
                        <th className="px-3 py-2">Longitude</th>
                        <th className="px-3 py-2">House</th>
                        <th className="px-3 py-2">Motion</th>
                      </tr>
                    </thead>
                    <tbody>
                      {PLANETS.map((planet) => {
                        const position = chart[planet.key as PlanetKey];
                        return (
                          <tr key={planet.key} className="border-t border-stone-100">
                            <td className="px-3 py-2 font-semibold">{planet.label}</td>
                            <td className="px-3 py-2">{position.sign}. {rashiName(position.sign)}</td>
                            <td className="px-3 py-2 font-mono text-xs">{formatDMS(position)}</td>
                            <td className="px-3 py-2 text-center font-mono">
                              {houseOf(position.sign, chart.Lagna.sign)}
                            </td>
                            <td className="px-3 py-2 text-center font-mono">{position.motion ?? "D"}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {metricSlots.map((slot) => {
                  const metric = metricsByCode.get(slot.code);
                  return (
                  <div
                    key={slot.code}
                    className={`rounded-2xl border-2 p-4 ${
                      metric
                        ? "border-emerald-600/25 bg-emerald-50"
                        : "border-stone-300 bg-white/80"
                    }`}
                  >
                    <div className={metric ? "font-mono text-sm font-black text-emerald-800" : "font-mono text-sm font-black text-stone-500"}>{slot.code}</div>
                    <div className={`mt-1 text-[10px] font-bold uppercase tracking-wide ${metric ? "text-emerald-700" : "text-stone-500"}`}>
                      {slot.label}
                    </div>
                    <div className="mt-2 font-serif text-lg font-black text-[#7c2d12]">
                      {metric ? metric.controller : "Not applicable"}
                    </div>
                    {metric ? (
                      <p className="mt-1 text-xs leading-relaxed text-stone-600">
                        {metric.periodName} entry chart Lagna: {metric.lagnaSign}. {rashiName(metric.lagnaSign)};
                        Lagnesh = {metric.controller}.
                      </p>
                    ) : (
                      <p className="mt-1 text-xs leading-relaxed text-stone-500">
                        {slot.level} path is not present for this selected level yet.
                      </p>
                    )}
                    <p className="mt-2 border-t border-current/10 pt-2 text-[10px] leading-relaxed text-stone-500">
                      Calculation: {slot.explanation}
                    </p>
                  </div>
                  );
                })}
              </div>
            </>
          ) : null}
        </div>
      </section>
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-amber-800/15 bg-white p-3">
      <div className="text-[9px] font-bold uppercase tracking-wide text-amber-700">{label}</div>
      <div className="mt-1 break-words font-semibold text-stone-800">{value}</div>
    </div>
  );
}
