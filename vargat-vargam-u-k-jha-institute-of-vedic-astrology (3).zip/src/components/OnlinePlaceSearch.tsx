import { useState } from "react";
import { Globe2, Search } from "lucide-react";

export type OnlinePlaceResult = {
  displayName: string;
  latitude: number;
  longitude: number;
  type: string;
};

export default function OnlinePlaceSearch({
  selected,
  onSelect,
}: {
  selected?: string;
  onSelect: (place: OnlinePlaceResult) => void;
}) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<OnlinePlaceResult[]>([]);
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = useState("");

  const search = async () => {
    if (query.trim().length < 2) {
      setStatus("error");
      setError("Enter at least 2 characters.");
      return;
    }
    setStatus("loading");
    setError("");
    try {
      const url = new URL("https://nominatim.openstreetmap.org/search");
      url.searchParams.set("q", query.trim());
      url.searchParams.set("format", "jsonv2");
      url.searchParams.set("addressdetails", "1");
      url.searchParams.set("limit", "8");
      const response = await fetch(url.toString(), { headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error(`Online geocoder returned ${response.status}.`);
      const data = (await response.json()) as Array<{
        display_name: string;
        lat: string;
        lon: string;
        type?: string;
      }>;
      setResults(
        data.map((item) => ({
          displayName: item.display_name,
          latitude: Number(item.lat),
          longitude: Number(item.lon),
          type: item.type ?? "place",
        })),
      );
      setStatus("idle");
      if (data.length === 0) {
        setStatus("error");
        setError("No online result found. Try district/state/country or use Manual Coordinates.");
      }
    } catch (reason) {
      setStatus("error");
      setError(
        reason instanceof Error
          ? `${reason.message} Use Offline Database or Manual Coordinates if internet/API is blocked.`
          : "Online search failed.",
      );
    }
  };

  return (
    <div className="rounded-2xl border-2 border-sky-500/25 bg-sky-50/50 p-4">
      <div className="flex items-start gap-3">
        <Globe2 className="mt-0.5 h-5 w-5 shrink-0 text-sky-700" />
        <div>
          <h3 className="font-serif text-base font-bold text-sky-950">Online Location Search</h3>
          <p className="mt-0.5 text-xs leading-relaxed text-sky-800/75">
            Internet geocoder se offline database ke bahar ki city/village search karein. Result
            select karne par latitude, longitude aur IANA timezone automatically resolve hote hain.
          </p>
        </div>
      </div>

      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              void search();
            }
          }}
          placeholder="Village, Taluka, District, State, Country"
          className="min-w-0 flex-1 rounded-xl border border-sky-800/20 bg-white px-3 py-3 text-sm outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-500/15"
        />
        <button
          type="button"
          onClick={() => void search()}
          disabled={status === "loading"}
          className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-sky-800 px-5 text-sm font-bold text-white transition hover:bg-sky-700 disabled:opacity-60"
        >
          <Search className="h-4 w-4" />
          {status === "loading" ? "Searching..." : "Search Online"}
        </button>
      </div>

      {error && <p className="mt-2 text-xs font-semibold text-rose-700">{error}</p>}
      {selected && (
        <div className="mt-3 rounded-xl border border-emerald-600/20 bg-emerald-50 px-3 py-2 text-xs text-emerald-900">
          <strong>Selected:</strong> {selected}
        </div>
      )}

      {results.length > 0 && (
        <div className="mt-3 max-h-72 overflow-y-auto rounded-xl border border-sky-800/15 bg-white">
          {results.map((place, index) => (
            <button
              key={`${place.latitude}-${place.longitude}-${index}`}
              type="button"
              onClick={() => onSelect(place)}
              className="flex w-full items-center justify-between gap-3 border-b border-stone-100 px-3 py-2.5 text-left transition last:border-0 hover:bg-sky-50"
            >
              <span className="min-w-0">
                <span className="block text-sm font-semibold text-stone-900">{place.displayName}</span>
                <span className="text-[10px] uppercase tracking-wide text-stone-400">{place.type}</span>
              </span>
              <span className="shrink-0 font-mono text-[10px] text-stone-500">
                {place.latitude.toFixed(5)}, {place.longitude.toFixed(5)}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
