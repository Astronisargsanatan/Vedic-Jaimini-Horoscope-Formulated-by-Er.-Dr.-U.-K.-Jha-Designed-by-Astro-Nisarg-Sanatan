import { useMemo, useState } from "react";
import {
  computeMuktashtakiDasha,
  formatMuktashtakiDate,
  muktashtakiLabel,
  type MuktashtakiPeriod,
} from "../lib/muktashtakiDasha";
import DashaPraveshModal from "./DashaPraveshModal";
import type { DashaPraveshRequest, PraveshAnchor } from "../lib/dashaPravesh";
import { useChart } from "../state/ChartContext";

function resolveBirth(date?: string, time?: string, utc?: string): Date {
  if (utc) {
    const exact = new Date(utc);
    if (!Number.isNaN(exact.getTime())) return exact;
  }
  const d = (date ?? "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const t = (time ?? "").match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  if (!d) return new Date();
  return new Date(
    Date.UTC(Number(d[3]), Number(d[2]) - 1, Number(d[1]), t ? Number(t[1]) : 12, t ? Number(t[2]) : 0, t ? Number(t[3] ?? 0) : 0) - 330 * 60000,
  );
}

function PeriodRow({
  period,
  level,
  path,
  active,
  timeZone,
  onOpen,
}: {
  period: MuktashtakiPeriod;
  level: 1 | 2 | 3;
  path: PraveshAnchor[];
  active: MuktashtakiPeriod | undefined;
  timeZone?: string;
  onOpen: (request: DashaPraveshRequest) => void;
}) {
  const isActive = active === period;
  const [expanded, setExpanded] = useState(isActive && level < 3);
  const levelName = level === 1 ? "Mahadasha" : level === 2 ? "Antardasha" : "Pratyantar Dasha";
  const current: PraveshAnchor = {
    level: levelName,
    name: muktashtakiLabel(period),
    start: period.start,
  };
  const currentPath = level === 1 ? [current] : [...path, current];

  return (
    <>
      <tr className={`border-b border-stone-200/70 ${isActive ? "bg-emerald-50" : "bg-white"}`}>
        <td className="px-3 py-2" style={{ paddingLeft: `${10 + (level - 1) * 18}px` }}>
          <button
            type="button"
            onClick={() => level < 3 && setExpanded((value) => !value)}
            className="flex items-center gap-2 text-left"
          >
            <span className="w-3 font-mono text-xs text-stone-400">
              {level < 3 ? (expanded ? "▾" : "▸") : ""}
            </span>
            <span className="font-serif font-black text-[#7c2d12]">{muktashtakiLabel(period)}</span>
            {isActive && <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-[9px] font-black text-white">ACTIVE</span>}
          </button>
        </td>
        <td className="px-3 py-2 text-xs text-stone-500">{levelName}</td>
        <td className="px-3 py-2 text-center font-mono font-black text-amber-800">{period.bindus}</td>
        <td className="px-3 py-2 font-mono text-xs text-stone-600">{formatMuktashtakiDate(period.start, timeZone)}</td>
        <td className="px-3 py-2 font-mono text-xs text-stone-600">{formatMuktashtakiDate(period.end, timeZone)}</td>
        <td className="px-3 py-2 text-xs text-stone-600">{period.years.toFixed(4)} years</td>
        <td className="px-3 py-2">
          <button
            type="button"
            onClick={() =>
              onOpen({
                system: "Muktashtaki Dasha · Ashtakavarga",
                selected: current,
                path: currentPath,
              })
            }
            className="whitespace-nowrap rounded-lg border border-indigo-700/20 bg-indigo-50 px-2 py-1 text-[9px] font-bold text-indigo-800 hover:bg-indigo-100"
          >
            View Dasha Pravesh Chart
          </button>
        </td>
      </tr>
      {expanded &&
        level < 3 &&
        period.children.map((child) => (
          <PeriodRow
            key={`${level + 1}-${period.order}-${child.order}`}
            period={child}
            level={(level + 1) as 2 | 3}
            path={currentPath}
            active={undefined}
            timeZone={timeZone}
            onOpen={onOpen}
          />
        ))}
    </>
  );
}

export default function MuktashtakiDashaSection() {
  const { chart, native } = useChart();
  const [pravesh, setPravesh] = useState<DashaPraveshRequest | null>(null);
  const birth = useMemo(() => resolveBirth(native?.date, native?.time, native?.birthUtc), [native]);
  const result = useMemo(() => computeMuktashtakiDasha(chart, birth), [birth, chart]);

  return (
    <div className="space-y-6">
      <header className="rounded-3xl border border-indigo-800/20 bg-gradient-to-br from-indigo-50 via-white to-amber-50 p-5 shadow-sm sm:p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-indigo-700">
          Ashtakavarga Timing · SAV 386
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Muktashtaki Dasha
        </h1>
        <p className="mt-3 max-w-4xl text-sm leading-relaxed text-stone-600">
          Sarvashtakavarga bindus के आधार पर राशि-दशा timing. हर Mahadasha, Antardasha और
          Pratyantar के exact start पर fixed Birth Place से Dasha Pravesh D1 और ECPM/ECPA/ECPP
          calculate होते हैं।
        </p>
        <div className="mt-4 rounded-xl border-2 border-amber-500/30 bg-amber-50 p-4 text-xs leading-relaxed text-amber-950">
          <strong>Method transparency:</strong> “Muktashtaki Dasha” की universally standardized
          classical sequence/duration table public references में उपलब्ध नहीं मिली। यह वर्तमान
          default <strong>{result.method}</strong> है: sequence SAV bindus high-to-low; tenure =
          max(1, bindus − 24) years; sub-period share = sign bindus / total 386. Institute की exact
          source table मिलने पर इसे उसी table से replace किया जा सकता है।
        </div>
      </header>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Info label="SAV Total" value={`${result.totalBindus} Bindus`} />
        <Info label="First Dasha" value={muktashtakiLabel(result.periods[0])} />
        <Info label="Active Maha" value={result.activeMaha ? muktashtakiLabel(result.activeMaha) : "Outside cycle"} />
        <Info label="Active Antar" value={result.activeAntar ? muktashtakiLabel(result.activeAntar) : "—"} />
      </section>

      <section className="rounded-3xl border border-amber-800/15 bg-white/85 p-4 shadow-sm sm:p-6">
        <h2 className="font-serif text-xl font-black text-[#7c2d12]">Bindu-ranked Rashi Sequence</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {result.periods.map((period) => (
            <span key={period.sign} className="rounded-lg border border-amber-800/15 bg-amber-50 px-2.5 py-1.5 text-xs">
              <strong>{period.order}. {muktashtakiLabel(period)}</strong> · {period.bindus} bindus
            </span>
          ))}
        </div>
      </section>

      <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-sm">
        <header className="border-b border-amber-800/10 bg-amber-50 px-4 py-4 sm:px-6">
          <h2 className="font-serif text-xl font-black text-[#7c2d12]">
            Maha → Antar → Pratyantar Table
          </h2>
          <p className="text-xs text-stone-500">Rows expand with ▸. Every level has its own Pravesh chart.</p>
        </header>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-sm">
            <thead>
              <tr className="bg-amber-50 text-left text-[10px] font-bold uppercase tracking-wide text-amber-900">
                <th className="px-3 py-2">Dasha Rashi</th><th className="px-3 py-2">Level</th>
                <th className="px-3 py-2">Bindus</th><th className="px-3 py-2">Start</th>
                <th className="px-3 py-2">End</th><th className="px-3 py-2">Duration</th>
                <th className="px-3 py-2">Pravesh / ECP</th>
              </tr>
            </thead>
            <tbody>
              {result.periods.map((period) => (
                <PeriodRow
                  key={period.order}
                  period={period}
                  level={1}
                  path={[]}
                  active={result.activeMaha}
                  timeZone={native?.tz}
                  onOpen={setPravesh}
                />
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <DashaPraveshModal request={pravesh} native={native} onClose={() => setPravesh(null)} />
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-amber-800/15 bg-white/85 p-4">
      <div className="text-[9px] font-bold uppercase tracking-wider text-amber-700">{label}</div>
      <div className="mt-1 font-serif text-base font-black text-[#7c2d12] sm:text-lg">{value}</div>
    </div>
  );
}
