import { computeAshtakavarga, BAV_DISPLAY, BAV_KEYS, KAKSHYA_ORDER } from "../lib/ashtakavarga";
import { computeCharaDasha, formatCharaDateTime } from "../lib/charaDasha";
import { computeSpousePrediction } from "../lib/spouse";
import { computeMandookDasha, formatMandookDate } from "../lib/mandookDasha";
import { computeAarshaVimshottari } from "../lib/aarshaVimshottari";
import { LORD_HINDI, formatDate, formatDuration } from "../lib/vimshottari";
import {
  computeMuktashtakiDasha,
  formatMuktashtakiDate,
  type MuktashtakiResult,
} from "../lib/muktashtakiDasha";
import { calculateEcpMetrics, type PraveshAnchor } from "../lib/dashaPravesh";
import { PLANETS, RASHI_LORDS, houseOf, rashiName, type Chart } from "../lib/astro";
import type { NativeInfo } from "../state/ChartContext";
import Logo from "./Logo";

export default function ExtendedPdfSections({
  chart,
  native,
  startPage,
  totalPages,
}: {
  chart: Chart;
  native: NativeInfo | null;
  startPage: number;
  totalPages: number;
}) {
  const av = computeAshtakavarga(chart);
  const birth = birthInstant(native);
  const chara = computeCharaDasha(chart, birth);
  const aarsha = computeAarshaVimshottari(chart, birth);
  const mandook = computeMandookDasha(chart, birth);
  const muktashtaki = computeMuktashtakiDasha(chart, birth);
  const activeChara = chara.periods.find((period) => new Date() >= period.start && new Date() < period.end);
  const activeMuktashtaki = [
    { level: "Mahadasha", period: muktashtaki.activeMaha },
    { level: "Antardasha", period: muktashtaki.activeAntar },
    { level: "Pratyantar Dasha", period: muktashtaki.activePratyantar },
  ];
  const match = computeSpousePrediction(chart);
  const matchRepetition = new Map(
    match.tally.map((item) => [item.sign, { count: item.rules.length, score: item.score }]),
  );

  return (
    <>
      {/* 8 separate Prastarashtakavarga pages */}
      {BAV_KEYS.map((target, targetIndex) => {
        const table = av.prastara[target];
        return (
          <section className="pdf-page" key={`pdf-prastara-${target}`}>
            <ExtendedLetterhead />
            <h2 className="pdf-title">
              Part {targetIndex + 1} · {BAV_DISPLAY[target]} Prastarashtakavarga
            </h2>
            <p className="pdf-note">
              Kakshya order: Shani → Guru → Mangal → Surya → Shukra → Budh → Chandra → Lagna ·
              1 = Bindu, blank = Rekha · verified total {table.expectedTotal}.
            </p>

            <table className="pdf-table pdf-prastara">
              <thead>
                <tr>
                  <th>Contributor</th>
                  {Array.from({ length: 12 }, (_, i) => (
                    <th key={i} className="center">
                      {i + 1}
                      <small>{rashiName(i + 1)}</small>
                    </th>
                  ))}
                  <th className="center">Total</th>
                </tr>
              </thead>
              <tbody>
                {KAKSHYA_ORDER.map((contributor) => (
                  <tr key={contributor}>
                    <td className="font-semibold">{BAV_DISPLAY[contributor]}</td>
                    {table.rows[contributor].map((value, i) => (
                      <td key={i} className={`center mono ${value ? "pdf-bindu" : "pdf-rekha"}`}>
                        {value ? "1" : ""}
                      </td>
                    ))}
                    <td className="center mono font-semibold">{table.rowTotals[contributor]}</td>
                  </tr>
                ))}
                <tr className="pdf-total-row">
                  <td className="font-semibold">Total Bindus</td>
                  {table.signTotals.map((value, i) => (
                    <td key={i} className="center mono font-semibold">{value}</td>
                  ))}
                  <td className="center mono font-semibold">
                    {table.grandTotal} {table.verified ? "✓" : "✗"}
                  </td>
                </tr>
              </tbody>
            </table>

            <BinduChart
              title={`${BAV_DISPLAY[target]} BAV Kundali`}
              bindus={table.signTotals}
              lagna={chart.Lagna.sign}
              marker={{ sign: chart[target].sign, label: target === "Lagna" ? "La" : target.slice(0, 2) }}
            />
            <ExtendedFooter page={startPage + targetIndex} total={totalPages} />
          </section>
        );
      })}

      {/* Master SAV page */}
      <section className="pdf-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Part 9 · Master Sarvashtakavarga (386 Bindus)</h2>
        <p className="pdf-note">
          Surya 48 + Chandra 49 + Mangal 39 + Budh 54 + Guru 56 + Shukra 52 + Shani 39 + Lagna
          49 = 386. Lagnashtakavarga is included.
        </p>
        <table className="pdf-table pdf-prastara">
          <thead>
            <tr>
              <th>Contributor</th>
              {Array.from({ length: 12 }, (_, i) => (
                <th key={i} className="center">
                  {i + 1}
                  <small>{rashiName(i + 1)}</small>
                </th>
              ))}
              <th className="center">Total</th>
            </tr>
          </thead>
          <tbody>
            {BAV_KEYS.map((key) => (
              <tr key={key}>
                <td className="font-semibold">{BAV_DISPLAY[key]}</td>
                {av.bav[key].map((value, i) => (
                  <td key={i} className="center mono">{value}</td>
                ))}
                <td className="center mono font-semibold">{av.totals[key]}</td>
              </tr>
            ))}
            <tr className="pdf-total-row">
              <td className="font-semibold">SAV Total</td>
              {av.sarva.map((value, i) => (
                <td key={i} className="center mono font-semibold">{value}</td>
              ))}
              <td className="center mono font-semibold">{av.sarvaTotal} ✓</td>
            </tr>
          </tbody>
        </table>
        <BinduChart
          title="Complete Natal Kundali with SAV Bindus"
          bindus={av.sarva}
          lagna={chart.Lagna.sign}
          chart={chart}
        />
        <ExtendedFooter page={startPage + 8} total={totalPages} />
      </section>

      {/* Muktashtaki immediately follows Master SAV, as part of Ashtakavarga. */}
      <section className="pdf-page prediction-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Muktashtaki Dasha · SAV 386 Calculation</h2>
        <p className="pdf-note">
          Institutional configurable method: Rashi sequence by SAV bindus high-to-low; tie by
          natal house order. Tenure = max(1, SAV bindus − 24) years. Sub-period share = Rashi
          bindus / 386.
        </p>
        <table className="pdf-meta">
          <tbody>
            <tr><th>SAV Total</th><td>{muktashtaki.totalBindus}</td><th>Method</th><td>{muktashtaki.method}</td></tr>
            <tr><th>First Dasha</th><td>{muktashtaki.periods[0].sign}. {rashiName(muktashtaki.periods[0].sign)}</td><th>Active Maha</th><td>{muktashtaki.activeMaha ? `${muktashtaki.activeMaha.sign}. ${rashiName(muktashtaki.activeMaha.sign)}` : "Outside cycle"}</td></tr>
          </tbody>
        </table>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>#</th><th>Dasha Rashi</th><th>SAV</th><th>Tenure</th><th>Start</th><th>End</th><th>Natal House</th><th>Rashi Lord</th></tr></thead>
          <tbody>
            {muktashtaki.periods.map((period) => (
              <tr key={`muk-maha-${period.order}`} className={period === muktashtaki.activeMaha ? "pdf-active-row" : ""}>
                <td className="center">{period.order}</td><td>{period.sign}. {rashiName(period.sign)}</td><td className="center mono">{period.bindus}</td>
                <td>{period.years.toFixed(4)} years</td><td className="mono">{formatMuktashtakiDate(period.start, native?.tz)}</td><td className="mono">{formatMuktashtakiDate(period.end, native?.tz)}</td>
                <td className="center">H{houseOf(period.sign, chart.Lagna.sign)}</td><td>{RASHI_LORDS[period.sign]}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <h3 className="pdf-h3">Muktashtaki Rashi-Phala</h3>
        <div className="pdf-two-column-text">
          {muktashtaki.periods.map((period) => {
            const house = houseOf(period.sign, chart.Lagna.sign);
            const occupants = PLANETS.filter((planet) => planet.key !== "Lagna" && chart[planet.key].sign === period.sign).map((planet) => planet.key);
            return (
              <p key={`muk-phala-${period.order}`}>
                <strong>{period.order}. {rashiName(period.sign)}:</strong> जन्म लग्न से H{house}, SAV {period.bindus}; राशीश {RASHI_LORDS[period.sign]}; {occupants.length ? `स्थित ग्रह ${occupants.join(", ")}` : "कोई natal ग्रह स्थित नहीं"}। फल मुख्यतः H{house} के विषय, राशीश की स्थिति और सक्रिय उपदशा से प्रकट होगा।
              </p>
            );
          })}
        </div>
        <ExtendedFooter page={startPage + 9} total={totalPages} />
      </section>

      <section className="pdf-page prediction-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Muktashtaki · Active Antar, Pratyantar & Event Controllers</h2>
        <p className="pdf-note">
          Active hierarchy and Dasha Pravesh controllers use each period's exact start second and
          the native's fixed birth latitude/longitude.
        </p>
        <table className="pdf-table">
          <thead><tr><th>Level</th><th>Rashi</th><th>SAV</th><th>Start</th><th>End</th><th>Natal House</th></tr></thead>
          <tbody>
            {activeMuktashtaki.map(({ level, period }) =>
              period ? (
                <tr key={`muk-active-${level}`} className="pdf-active-row">
                  <td>{level}</td><td>{period.sign}. {rashiName(period.sign)}</td><td className="center">{period.bindus}</td>
                  <td className="mono">{formatMuktashtakiDate(period.start, native?.tz)}</td><td className="mono">{formatMuktashtakiDate(period.end, native?.tz)}</td>
                  <td className="center">H{houseOf(period.sign, chart.Lagna.sign)}</td>
                </tr>
              ) : null,
            )}
          </tbody>
        </table>
        <MuktashtakiEcp chart={chart} native={native} result={muktashtaki} />
        <h3 className="pdf-h3">Active Period Interpretation</h3>
        <p className="pdf-prediction-box">
          {muktashtaki.activeMaha
            ? `सक्रिय महादशा ${rashiName(muktashtaki.activeMaha.sign)} जन्म लग्न से ${houseOf(muktashtaki.activeMaha.sign, chart.Lagna.sign)}वें भाव को सक्रिय करती है। इसके ${muktashtaki.activeMaha.bindus} SAV बिन्दु फल की सहजता/प्रयास का मात्रात्मक आधार हैं।`
            : "वर्तमान समय प्रथम configured Muktashtaki cycle के बाहर है।"}
          {muktashtaki.activeAntar ? ` अंतर्दशा ${rashiName(muktashtaki.activeAntar.sign)} उस भाव और उसके राशीश के विषयों को सूक्ष्म रूप से जोड़ती है।` : ""}
          {muktashtaki.activePratyantar ? ` प्रत्यंतर ${rashiName(muktashtaki.activePratyantar.sign)} घटना-स्तर timing को सीमित करता है।` : ""}
        </p>
        <ExtendedFooter page={startPage + 10} total={totalPages} />
      </section>

      {/* Char Dasha page */}
      <section className="pdf-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Jaimini Char Dasha · A9 Bhagya Pada Based</h2>
        <table className="pdf-meta">
          <tbody>
            <tr>
              <th>A9 / Bhagya Pada</th>
              <td>{chara.a9Sign}. {rashiName(chara.a9Sign)}</td>
              <th>AL / A1</th>
              <td>{chara.a1Sign}. {rashiName(chara.a1Sign)}</td>
            </tr>
            <tr>
              <th>Direction</th>
              <td>{chara.direction}</td>
              <th>Uniform Madhya Bindu</th>
              <td className="mono">{chara.lagnaMadhyaDms}</td>
            </tr>
          </tbody>
        </table>
        <table className="pdf-table pdf-dense">
          <thead>
            <tr>
              <th>#</th><th>Dasha Rashi</th><th>Class</th><th>Lord</th><th>Madhya</th>
              <th>Lord Longitude</th><th>Difference</th><th>Duration</th><th>Start</th><th>End</th>
            </tr>
          </thead>
          <tbody>
            {chara.periods.map((period) => (
              <tr key={period.order}>
                <td className="center">{period.order}</td>
                <td>{period.sign}. {period.signName}</td>
                <td>{period.classification}</td>
                <td>{period.lord}</td>
                <td className="mono">{period.madhyaLongitudeDms}</td>
                <td className="mono">{period.lordLongitudeDms}</td>
                <td className="mono">{period.differenceDms}</td>
                <td className="mono">{period.duration.label}</td>
                <td className="mono">{formatCharaDateTime(period.start, native?.tz)}</td>
                <td className="mono">{formatCharaDateTime(period.end, native?.tz)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="pdf-note">
          First period starts at the exact birth instant. Each next period starts at the previous
          period's exact end, including HH:MM:SS.
        </p>
        <EcpPdfTable
          native={native}
          anchors={activeChara ? [{ level: "Mahadasha", name: `${activeChara.sign}. ${activeChara.signName}`, start: activeChara.start }] : []}
        />
        <ExtendedFooter page={startPage + 11} total={totalPages} />
      </section>

      {/* Aarsha Vimshottari — cycle and trigger calculation */}
      <section className="pdf-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Rishi Pranit Aarsha Vimshottari · Cycle & Trigger</h2>
        <table className="pdf-meta">
          <tbody>
            <tr>
              <th>Birth Hora</th><td>{aarsha.hora}</td>
              <th>Birth Paksha</th><td>{aarsha.paksha}</td>
            </tr>
            <tr>
              <th>Applicable Cycle</th><td>{aarsha.cycle}</td>
              <th>First Dasha Lord</th><td>{LORD_HINDI[aarsha.firstDashaLord]} · {aarsha.firstDashaLord}</td>
            </tr>
            <tr>
              <th>Lagna / Moon Nakshatra</th>
              <td>{aarsha.lagnaNakshatra.name} / {aarsha.moonNakshatra.name}</td>
              <th>Inclusive Count</th><td>{aarsha.inclusiveCount}</td>
            </tr>
            <tr>
              <th>Target Nakshatra</th><td>{aarsha.targetNakshatra.name}</td>
              <th>Triggering Planet</th><td>{aarsha.triggeringPlanet}</td>
            </tr>
            <tr>
              <th>Trigger Planet Nakshatra</th><td>{aarsha.triggeringPlanetNakshatra.name} · Pada {aarsha.triggeringPlanetNakshatra.pada}</td>
              <th>First Dasha Lord</th><td>{aarsha.firstDashaLord}</td>
            </tr>
            <tr>
              <th>Balance Source Nakshatra</th>
              <td>{aarsha.firstDashaLordNakshatra.name} · Pada {aarsha.firstDashaLordNakshatra.pada}</td>
              <th>Dasha Lord Longitude</th>
              <td className="mono">{chart[aarsha.firstDashaLord].sign}R {chart[aarsha.firstDashaLord].deg}° {chart[aarsha.firstDashaLord].min}′ {chart[aarsha.firstDashaLord].sec}″</td>
            </tr>
            <tr>
              <th>Traversed / Remaining Arc</th>
              <td className="mono">{aarsha.traversedArcMinutes.toFixed(6)}′ / {aarsha.remainingArcMinutes.toFixed(6)}′</td>
              <th>Nakshatra Full Arc</th><td>800′ (13°20′)</td>
            </tr>
            <tr>
              <th>Bhukta at Birth</th><td>{formatDuration(aarsha.bhuktaAtBirthMs)}</td>
              <th>Bhogya at Birth</th><td>{formatDuration(aarsha.bhogyaAtBirthMs)}</td>
            </tr>
          </tbody>
        </table>
        <p className="pdf-note">
          Lagna Nakshatra → Moon Nakshatra inclusive count = {aarsha.inclusiveCount}; Moon से वही
          count → {aarsha.targetNakshatra.name}; applicable cycle owner = {aarsha.triggeringPlanet}.
          Triggering planet के natal Nakshatra owner से first Dasha Lord = {aarsha.firstDashaLord}.
          Balance केवल {aarsha.firstDashaLord} की अपनी longitude in {aarsha.firstDashaLordNakshatra.name}
          से: Remaining {aarsha.remainingArcMinutes.toFixed(6)}′ / 800′ × {aarsha.firstDashaYears} years.
          DOB + Bhogya = first Dasha end. Triggering planet degrees balance में use नहीं हुईं।
        </p>
        <h3 className="pdf-h3">Aarsha Mahadasha Table</h3>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>#</th><th>Lord</th><th>Start</th><th>End</th><th>Duration</th></tr></thead>
          <tbody>
            {aarsha.mahadashas.map((period, index) => (
              <tr key={`aarsha-maha-${index}`}>
                <td className="center">{index + 1}</td>
                <td>{LORD_HINDI[period.lord]} · {period.lord}</td>
                <td className="mono">{formatDate(period.start)}</td>
                <td className="mono">{formatDate(period.end)}</td>
                <td>{formatDuration(period.durationMs)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <ExtendedFooter page={startPage + 12} total={totalPages} />
      </section>

      {/* Aarsha active five-level hierarchy */}
      <section className="pdf-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Aarsha Vimshottari · Active Maha to Pran</h2>
        <p className="pdf-note">
          Current active hierarchy generated from the selected {aarsha.cycle} cycle and triggering
          planet {aarsha.triggeringPlanet}.
        </p>
        <table className="pdf-table">
          <thead><tr><th>Level</th><th>Lord</th><th>Start</th><th>End</th><th>Duration</th></tr></thead>
          <tbody>
            {aarsha.activePath.map((period) => (
              <tr key={`aarsha-active-${period.level}`} className="pdf-active-row">
                <td>L{period.level}</td>
                <td>{LORD_HINDI[period.lord]} · {period.lord}</td>
                <td className="mono">{formatDate(period.start)}</td>
                <td className="mono">{formatDate(period.end)}</td>
                <td>{formatDuration(period.durationMs)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <EcpPdfTable
          native={native}
          anchors={aarsha.activePath.slice(0, 3).map((period) => ({
            level: period.level === 1 ? "Mahadasha" : period.level === 2 ? "Antardasha" : "Pratyantar Dasha",
            name: period.lord,
            start: period.start,
          }))}
        />
        <h3 className="pdf-h3">Cycle Decision Rule</h3>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>Hora</th><th>Paksha</th><th>Cycle</th></tr></thead>
          <tbody>
            <tr><td>Surya Hora</td><td>Shukla Paksha</td><td>Ardradi</td></tr>
            <tr><td>Chandra Hora</td><td>Krishna Paksha</td><td>Ardradi</td></tr>
            <tr><td>Surya Hora</td><td>Krishna Paksha</td><td>Krittikadi</td></tr>
            <tr><td>Chandra Hora</td><td>Shukla Paksha</td><td>Krittikadi</td></tr>
          </tbody>
        </table>
        <ExtendedFooter page={startPage + 13} total={totalPages} />
      </section>

      {/* Mandook Dasha — Maha periods */}
      <section className="pdf-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Jaimini Mandook Dasha · Maha Dasha & Birth Balance</h2>
        <table className="pdf-meta">
          <tbody>
            <tr>
              <th>Natal Lagna</th>
              <td>{mandook.lagnaSign}. {rashiName(mandook.lagnaSign)} · {mandook.polarity}</td>
              <th>Starting Sign</th>
              <td>{mandook.startingSign}. {rashiName(mandook.startingSign)}</td>
            </tr>
            <tr>
              <th>Starting Modality</th>
              <td>{mandook.modality}</td>
              <th>Cycle / Per Sign</th>
              <td>{mandook.totalCycleYears} years / {mandook.yearsPerSign} years</td>
            </tr>
            <tr>
              <th>Lagna Absolute Longitude M</th>
              <td className="mono">{mandook.lagnaAbsoluteLongitude.toFixed(6)}°</td>
              <th>Consumed / Balance</th>
              <td>{mandook.consumed.label} / {mandook.balance.label}</td>
            </tr>
          </tbody>
        </table>
        <p className="pdf-note">
          Dc = (M / 360) × N. Db = N − Dc. First Dasha End = Date of Birth + Db. Critical
          junction: 6th → 7th Maha Dasha.
        </p>
        <EcpPdfTable
          native={native}
          anchors={[
            ...(mandook.activeMaha ? [{ level: "Mahadasha" as const, name: `${mandook.activeMaha.sign}. ${rashiName(mandook.activeMaha.sign)}`, start: mandook.activeMaha.start }] : []),
            ...(mandook.activeBhukti ? [{ level: "Antardasha" as const, name: `${mandook.activeBhukti.sign}. ${rashiName(mandook.activeBhukti.sign)}`, start: mandook.activeBhukti.start }] : []),
          ]}
        />
        <table className="pdf-table pdf-dense">
          <thead>
            <tr><th>#</th><th>Maha Sign</th><th>Start</th><th>End</th><th>Duration</th><th>Junction</th></tr>
          </thead>
          <tbody>
            {mandook.mahadashas.map((maha) => (
              <tr key={`pdf-man-maha-${maha.order}`}>
                <td className="center">{maha.order}</td>
                <td>{maha.sign}. {rashiName(maha.sign)}</td>
                <td className="mono">{formatMandookDate(maha.start, native?.tz)}</td>
                <td className="mono">{formatMandookDate(maha.end, native?.tz)}</td>
                <td>{maha.duration.label}</td>
                <td>{maha.junctionAfter ? "6→7 MAJOR JUNCTION" : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <ExtendedFooter page={startPage + 14} total={totalPages} />
      </section>

      {/* Mandook Dasha — Bhukti matrix */}
      <section className="pdf-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Jaimini Mandook Dasha · Complete Bhukti Sequence Matrix</h2>
        <p className="pdf-note">
          {mandook.polarity} Lagna Bhukti table. Each row starts with its operating Maha sign;
          every Bhukti = 1/12 of its parent duration. Columns 6→7 mark the karmic inflection.
        </p>
        <table className="pdf-table pdf-dense">
          <thead>
            <tr>
              <th>Maha</th>
              {Array.from({ length: 12 }, (_, index) => (
                <th key={index} className="center">B{index + 1}{index === 5 ? " ↓" : ""}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {mandook.mahadashas.map((maha) => (
              <tr key={`pdf-man-bhukti-${maha.order}`}>
                <td className="font-semibold">{maha.sign}. {rashiName(maha.sign)}</td>
                {maha.bhuktis.map((bhukti) => (
                  <td key={bhukti.order} className={`center mono ${bhukti.junctionAfter ? "pdf-junction" : ""}`}>
                    {bhukti.sign}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        <h3 className="pdf-h3">Active Mandook Period</h3>
        <p className="pdf-note">
          Maha: {mandook.activeMaha ? `${mandook.activeMaha.sign}. ${rashiName(mandook.activeMaha.sign)}` : "Outside first cycle"}
          {mandook.activeBhukti ? ` · Bhukti: ${mandook.activeBhukti.sign}. ${rashiName(mandook.activeBhukti.sign)}` : ""}
        </p>
        <ExtendedFooter page={startPage + 15} total={totalPages} />
      </section>

      <section className="pdf-page prediction-page">
        <ExtendedLetterhead />
        <h2 className="pdf-title">Match–Matching · Overall Summary Only</h2>
        <p className="pdf-note">
          Internal 47-point scoring was evaluated, but individual point details are intentionally
          omitted. Only the organized overall conclusion is displayed.
        </p>
        <table className="pdf-meta">
          <tbody>
            <tr>
              <th>Most Likely Spouse Rashi</th>
              <td>{match.topSign ? `${match.topSign}. ${rashiName(match.topSign)}` : "—"}</td>
              <th>Weighted Score</th><td>{match.topScore}</td>
            </tr>
            <tr>
              <th>7th Sign</th><td>{match.seventhSign}. {rashiName(match.seventhSign)}</td>
              <th>DK / UL</th><td>{match.dkPlanet} · {rashiName(match.dkSign)} / {rashiName(match.ulSign)}</td>
            </tr>
            <tr>
              <th>Final Rashi Repetition</th>
              <td>{match.topSign ? `${matchRepetition.get(match.topSign)?.count ?? 0} internal signals` : "—"}</td>
              <th>Rules Evaluated</th><td>47 internal points</td>
            </tr>
          </tbody>
        </table>
        <h3 className="pdf-h3">Candidate Rashi Ranking</h3>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>Rank</th><th>Candidate Rashi</th><th>Repetition Count</th><th>Weighted Score</th><th>Supporting Rule Numbers</th></tr></thead>
          <tbody>
            {match.tally.map((item, index) => (
              <tr key={`match-summary-${item.sign}`} className={index === 0 ? "pdf-active-row" : ""}>
                <td className="center">{index + 1}</td><td>{item.sign}. {rashiName(item.sign)}</td>
                <td className="center mono">{item.rules.length}</td><td className="center mono">{item.score}</td>
                <td className="mono">{item.rules.join(", ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="pdf-prediction-box">
          Overall synthesis: 7th sign, Darakaraka, Upapada/A7, D9, D12, Ashtakavarga and
          Karakamsha signals were combined internally. Highest scoring and most repeated Rashi is
          {" "}{match.topSign ? `${match.topSign}. ${rashiName(match.topSign)}` : "not available"}. This is a summary indication, not a separate replacement for full horoscope matching.
        </p>
        <ExtendedFooter page={startPage + 16} total={totalPages} />
      </section>
    </>
  );
}

function MuktashtakiEcp({
  native,
  result,
}: {
  chart: Chart;
  native: NativeInfo | null;
  result: MuktashtakiResult;
}) {
  if (!native || native.lat == null || native.lon == null) {
    return <p className="pdf-note">ECP metrics require calculated birth coordinates.</p>;
  }
  const anchors: PraveshAnchor[] = [];
  if (result.activeMaha) {
    anchors.push({
      level: "Mahadasha",
      name: `${result.activeMaha.sign}. ${rashiName(result.activeMaha.sign)}`,
      start: result.activeMaha.start,
    });
  }
  if (result.activeAntar) {
    anchors.push({
      level: "Antardasha",
      name: `${result.activeAntar.sign}. ${rashiName(result.activeAntar.sign)}`,
      start: result.activeAntar.start,
    });
  }
  if (result.activePratyantar) {
    anchors.push({
      level: "Pratyantar Dasha",
      name: `${result.activePratyantar.sign}. ${rashiName(result.activePratyantar.sign)}`,
      start: result.activePratyantar.start,
    });
  }
  const metrics = calculateEcpMetrics(native, anchors);
  return (
    <>
      <h3 className="pdf-h3">Dasha Pravesh Event Controllers</h3>
      <table className="pdf-table pdf-dense">
        <thead><tr><th>Metric</th><th>Period</th><th>Pravesh Lagna</th><th>Controller / Lagnesh</th></tr></thead>
        <tbody>
          {metrics.map((metric) => (
            <tr key={metric.code}>
              <td className="font-semibold">{metric.code}</td><td>{metric.periodName}</td>
              <td>{metric.lagnaSign}. {rashiName(metric.lagnaSign)}</td><td>{metric.controller}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

function EcpPdfTable({ native, anchors }: { native: NativeInfo | null; anchors: PraveshAnchor[] }) {
  if (!anchors.length) return null;
  if (!native || native.lat == null || native.lon == null) {
    return <p className="pdf-note">Dasha Pravesh / ECP requires birth coordinates.</p>;
  }
  const metrics = calculateEcpMetrics(native, anchors);
  return (
    <>
      <h3 className="pdf-h3">Dasha Pravesh · ECPM / ECPA / ECPP</h3>
      <table className="pdf-table pdf-dense">
        <thead><tr><th>Metric</th><th>Period</th><th>Pravesh Lagna</th><th>Controller</th><th>Calculation</th></tr></thead>
        <tbody>
          {metrics.map((metric) => (
            <tr key={`${metric.code}-${metric.periodName}`}>
              <td className="font-semibold">{metric.code}</td><td>{metric.periodName}</td>
              <td>{metric.lagnaSign}. {rashiName(metric.lagnaSign)}</td><td>{metric.controller}</td>
              <td>{metric.code} = Pravesh D1 Lagna Lord / Lagnesh at exact start second</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

function BinduChart({
  title,
  bindus,
  lagna,
  marker,
  chart,
}: {
  title: string;
  bindus: number[];
  lagna: number;
  marker?: { sign: number; label: string };
  chart?: Chart;
}) {
  const positions = [
    { x: 150, y: 62 }, { x: 75, y: 32 }, { x: 32, y: 75 }, { x: 62, y: 150 },
    { x: 32, y: 225 }, { x: 75, y: 268 }, { x: 150, y: 238 }, { x: 225, y: 268 },
    { x: 268, y: 225 }, { x: 238, y: 150 }, { x: 268, y: 75 }, { x: 225, y: 32 },
  ];
  const chartMarkers = chart
    ? Object.entries(chart)
        .filter(([key]) => key !== "Rahu" && key !== "Ketu")
        .map(([key, position]) => ({ sign: position.sign, label: key === "Lagna" ? "La" : key.slice(0, 2) }))
    : [];

  return (
    <div className="pdf-bindu-chart">
      <h3 className="pdf-h3">{title}</h3>
      <svg viewBox="0 0 300 300" className="pdf-north-bindu">
        <rect x="0" y="0" width="300" height="300" fill="#fffdf8" stroke="#7c2d12" strokeWidth="2" />
        <line x1="0" y1="0" x2="300" y2="300" stroke="#7c2d12" strokeWidth="1.2" />
        <line x1="300" y1="0" x2="0" y2="300" stroke="#7c2d12" strokeWidth="1.2" />
        <polygon points="150,0 300,150 150,300 0,150" fill="none" stroke="#7c2d12" strokeWidth="1.2" />
        {positions.map((position, index) => {
          const house = index + 1;
          const sign = ((lagna - 1 + index) % 12) + 1;
          const labels = [
            ...(marker?.sign === sign ? [marker.label] : []),
            ...chartMarkers.filter((item) => item.sign === sign).map((item) => item.label),
          ];
          return (
            <g key={house}>
              <text x={position.x} y={position.y - 17} textAnchor="middle" fontSize="9" fontWeight="700" fill="#b45309">
                H{house} · R{sign}
              </text>
              <circle cx={position.x} cy={position.y + 1} r="15" fill="#7c2d12" />
              <text x={position.x} y={position.y + 6} textAnchor="middle" fontSize="12" fontWeight="900" fill="#fff">
                {bindus[sign - 1]}
              </text>
              {labels.map((label, labelIndex) => (
                <text key={`${label}-${labelIndex}`} x={position.x} y={position.y + 23 + labelIndex * 8} textAnchor="middle" fontSize="7" fontWeight="800" fill="#1e3a8a">
                  {label}
                </text>
              ))}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function birthInstant(native: NativeInfo | null): Date {
  if (native?.birthUtc) {
    const date = new Date(native.birthUtc);
    if (!Number.isNaN(date.getTime())) return date;
  }
  const d = (native?.date ?? "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const t = (native?.time ?? "").match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  if (!d) return new Date();
  return new Date(
    Date.UTC(Number(d[3]), Number(d[2]) - 1, Number(d[1]), t ? Number(t[1]) : 12, t ? Number(t[2]) : 0, t ? Number(t[3] ?? 0) : 0) - 330 * 60000,
  );
}

function ExtendedLetterhead() {
  return (
    <div className="pdf-head">
      <Logo className="pdf-logo" />
      <div>
        <div className="pdf-inst">U K Jha Institute of Vedic Astrology</div>
        <div className="pdf-by">President · Er. Dr. U K Jha</div>
        <div className="pdf-sub">Vice-President · Astro Nisarg Sanatan · Gujarat Chapter — (+91) 9998074088</div>
      </div>
    </div>
  );
}

function ExtendedFooter(_props: { page: number; total: number }) {
  return (
    <div className="pdf-foot">
      <span>U K Jha Institute of Vedic Astrology ; Er. Dr. U K Jha & Astro Nisarg Sanatan — (+91) 9998074088</span>
    </div>
  );
}