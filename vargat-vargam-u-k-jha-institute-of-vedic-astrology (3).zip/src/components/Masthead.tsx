import Logo from "./Logo";

export default function Masthead() {
  return (
    <header className="relative overflow-hidden rounded-[2rem] border border-amber-800/20 bg-gradient-to-b from-[#fffaf0] via-[#fdf4e3] to-[#f9ecd6] px-5 py-10 text-center shadow-[0_18px_50px_-25px_rgba(120,53,15,0.45)] sm:px-10 sm:py-12">
      {/* subtle rays backdrop */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{
          background:
            "repeating-conic-gradient(from 0deg at 50% 0%, #b45309 0deg 4deg, transparent 4deg 12deg)",
        }}
      />
      <div className="pointer-events-none absolute inset-x-6 top-3 h-px bg-gradient-to-r from-transparent via-amber-700/40 to-transparent" />

      <div className="relative flex flex-col items-center">
        <Logo className="h-36 w-36 object-contain drop-shadow-[0_10px_24px_rgba(120,53,15,0.35)] sm:h-48 sm:w-48" />

        {/* Title */}
        <h1 className="mt-6 font-serif text-2xl font-black uppercase leading-tight tracking-tight text-[#14532d] sm:text-4xl">
          U K Jha Institute
          <span className="mt-1 block font-serif text-lg font-bold uppercase tracking-[0.14em] text-[#3730a3] sm:text-2xl">
            of Vedic Astrology
          </span>
        </h1>

        <div className="mt-6 flex w-full max-w-3xl flex-col items-stretch gap-3 sm:flex-row sm:justify-center">
          <div className="flex-1 rounded-2xl border border-amber-800/15 bg-white/70 px-4 py-3 shadow-sm">
            <div className="text-[10px] font-semibold uppercase tracking-[0.22em] text-amber-700">
              President
            </div>
            <div className="mt-1 font-serif text-lg font-bold text-[#4a2511]">Er. Dr. U K Jha</div>
          </div>
          <div className="flex-1 rounded-2xl border border-amber-800/15 bg-white/70 px-4 py-3 shadow-sm">
            <div className="text-[10px] font-semibold uppercase tracking-[0.22em] text-amber-700">
              Vice President
            </div>
            <div className="mt-1 font-serif text-lg font-bold text-[#4a2511]">
              Astro Nisarg Sanatan
            </div>
            <div className="text-xs text-stone-500">Gujarat Chapter</div>
          </div>
        </div>

        {/* Large text — Vargat Vargam page only */}
        <div className="mt-10 w-full">
          <div className="mx-auto mb-5 flex items-center justify-center gap-3">
            <span className="h-px w-16 bg-gradient-to-r from-transparent to-amber-700/50" />
            <span className="text-lg text-amber-700">❖</span>
            <span className="h-px w-16 bg-gradient-to-l from-transparent to-amber-700/50" />
          </div>
          <h2 className="font-serif text-5xl font-black uppercase leading-none tracking-tight sm:text-7xl lg:text-8xl">
            <span className="bg-gradient-to-b from-[#b45309] via-[#9a3412] to-[#7c2d12] bg-clip-text text-transparent">
              Vargat Vargam
            </span>
          </h2>
          <p className="mx-auto mt-5 max-w-3xl text-sm leading-relaxed text-stone-600 sm:text-base">
            One of the Pentadic Principles — Panch Lakshana — of chart evaluation in Maharishi
            Parashara&rsquo;s system (Classical Indian Astrology)
          </p>
          <div className="mt-6 inline-flex items-center gap-3 rounded-full border border-amber-700/30 bg-amber-100/80 px-6 py-2 shadow-sm">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-700" />
            <span className="font-serif text-xl font-bold tracking-wide text-[#7c2d12] sm:text-2xl">
              Varga Engineering
            </span>
            <span className="h-1.5 w-1.5 rounded-full bg-amber-700" />
          </div>
        </div>
      </div>
    </header>
  );
}
