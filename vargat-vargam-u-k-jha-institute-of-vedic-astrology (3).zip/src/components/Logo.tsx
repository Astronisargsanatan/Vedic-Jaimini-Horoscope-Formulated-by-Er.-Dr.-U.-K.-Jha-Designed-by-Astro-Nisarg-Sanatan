import { useEffect, useState } from "react";

/**
 * Logo with its white background removed at runtime.
 *
 * The source /logo.png is actually an opaque JPEG-style raster, so its white
 * box is baked into the pixels. `mix-blend-mode: multiply` is unreliable inside
 * gradient/shadow containers, so we instead process the bitmap once on a canvas
 * and make near-white pixels fully transparent. The resulting data URL is
 * cached module-wide and reused on every page and in the print PDF.
 */

let cachedUrl: string | null = null;
let pending: Promise<string> | null = null;

const NEAR_WHITE_THRESHOLD = 238;

function stripWhiteBackground(src: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      // Read the source first to detect the whitespace break between the
      // circular emblem and the large wordmark baked below it.
      const source = document.createElement("canvas");
      source.width = img.naturalWidth;
      source.height = img.naturalHeight;
      const sourceCtx = source.getContext("2d", { willReadFrequently: true });
      if (!sourceCtx) {
        reject(new Error("Canvas unavailable"));
        return;
      }
      sourceCtx.drawImage(img, 0, 0);
      const sourceImage = sourceCtx.getImageData(0, 0, source.width, source.height);

      const rowHasForeground = (y: number) => {
        let foreground = 0;
        for (let x = 0; x < source.width; x += 4) {
          const i = (y * source.width + x) * 4;
          const r = sourceImage.data[i];
          const g = sourceImage.data[i + 1];
          const b = sourceImage.data[i + 2];
          if (Math.min(r, g, b) < 225 || Math.max(r, g, b) - Math.min(r, g, b) > 25) {
            foreground++;
          }
        }
        return foreground > source.width / 160;
      };

      let cropHeight = source.height;
      let blankRun = 0;
      const scanStart = Math.floor(source.height * 0.58);
      for (let y = scanStart; y < source.height; y++) {
        if (rowHasForeground(y)) {
          blankRun = 0;
        } else {
          blankRun++;
          if (blankRun >= Math.max(12, Math.floor(source.height * 0.012))) {
            cropHeight = y - blankRun + 1;
            break;
          }
        }
      }

      // Safety for tall source artwork: retain only the emblem zone.
      if (source.height > source.width * 1.08) {
        cropHeight = Math.min(cropHeight, Math.round(source.width * 0.96));
      }

      const canvas = document.createElement("canvas");
      canvas.width = source.width;
      canvas.height = cropHeight;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      if (!ctx) {
        reject(new Error("Canvas unavailable"));
        return;
      }
      ctx.drawImage(source, 0, 0, source.width, cropHeight, 0, 0, source.width, cropHeight);
      const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = image.data;

      const width = canvas.width;
      const height = canvas.height;
      const pixelCount = width * height;
      const visited = new Uint8Array(pixelCount);
      const queue = new Int32Array(pixelCount);
      let head = 0;
      let tail = 0;

      const isBackgroundWhite = (pixel: number) => {
        const i = pixel * 4;
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        return (
          r >= NEAR_WHITE_THRESHOLD &&
          g >= NEAR_WHITE_THRESHOLD &&
          b >= NEAR_WHITE_THRESHOLD &&
          Math.max(r, g, b) - Math.min(r, g, b) <= 18
        );
      };

      const add = (pixel: number) => {
        if (pixel < 0 || pixel >= pixelCount || visited[pixel] || !isBackgroundWhite(pixel)) return;
        visited[pixel] = 1;
        queue[tail++] = pixel;
      };

      // Seed only the outer boundary. This removes the connected white canvas,
      // while preserving white letters and ornaments enclosed inside the emblem.
      for (let x = 0; x < width; x++) {
        add(x);
        add((height - 1) * width + x);
      }
      for (let y = 0; y < height; y++) {
        add(y * width);
        add(y * width + width - 1);
      }

      while (head < tail) {
        const pixel = queue[head++];
        const x = pixel % width;
        const y = Math.floor(pixel / width);
        data[pixel * 4 + 3] = 0;
        if (x > 0) add(pixel - 1);
        if (x + 1 < width) add(pixel + 1);
        if (y > 0) add(pixel - width);
        if (y + 1 < height) add(pixel + width);
      }

      ctx.putImageData(image, 0, 0);
      resolve(canvas.toDataURL("image/png"));
    };
    img.onerror = () => reject(new Error("Logo load failed"));
    img.src = src;
  });
}

function getTransparentLogo(): Promise<string> {
  if (cachedUrl) return Promise.resolve(cachedUrl);
  if (!pending) {
    pending = stripWhiteBackground("/logo.png")
      .then((url) => {
        cachedUrl = url;
        return url;
      })
      .catch(() => "/logo.png");
  }
  return pending;
}

export default function Logo({
  className = "",
  alt = "U K Jha Institute of Vedic Astrology",
}: {
  className?: string;
  alt?: string;
}) {
  const [src, setSrc] = useState<string>(cachedUrl ?? "");

  useEffect(() => {
    let alive = true;
    getTransparentLogo().then((url) => {
      if (alive) setSrc(url);
    });
    return () => {
      alive = false;
    };
  }, []);

  return (
    <span className={`app-logo-box inline-flex shrink-0 items-center justify-center overflow-hidden ${className}`}>
      <img
        src={src || "/logo.png"}
        alt={alt}
        className="block h-full w-full object-contain object-center"
        style={{ mixBlendMode: "multiply" }}
      />
    </span>
  );
}
