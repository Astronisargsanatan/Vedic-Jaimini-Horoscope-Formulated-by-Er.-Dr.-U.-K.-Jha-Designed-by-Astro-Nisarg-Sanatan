import { PLANETS, type ChartSigns, type PlanetKey } from "../lib/astro";
import type { ArudhaLabel } from "../lib/arudha";

/**
 * North Indian (diamond) chart.
 * House 1 is the top-center diamond; houses run anti-clockwise.
 */
const HOUSE_POS: { x: number; y: number }[] = [
  { x: 150, y: 62 },
  { x: 75, y: 32 },
  { x: 32, y: 75 },
  { x: 62, y: 150 },
  { x: 32, y: 225 },
  { x: 75, y: 268 },
  { x: 150, y: 238 },
  { x: 225, y: 268 },
  { x: 268, y: 225 },
  { x: 238, y: 150 },
  { x: 268, y: 75 },
  { x: 225, y: 32 },
];

const SIGN_POS: { x: number; y: number }[] = [
  { x: 150, y: 30 },
  { x: 40, y: 14 },
  { x: 14, y: 40 },
  { x: 30, y: 150 },
  { x: 14, y: 260 },
  { x: 40, y: 288 },
  { x: 150, y: 274 },
  { x: 260, y: 288 },
  { x: 286, y: 260 },
  { x: 272, y: 150 },
  { x: 286, y: 40 },
  { x: 260, y: 14 },
];

export default function NorthChart({
  signs,
  title,
  subtitle,
  accent = "#7c2d12",
  arudhaByHouse,
  showPlanets = true,
}: {
  signs: ChartSigns;
  title?: string;
  subtitle?: string;
  accent?: string;
  /** Optional Arudha labels grouped by house number 1..12 */
  arudhaByHouse?: Record<number, ArudhaLabel[]>;
  showPlanets?: boolean;
}) {
  const lagnaSign = signs.Lagna;

  const byHouse: Record<number, PlanetKey[]> = {};
  for (let h = 1; h <= 12; h++) byHouse[h] = [];
  if (showPlanets) {
    for (const p of PLANETS) {
      if (p.key === "Lagna") continue;
      const house = ((signs[p.key] - lagnaSign + 12) % 12) + 1;
      byHouse[house].push(p.key);
    }
  }

  const shortOf = (k: PlanetKey) => PLANETS.find((p) => p.key === k)!.short;

  return (
    <div className="w-full">
      {title && (
        <div className="mb-2 text-center">
          <div className="font-serif text-base font-bold" style={{ color: accent }}>
            {title}
          </div>
          {subtitle && <div className="text-xs text-stone-500">{subtitle}</div>}
        </div>
      )}
      <svg viewBox="0 0 300 300" className="mx-auto w-full max-w-[340px]">
        <rect x="0" y="0" width="300" height="300" fill="#fffdf8" stroke={accent} strokeWidth="2" />
        <line x1="0" y1="0" x2="300" y2="300" stroke={accent} strokeWidth="1.2" />
        <line x1="300" y1="0" x2="0" y2="300" stroke={accent} strokeWidth="1.2" />
        <polygon
          points="150,0 300,150 150,300 0,150"
          fill="none"
          stroke={accent}
          strokeWidth="1.2"
        />

        {HOUSE_POS.map((pos, i) => {
          const house = i + 1;
          const sign = ((lagnaSign - 1 + i) % 12) + 1;
          const planets = byHouse[house];
          const arudhas = arudhaByHouse?.[house] ?? [];
          const isLagna = house === 1;
          const planetOffset = isLagna || arudhas.length > 0 ? 10 : -((planets.length - 1) * 5);

          return (
            <g key={house}>
              <text
                x={SIGN_POS[i].x}
                y={SIGN_POS[i].y}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize="11"
                fontWeight="700"
                fill="#b45309"
              >
                {sign}
              </text>

              {isLagna && (
                <text
                  x={pos.x}
                  y={pos.y - (arudhas.length > 0 ? 18 : 14)}
                  textAnchor="middle"
                  fontSize="10"
                  fontWeight="700"
                  fill="#166534"
                >
                  La
                </text>
              )}

              {/* Arudha labels — teal, bold */}
              {arudhas.map((label, j) => (
                <text
                  key={label}
                  x={pos.x}
                  y={pos.y + j * 11 - (arudhas.length > 1 ? 4 : 0) + (isLagna ? 0 : -6)}
                  textAnchor="middle"
                  fontSize="10"
                  fontWeight="800"
                  fill="#0f766e"
                >
                  {label}
                </text>
              ))}

              {/* Planets */}
              {showPlanets &&
                planets.map((k, j) => (
                  <text
                    key={k}
                    x={pos.x}
                    y={
                      pos.y +
                      arudhas.length * 11 +
                      j * 11 +
                      planetOffset
                    }
                    textAnchor="middle"
                    fontSize="10"
                    fontWeight="600"
                    fill="#1e3a8a"
                  >
                    {shortOf(k)}
                  </text>
                ))}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
