import { useMemo, useRef, useState } from "react";
import { ChevronDown, MapPin, Search, X } from "lucide-react";
import { searchPlaces, type Place } from "../lib/gazetteer";

const CATEGORY_STYLES: Record<string, string> = {
  "Gujarat District": "bg-amber-100 text-amber-900",
  "Gujarat Taluka": "bg-orange-100 text-orange-900",
  "India Metro": "bg-indigo-100 text-indigo-900",
  "India City": "bg-blue-100 text-blue-900",
  "India District": "bg-emerald-100 text-emerald-900",
  "Foreign City": "bg-purple-100 text-purple-900",
};

export default function PlaceSelect({
  value,
  onSelect,
}: {
  value: { placeId?: string; placeLabel?: string } | undefined;
  onSelect: (place: Place) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const boxRef = useRef<HTMLDivElement>(null);

  const results = useMemo(() => searchPlaces(query, 80), [query]);

  const selectedLabel = value?.placeLabel
    ? value.placeLabel.split(" (")[0]
    : "";

  const highlight = (index: number) => {
    if (typeof document === "undefined") return;
    const el = document.getElementById(`place-opt-${index}`);
    el?.scrollIntoView({ block: "nearest" });
  };

  return (
    <div ref={boxRef} className="relative">
      <label className="text-[11px] font-bold uppercase tracking-[0.16em] text-amber-700">
        4. Place of Birth (select from list)
      </label>

      <button
        type="button"
        onClick={() => {
          setOpen((v) => !v);
          setQuery("");
        }}
        className={`mt-1.5 flex w-full items-center gap-2 rounded-xl border bg-[#fffdf8] px-3 py-3 text-left text-sm transition ${
          open
            ? "border-amber-500 ring-4 ring-amber-500/15"
            : "border-amber-800/20 hover:border-amber-400"
        }`}
      >
        <MapPin className="h-4 w-4 shrink-0 text-amber-700" />
        <span className={`min-w-0 flex-1 truncate ${selectedLabel ? "text-stone-900" : "text-stone-400"}`}>
          {selectedLabel || "Select city / town / taluka / district / country"}
        </span>
        <ChevronDown
          className={`h-4 w-4 shrink-0 text-stone-400 transition ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open && (
        <div className="absolute left-0 right-0 top-full z-50 mt-1.5 overflow-hidden rounded-2xl border border-amber-800/25 bg-white shadow-2xl">
          <div className="flex items-center gap-2 border-b border-stone-200 bg-amber-50 px-3 py-2">
            <Search className="h-4 w-4 shrink-0 text-amber-700" />
            <input
              autoFocus
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                highlight(0);
              }}
              onKeyDown={(e) => {
                if (e.key === "Escape") setOpen(false);
                if (e.key === "Enter" && results[0]) {
                  onSelect(results[0]);
                  setOpen(false);
                }
              }}
              placeholder="Search: Surat, Bardoli, Kutch, Mumbai, Dubai..."
              className="w-full bg-transparent text-sm text-stone-900 outline-none placeholder:text-stone-400"
            />
            <button
              type="button"
              onClick={() => setQuery("")}
              className="text-stone-400 hover:text-stone-700"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="max-h-72 overflow-y-auto">
            {results.length === 0 ? (
              <div className="px-4 py-6 text-center text-sm text-stone-500">
                No place matched. Try a district name like “Kutch” or “Mehsana”.
              </div>
            ) : (
              results.map((place, index) => (
                <button
                  key={place.id}
                  id={`place-opt-${index}`}
                  type="button"
                  onMouseEnter={() => highlight(index)}
                  onClick={() => {
                    onSelect(place);
                    setOpen(false);
                  }}
                  className={`flex w-full items-center justify-between gap-3 px-3 py-2 text-left transition hover:bg-amber-50 ${
                    value?.placeId === place.id ? "bg-amber-100/70" : ""
                  }`}
                >
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold text-stone-900">
                      {place.name}
                    </span>
                    <span className="block truncate text-[11px] text-stone-500">
                      {place.district} · {place.state} · {place.country}
                    </span>
                  </span>
                  <span className="flex shrink-0 flex-col items-end gap-1">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide ${
                        CATEGORY_STYLES[place.category] ?? "bg-stone-100 text-stone-700"
                      }`}
                    >
                      {place.category}
                    </span>
                    <span className="font-mono text-[10px] text-stone-400">
                      {place.lat.toFixed(2)}, {place.lon.toFixed(2)}
                    </span>
                  </span>
                </button>
              ))
            )}
          </div>

          <div className="border-t border-stone-200 bg-stone-50 px-3 py-2 text-[10px] text-stone-500">
            Showing {results.length} of the bundled gazetteer. Type to filter districts, talukas,
            towns and countries. Each entry carries fixed latitude, longitude and timezone.
          </div>
        </div>
      )}
    </div>
  );
}
