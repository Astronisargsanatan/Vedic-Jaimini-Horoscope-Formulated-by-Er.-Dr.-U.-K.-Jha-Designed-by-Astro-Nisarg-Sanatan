import { useMemo, useState } from "react";
import {
  computeAarshaVimshottari,
  type AarshaCycle,
} from "../lib/aarshaVimshottari";
import {
  LEVEL_NAMES,
  LORD_HINDI,
  bhuktaBhogya,
  formatDate,
  formatDuration,
  type DashaPeriod,
} from "../lib/vimshottari";
import { formatDMS } from "../lib/astro";
import { useChart } from "../state/ChartContext";
import DashaPraveshModal from "./DashaPraveshModal";
import type { DashaPraveshRequest, PraveshAnchor } from "../lib/dashaPravesh";

function birthInstant(native?: { date?: string; time?: string; birthUtc?: string }): Date {
  if (native?.birthUtc) {
    const exact = new Date(native.birthUtc);
    if (!Number.isNaN(exact.getTime())) return exact;
  }
  const d = (native?.date ?? "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const t = (native?.time ?? "").match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  if (!d) return new Date();
  return new Date(
    Date.UTC(
      Number(d[3]),
      Number(d[2]) - 1,
      Number(d[1]),
      t ? Number(t[1]) : 12,
      t ? Number(t[2]) : 0,
      t ? Number(t[3] ?? 0) : 0,
    ) - 330 * 60000,
  );
}

function PeriodRow({
  period,
  now,
  depth,
  activePath,
  path,
  onOpenPravesh,
}: {
  period: DashaPeriod;
  now: Date;
  depth: number;
  activePath: DashaPeriod[];
  path: PraveshAnchor[];
  onOpenPravesh: (period: DashaPeriod, path: PraveshAnchor[]) => void;
}) {
  const active = now >= period.start && now < period.end;
  const [open, setOpen] = useState(active && depth < 2);
  const hasChildren = Boolean(period.children?.length);
  const balance = active ? bhuktaBhogya(period, now) : null;

  return (
    <>
      <tr className={`border-b border-stone-200/70 ${active ? "bg-emerald-50" : "bg-white"}`}>
        <td className="py-2 pr-2" style={{ paddingLeft: `${10 + depth * 18}px` }}>
          <button
            type="button"
            onClick={() => hasChildren && setOpen((value) => !value)}
            className="flex items-center gap-2 text-left"
          >
            <span className="w-3 font-mono text-xs text-stone-400">
              {hasChildren ? (open ? "▾" : "▸") : ""}
            </span>
            <span className="font-serif text-sm font-black text-[#7c2d12]">
              {LORD_HINDI[period.lord]} · {period.lord}
            </span>
            {active && (
              <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-[9px] font-black text-white">
                ACTIVE
              </span>
            )}
          </button>
        </td>
        <td className="py-2 pr-2 text-[10px] text-stone-500">{LEVEL_NAMES[period.level]}</td>
        <td className="py-2 pr-2 font-mono text-xs text-stone-600">{formatDate(period.start)}</td>
        <td className="py-2 pr-2 font-mono text-xs text-stone-600">{formatDate(period.end)}</td>
        <td className="py-2 pr-2 text-xs text-stone-600">{formatDuration(period.durationMs)}</td>
        <td className="py-2 pr-2 text-xs text-stone-500">{balance?.bhuktaLabel ?? "—"}</td>
        <td className="py-2 pr-2 text-xs text-stone-500">{balance?.bhogyaLabel ?? "—"}</td>
        <td className="py-2 pr-2">
          {period.level <= 3 && (
            <button
              type="button"
              onClick={() => onOpenPravesh(period, path)}
              className="whitespace-nowrap rounded-lg border border-indigo-700/20 bg-indigo-50 px-2 py-1 text-[9px] font-bold text-indigo-800 hover:bg-indigo-100"
            >
              View Dasha Pravesh Chart
            </button>
          )}
        </td>
      </tr>
      {open &&
        period.children?.map((child, index) => (
          <PeriodRow
            key={`${child.lord}-${child.level}-${index}`}
            period={child}
            now={now}
            depth={depth + 1}
            activePath={activePath}
            path={[
              ...path,
              {
                level:
                  child.level === 2
                    ? "Antardasha"
                    : child.level === 3
                      ? "Pratyantar Dasha"
                      : "Bhukti",
                name: child.lord,
                start: child.start,
              },
            ]}
            onOpenPravesh={onOpenPravesh}
          />
        ))}
    </>
  );
}

const CYCLE_ROWS: { title: string; stars: string; lord: string }[] = [
  { title: "1", stars: "Ardra · Swati · Shatabhisha", lord: "Surya" },
  { title: "2", stars: "Punarvasu · Vishakha · Purva Bhadrapada", lord: "Chandra" },
  { title: "3", stars: "Pushya · Anuradha · Uttara Bhadrapada", lord: "Mangal" },
  { title: "4", stars: "Ashlesha · Jyeshtha · Revati", lord: "Rahu" },
  { title: "5", stars: "Ashwini · Magha · Mula", lord: "Guru" },
  { title: "6", stars: "Bharani · Purva Phalguni · Purva Ashadha", lord: "Shani" },
  { title: "7", stars: "Krittika · Uttara Phalguni · Uttara Ashadha", lord: "Budh" },
  { title: "8", stars: "Rohini · Hasta · Shravana", lord: "Ketu" },
  { title: "9", stars: "Mrigashira · Chitra · Dhanishta", lord: "Shukra" },
];

function CycleBadge({ cycle }: { cycle: AarshaCycle }) {
  return (
    <span
      className={`rounded-full border px-3 py-1 text-xs font-black ${
        cycle === "Ardradi"
          ? "border-indigo-600/25 bg-indigo-100 text-indigo-900"
          : "border-amber-600/25 bg-amber-100 text-amber-900"
      }`}
    >
      {cycle === "Ardradi" ? "आर्द्रादि चक्र" : "कृतिकादि चक्र"}
    </span>
  );
}

export default function AarshaVimshottariSection() {
  const { chart, native } = useChart();
  const [pravesh, setPravesh] = useState<DashaPraveshRequest | null>(null);
  const now = useMemo(() => new Date(), []);
  const birth = useMemo(() => birthInstant(native ?? undefined), [native]);
  const result = useMemo(
    () => computeAarshaVimshottari(chart, birth, now),
    [birth, chart, now],
  );
  const firstEnd = new Date(birth.getTime() + result.bhogyaAtBirthMs);

  return (
    <section className="space-y-6">
      <header className="rounded-3xl border border-indigo-800/20 bg-gradient-to-br from-indigo-50 via-white to-amber-50 p-6 shadow-[0_14px_42px_-28px_rgba(49,46,129,0.45)] sm:p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-indigo-700">
          Rishi Pranit · Hora + Paksha Selected Cycle
        </div>
        <h2 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-4xl">
          ऋषि प्रणीत आर्ष विंशोत्तरी दशा
        </h2>
        <p className="mt-3 max-w-4xl text-sm leading-relaxed text-stone-600">
          Hora और Paksha से कृतिकादि/आर्द्रादि चक्र चुना जाता है। Lagna Nakshatra से Moon
          Nakshatra तक inclusive count, Moon से वही count दोबारा, फिर लक्षित नक्षत्र का स्वामी
          triggering planet बनता है।
        </p>

        {!native?.date && (
          <div className="mt-4 rounded-xl border-2 border-amber-500 bg-amber-50 px-4 py-3 text-xs text-amber-900">
            सही तिथियों के लिए पहले Home page पर जन्म विवरण calculate करें।
          </div>
        )}
      </header>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Info label="Birth Hora" value={result.hora} />
        <Info label="Birth Paksha" value={result.paksha} />
        <Info
          label="Applicable Cycle"
          value={result.cycle === "Ardradi" ? "आर्द्रादि" : "कृतिकादि"}
          tone="indigo"
        />
        <Info
          label="First Dasha Lord"
          value={`${LORD_HINDI[result.firstDashaLord]} · ${result.firstDashaLord}`}
          tone="emerald"
        />
      </div>

      <section className="rounded-3xl border border-indigo-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="font-serif text-xl font-black text-[#7c2d12]">Cycle Selection</h3>
            <p className="mt-1 text-xs text-stone-500">
              Surya Hora + Shukla अथवा Chandra Hora + Krishna = Ardradi; अन्य संयोजन = Krittikadi.
            </p>
          </div>
          <CycleBadge cycle={result.cycle} />
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <div
            className={`rounded-2xl border p-4 ${
              result.cycle === "Ardradi"
                ? "border-indigo-500 bg-indigo-50 ring-2 ring-indigo-500/20"
                : "border-stone-200 bg-stone-50"
            }`}
          >
            <div className="font-serif text-base font-black text-indigo-900">आर्द्रादि चक्र</div>
            <p className="mt-1 text-xs text-stone-600">
              Surya Hora + Shukla Paksha OR Chandra Hora + Krishna Paksha.
            </p>
          </div>
          <div
            className={`rounded-2xl border p-4 ${
              result.cycle === "Krittikadi"
                ? "border-amber-500 bg-amber-50 ring-2 ring-amber-500/20"
                : "border-stone-200 bg-stone-50"
            }`}
          >
            <div className="font-serif text-base font-black text-amber-900">कृतिकादि चक्र</div>
            <p className="mt-1 text-xs text-stone-600">
              Surya Hora + Krishna Paksha OR Chandra Hora + Shukla Paksha.
            </p>
          </div>
        </div>

        {result.cycle === "Ardradi" && (
          <div className="mt-4 overflow-x-auto rounded-xl border border-indigo-800/15">
            <table className="w-full min-w-[620px] text-sm">
              <thead>
                <tr className="bg-indigo-50 text-left text-[10px] font-bold uppercase tracking-wide text-indigo-900">
                  <th className="px-3 py-2">#</th>
                  <th className="px-3 py-2">Nakshatra Group</th>
                  <th className="px-3 py-2">Aarsha Lord</th>
                </tr>
              </thead>
              <tbody>
                {CYCLE_ROWS.map((row) => (
                  <tr key={row.title} className="border-t border-stone-200/70">
                    <td className="px-3 py-2 font-mono text-stone-400">{row.title}</td>
                    <td className="px-3 py-2 text-stone-700">{row.stars}</td>
                    <td className="px-3 py-2 font-serif font-bold text-[#7c2d12]">{row.lord}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
        <h3 className="font-serif text-xl font-black text-[#7c2d12]">
          Triggering Planet Calculation
        </h3>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <Step
            number="1"
            title="Lagna → Moon Nakshatra Count"
            body={`${result.lagnaNakshatra.name} (Lagna) से ${result.moonNakshatra.name} (Moon) तक inclusive count = ${result.inclusiveCount}.`}
          />
          <Step
            number="2"
            title="Moon से वही Count"
            body={`${result.moonNakshatra.name} से ${result.inclusiveCount} inclusive count करने पर target = ${result.targetNakshatra.name}.`}
          />
          <Step
            number="3"
            title="Target Owner = Trigger"
            body={`${result.cycle} cycle में ${result.targetNakshatra.name} का स्वामी ${result.triggeringPlanet} है — यही triggering planet.`}
          />
        </div>

        <div className="mt-4 rounded-2xl border-2 border-emerald-500/30 bg-emerald-50 p-4 text-sm leading-relaxed text-emerald-950">
          Triggering planet <strong>{result.triggeringPlanet}</strong> natal chart में{" "}
          <strong>{result.triggeringPlanetNakshatra.name}</strong> नक्षत्र, पद{" "}
          {result.triggeringPlanetNakshatra.pada} में है ({formatDMS(chart[result.triggeringPlanet as keyof typeof chart])}).{" "}
          {result.cycle} cycle में इस नक्षत्र का स्वामी{" "}
          <strong>{result.firstDashaLord}</strong> है; इसलिए जन्म की पहली दशा इसी से शुरू होगी।
          <span className="mt-2 block border-t border-emerald-700/15 pt-2 text-xs font-semibold text-emerald-800">
            महत्वपूर्ण: Triggering Planet की degree केवल First Mahadasha Lord पहचानने तक उपयोग हुई;
            balance calculation में इसकी degree उपयोग नहीं होगी।
          </span>
        </div>
      </section>

      <section className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
        <h3 className="font-serif text-xl font-black text-[#7c2d12]">
          Bhukta–Bhogya & First Dasha End
        </h3>
        <div className="mt-3 rounded-2xl border-2 border-indigo-500/30 bg-indigo-50 p-4 text-sm leading-relaxed text-indigo-950">
          Balance source = First Mahadasha Lord <strong>{result.firstDashaLord}</strong> की अपनी D1
          longitude: <strong className="font-mono">{formatDMS(chart[result.firstDashaLord])}</strong>।
          यह ग्रह <strong>{result.firstDashaLordNakshatra.name}</strong> नक्षत्र, पद{" "}
          {result.firstDashaLordNakshatra.pada} में है। Triggering Planet{" "}
          {result.triggeringPlanet} की longitude इस चरण में निषिद्ध है।
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Info
            label="Dasha Lord Nakshatra"
            value={`${result.firstDashaLordNakshatra.name} · Pada ${result.firstDashaLordNakshatra.pada}`}
          />
          <Info
            label="Traversed Arc · Bhukta Source"
            value={`${result.traversedArcMinutes.toFixed(6)}′ / 800′`}
            tone="rose"
          />
          <Info
            label="Remaining Arc · Bhogya Source"
            value={`${result.remainingArcMinutes.toFixed(6)}′ / 800′`}
            tone="emerald"
          />
          <Info label="First Dasha Full Tenure" value={`${result.firstDashaYears} Years`} tone="indigo" />
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <Info label="Bhukta at Birth" value={formatDuration(result.bhuktaAtBirthMs)} tone="rose" />
          <Info label="Bhogya at Birth" value={formatDuration(result.bhogyaAtBirthMs)} tone="emerald" />
        </div>

        <div className="mt-4 space-y-2 rounded-xl border border-indigo-700/15 bg-indigo-50 p-4 text-xs leading-relaxed text-indigo-950">
          <div>
            <strong>Traversed Arc:</strong> {result.firstDashaLordNakshatra.name} में{" "}
            {result.firstDashaLord} की चली हुई longitude ={" "}
            <span className="font-mono font-bold">{result.traversedArcMinutes.toFixed(6)}′</span>।
          </div>
          <div>
            <strong>Remaining Arc:</strong> 800′ − {result.traversedArcMinutes.toFixed(6)}′ ={" "}
            <span className="font-mono font-bold">{result.remainingArcMinutes.toFixed(6)}′</span>।
          </div>
          <div>
            <strong>Bhukta:</strong> ({result.traversedArcMinutes.toFixed(6)} ÷ 800) ×{" "}
            {result.firstDashaYears} years = {formatDuration(result.bhuktaAtBirthMs)}।
          </div>
          <div>
            <strong>Bhogya:</strong> ({result.remainingArcMinutes.toFixed(6)} ÷ 800) ×{" "}
            {result.firstDashaYears} years = {formatDuration(result.bhogyaAtBirthMs)}।
          </div>
          <div className="border-t border-indigo-700/15 pt-2">
          <strong>DOB + केवल Bhogya:</strong> {formatDate(birth)} +{" "}
          {formatDuration(result.bhogyaAtBirthMs)} = <strong>{formatDate(firstEnd)}</strong> ({LORD_HINDI[result.firstDashaLord]} Mahadasha end).
          </div>
        </div>
      </section>

      {result.activePath.length > 0 && (
        <section className="rounded-3xl border-2 border-emerald-500/40 bg-emerald-50 p-5 sm:p-6">
          <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-emerald-700">
            Active Aarsha Vimshottari
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {result.activePath.map((period) => {
              const balance = bhuktaBhogya(period, now);
              return (
                <div key={`${period.level}-${period.lord}`} className="min-w-36 flex-1 rounded-xl bg-white p-3 shadow-sm">
                  <div className="text-[9px] font-bold uppercase text-emerald-700">
                    {LEVEL_NAMES[period.level]}
                  </div>
                  <div className="font-serif text-lg font-black text-[#7c2d12]">
                    {LORD_HINDI[period.lord]}
                  </div>
                  <div className="mt-1 text-[9px] text-stone-500">
                    भुक्त {balance.bhuktaLabel} · भोग्य {balance.bhogyaLabel}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-sm">
        <div className="border-b border-amber-800/15 bg-amber-50 px-5 py-4">
          <h3 className="font-serif text-xl font-black text-[#7c2d12]">
            Full Aarsha Dasha Table · Maha → Pran
          </h3>
          <p className="text-xs text-stone-500">▸ से उपदशाएँ खोलें; active periods हरे हैं।</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[780px] text-sm">
            <thead>
              <tr className="border-b border-amber-800/20 bg-amber-50 text-left text-[10px] uppercase tracking-wide text-amber-900">
                <th className="py-2.5 pr-2">Dasha Lord</th>
                <th className="py-2.5 pr-2">Level</th>
                <th className="py-2.5 pr-2">Start</th>
                <th className="py-2.5 pr-2">End</th>
                <th className="py-2.5 pr-2">Duration</th>
                <th className="py-2.5 pr-2">Bhukta</th>
                <th className="py-2.5 pr-2">Bhogya</th>
                <th className="py-2.5 pr-2">Pravesh Chart</th>
              </tr>
            </thead>
            <tbody>
              {result.mahadashas.map((period, index) => (
                <PeriodRow
                  key={`${period.lord}-${index}`}
                  period={period}
                  now={now}
                  depth={0}
                  activePath={result.activePath}
                  path={[{ level: "Mahadasha", name: period.lord, start: period.start }]}
                  onOpenPravesh={(selected, path) =>
                    setPravesh({
                      system: "Rishi Pranit Aarsha Vimshottari Dasha",
                      selected: {
                        level:
                          selected.level === 1
                            ? "Mahadasha"
                            : selected.level === 2
                              ? "Antardasha"
                              : "Pratyantar Dasha",
                        name: selected.lord,
                        start: selected.start,
                      },
                      path,
                    })
                  }
                />
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <DashaPraveshModal request={pravesh} native={native} onClose={() => setPravesh(null)} />
    </section>
  );
}

function Info({
  label,
  value,
  tone = "amber",
}: {
  label: string;
  value: string;
  tone?: "amber" | "indigo" | "emerald" | "rose";
}) {
  const classes = {
    amber: "border-amber-800/15 bg-amber-50 text-amber-900",
    indigo: "border-indigo-700/20 bg-indigo-50 text-indigo-900",
    emerald: "border-emerald-700/20 bg-emerald-50 text-emerald-900",
    rose: "border-rose-700/20 bg-rose-50 text-rose-900",
  };
  return (
    <div className={`rounded-2xl border p-4 ${classes[tone]}`}>
      <div className="text-[9px] font-bold uppercase tracking-wider opacity-75">{label}</div>
      <div className="mt-1 font-serif text-base font-black sm:text-lg">{value}</div>
    </div>
  );
}

function Step({ number, title, body }: { number: string; title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-stone-200 bg-[#fdfaf4] p-4">
      <div className="flex items-center gap-2">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#7c2d12] font-mono text-xs font-black text-white">
          {number}
        </span>
        <h4 className="font-serif text-sm font-black text-stone-900">{title}</h4>
      </div>
      <p className="mt-2 text-xs leading-relaxed text-stone-600">{body}</p>
    </div>
  );
}
