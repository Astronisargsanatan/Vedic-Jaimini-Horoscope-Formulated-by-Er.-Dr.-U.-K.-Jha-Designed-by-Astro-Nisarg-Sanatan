import Logo from "./Logo";
import NorthChart from "./NorthChart";
import { computeAshtakavarga } from "../lib/ashtakavarga";
import { computeVarshPravesh, formatVarshDate } from "../lib/varshPravesh";
import {
  PLANETS,
  RASHI_LORDS,
  computeVarga,
  houseOf,
  rashiName,
  type Chart,
} from "../lib/astro";
import type { NativeInfo } from "../state/ChartContext";

const HOUSE_META: Record<number, string> = {
  1: "शरीर, व्यक्तित्व, स्वास्थ्य और वर्ष की मूल दिशा",
  2: "धन, वाणी, कुटुम्ब और संचय",
  3: "साहस, संचार, परिश्रम और लघु यात्राएँ",
  4: "गृह, माता, सम्पत्ति, शिक्षा और मानसिक सुख",
  5: "बुद्धि, सन्तान, सृजन और पूर्व-पुण्य",
  6: "रोग, ऋण, सेवा, प्रतियोगिता और विरोध",
  7: "विवाह, साझेदारी, समझौते और सार्वजनिक व्यवहार",
  8: "परिवर्तन, आयु, रहस्य, उत्तराधिकार और आकस्मिकता",
  9: "भाग्य, धर्म, गुरु, पिता और उच्च अध्ययन",
  10: "कर्म, व्यवसाय, पद, प्रतिष्ठा और उत्तरदायित्व",
  11: "लाभ, मित्र-वृत्त, उपलब्धि और इच्छापूर्ति",
  12: "व्यय, विदेश, एकान्त, निद्रा और आध्यात्मिक निवृत्ति",
};

function currentReturn(natal: Chart, native: NativeInfo) {
  const now = new Date();
  const thisYear = computeVarshPravesh(natal, native, now.getUTCFullYear());
  return thisYear.praveshInstant <= now
    ? thisYear
    : computeVarshPravesh(natal, native, now.getUTCFullYear() - 1);
}

function Head() {
  return (
    <div className="pdf-head">
      <Logo className="pdf-logo" />
      <div>
        <div className="pdf-inst">U K Jha Institute of Vedic Astrology</div>
        <div className="pdf-by">President · Er. Dr. U K Jha</div>
        <div className="pdf-sub">Vice-President · Astro Nisarg Sanatan · Gujarat Chapter — (+91) 9998074088</div>
      </div>
    </div>
  );
}

function Footer(_props: { page: number; total: number }) {
  return (
    <div className="pdf-foot">
      <span>U K Jha Institute of Vedic Astrology ; Er. Dr. U K Jha & Astro Nisarg Sanatan — (+91) 9998074088</span>
    </div>
  );
}

export default function VarshPraveshPdfSections({
  natal,
  native,
  startPage,
  totalPages,
}: {
  natal: Chart;
  native: NativeInfo | null;
  startPage: number;
  totalPages: number;
}) {
  if (!native || native.lat == null || native.lon == null) {
    return (
      <>
        {[0, 1, 2].map((offset) => (
          <section className="pdf-page prediction-page" key={offset}>
            <Head />
            <h2 className="pdf-title">Varsh Pravesh · Data Required</h2>
            <p className="pdf-prediction-box">Home पर पूर्ण जन्म विवरण और birth coordinates के बिना वर्ष-प्रवेश गणना उपलब्ध नहीं है।</p>
            <Footer page={startPage + offset} total={totalPages} />
          </section>
        ))}
      </>
    );
  }

  const result = currentReturn(natal, native);
  const signs = computeVarga(result.chart, "D1");
  const annualAv = computeAshtakavarga(result.chart);

  return (
    <>
      <section className="pdf-page prediction-page">
        <Head />
        <h2 className="pdf-title">Varsh Pravesh · Current Age Solar Return</h2>
        <table className="pdf-meta">
          <tbody>
            <tr><th>Target Year</th><td>{result.targetYear}</td><th>Completed / Running Age</th><td>{result.completedAge} / {result.runningYear}</td></tr>
            <tr><th>Pravesh Time</th><td>{formatVarshDate(result.praveshInstant, native.tz)}</td><th>Fixed Birth Place</th><td>{native.place}</td></tr>
            <tr><th>Natal Sun</th><td className="mono">{result.natalSunSidereal.toFixed(8)}°</td><th>Return Sun</th><td className="mono">{result.returnSunSidereal.toFixed(8)}°</td></tr>
            <tr><th>Difference</th><td>{result.differenceArcSeconds.toFixed(4)} arcsec</td><th>Varsh Lagna</th><td>{result.chart.Lagna.sign}. {rashiName(result.chart.Lagna.sign)}</td></tr>
          </tbody>
        </table>
        <div className="pdf-chart-wrap">
          <NorthChart signs={signs} title={`Varsh Pravesh D1 · ${result.targetYear}`} subtitle={`Running Year ${result.runningYear}`} accent="#7c2d12" />
        </div>
        <h3 className="pdf-h3">Varsh Pravesh Planetary Positions</h3>
        <table className="pdf-table pdf-dense">
          <thead><tr><th>Graha</th><th>Varsh Rashi</th><th>Longitude</th><th>House</th><th>Motion</th><th>Natal Rashi</th><th>Comparison</th></tr></thead>
          <tbody>
            {result.planets.map((planet) => (
              <tr key={planet.key}>
                <td className="font-semibold">{planet.key}</td><td>{planet.sign}. {planet.rashi}</td><td className="mono">{planet.longitude}</td>
                <td className="center">H{planet.house}</td><td className="center">{planet.motion}</td><td>{planet.natalSign}. {rashiName(planet.natalSign)}</td>
                <td>{planet.sign === planet.natalSign ? "राशि पुनरावृत्ति" : `${houseOf(planet.sign, planet.natalSign)}वाँ from natal`}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <Footer page={startPage} total={totalPages} />
      </section>

      {[1, 7].map((firstHouse, pageIndex) => (
        <section className="pdf-page prediction-page" key={`varsh-phala-${firstHouse}`}>
          <Head />
          <h2 className="pdf-title">
            Varsh Pravesh · विस्तृत वार्षिक फलादेश · भाव {firstHouse}–{firstHouse + 5}
          </h2>
          <p className="pdf-note">
            केवल वर्ष-प्रवेश D1 के भाव, राशीश, ग्रह-स्थिति, annual Ashtakavarga और natal comparison पर आधारित।
          </p>
          {Array.from({ length: 6 }, (_, index) => {
          const house = firstHouse + index;
          const actualSign = ((result.chart.Lagna.sign - 1 + house - 1) % 12) + 1;
          const lord = RASHI_LORDS[actualSign];
          const lordHouse = houseOf(result.chart[lord].sign, result.chart.Lagna.sign);
          const occupants = PLANETS.filter(
            (planet) => planet.key !== "Lagna" && result.chart[planet.key].sign === actualSign,
          ).map((planet) => planet.key);
          const bindus = annualAv.sarva[actualSign - 1];
          const strength = bindus >= 32 ? "उच्च" : bindus >= 28 ? "मध्यम" : "परिश्रम-साध्य";
          return (
            <div className="pdf-bhava-block" key={`varsh-house-${house}`}>
              <div className="pdf-bhava-head">
                <strong>H{house} · {actualSign}. {rashiName(actualSign)}</strong>
                <span>Annual SAV {bindus} · {strength}</span>
              </div>
              <div className="pdf-bhava-facts">
                राशीश {lord} वर्ष-कुंडली में H{lordHouse} · स्थित ग्रह {occupants.length ? occupants.join(", ") : "कोई नहीं"} · natal chart से वर्ष लग्न {houseOf(result.chart.Lagna.sign, natal.Lagna.sign)}वाँ
              </div>
              <p>
                इस वर्ष {HOUSE_META[house]} के विषय {strength} स्तर पर सक्रिय हैं। राशीश {lord} का H{lordHouse} में होना परिणाम को {lordHouse === 1 || lordHouse === 4 || lordHouse === 7 || lordHouse === 10 ? "प्रत्यक्ष और क्रियाशील" : lordHouse === 5 || lordHouse === 9 ? "सहायक और अवसरप्रधान" : [6, 8, 12].includes(lordHouse) ? "परिवर्तन, सेवा या बाधा के बाद फलदायी" : "क्रमिक प्रयास से विकसित"} बनाता है। {occupants.length ? `${occupants.join(", ")} इस क्षेत्र में अपने कारकत्व जोड़ते हैं।` : "फल मुख्यतः राशीश और संबंधित दशा से संचालित होगा।"}
              </p>
            </div>
          );
          })}
          <p className="pdf-prediction-box">
            वर्ष का फल natal promise को बदलता नहीं। मुख्य घटना की पुष्टि natal Dasha, Varsh
            Pravesh house/lord, annual bindus और Gochar के समान संकेत से होगी।
          </p>
          <Footer page={startPage + 1 + pageIndex} total={totalPages} />
        </section>
      ))}
    </>
  );
}
