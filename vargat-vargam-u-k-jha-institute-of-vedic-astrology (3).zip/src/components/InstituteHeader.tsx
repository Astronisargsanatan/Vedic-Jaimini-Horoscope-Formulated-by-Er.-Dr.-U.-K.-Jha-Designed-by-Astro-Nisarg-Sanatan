import Logo from "./Logo";

export default function InstituteHeader({ compact = false }: { compact?: boolean }) {
  return (
    <header
      className={`relative overflow-hidden rounded-[2rem] border border-amber-800/20 bg-gradient-to-b from-[#fffaf0] via-[#fdf4e3] to-[#f9ecd6] text-center shadow-[0_18px_50px_-25px_rgba(120,53,15,0.45)] ${
        compact ? "px-5 py-5" : "px-5 py-10 sm:px-10 sm:py-12"
      }`}
    >
      <div className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{ background: "repeating-conic-gradient(from 0deg at 50% 0%, #b45309 0deg 4deg, transparent 4deg 12deg)" }}
      />
      <div className="pointer-events-none absolute inset-x-6 top-3 h-px bg-gradient-to-r from-transparent via-amber-700/40 to-transparent" />

      <div className="relative flex flex-col items-center">
        <Logo
          className={compact ? "h-16 w-16 object-contain" : "h-36 w-36 object-contain drop-shadow-[0_10px_24px_rgba(120,53,15,0.35)] sm:h-48 sm:w-48"}
        />
        <h1 className={`mt-5 font-serif font-black uppercase leading-tight text-[#14532d] ${compact ? "text-xl sm:text-2xl" : "text-3xl sm:text-5xl"}`}>
          U K Jha Institute
          <span className={`mt-1 block font-serif font-bold uppercase tracking-[0.14em] text-[#3730a3] ${compact ? "text-sm sm:text-lg" : "text-xl sm:text-3xl"}`}>
            of Vedic Astrology
          </span>
        </h1>
        <p className={`mt-3 font-serif font-semibold text-[#7c2d12] ${compact ? "text-sm" : "text-lg sm:text-2xl"}`}>
          By Er. Dr. U K Jha
        </p>
        <p className={`mt-1 text-stone-500 ${compact ? "text-xs" : "text-sm sm:text-base"}`}>
          President · Er. Dr. U K Jha · Vice President · Astro Nisarg Sanatan (Gujarat Chapter)
        </p>
      </div>
    </header>
  );
}
