type Principle = {
  sanskrit: string;
  devanagari: string;
  gloss: string;
  active?: boolean;
  linkTo?: "jaimini";
  linkLabel?: string;
};

const PRINCIPLES: Principle[] = [
  {
    sanskrit: "Bhavat Bhavam",
    devanagari: "भावात् भावम्",
    gloss: "House from the house — counting a bhava forward from itself.",
  },
  {
    sanskrit: "Bhaveshat Bhavam",
    devanagari: "भावेशात् भावम्",
    gloss:
      "House from the house-lord — reckoning from the dispositor. Opens Jaimini Arudha of Evolution (AL–A12).",
    linkTo: "jaimini",
    linkLabel: "Open Arudha of Evolution →",
  },
  {
    sanskrit: "Karakat Bhavam",
    devanagari: "कारकात् भावम्",
    gloss: "House from the significator — the karaka as a movable lagna.",
  },
  {
    sanskrit: "Vargat Vargam",
    devanagari: "वर्गात् वर्गम्",
    gloss: "Divisional within the divisional — varga of a varga, the engineering of sub-charts.",
    active: true,
  },
  {
    sanskrit: "Chakrat Chakram",
    devanagari: "चक्रात् चक्रम्",
    gloss: "Wheel from the wheel — one chakra read as the base of the next.",
  },
];

export default function PanchLakshana({
  onOpenJaimini,
}: {
  onOpenJaimini?: () => void;
}) {
  return (
    <section className="rounded-3xl border border-amber-800/15 bg-white/70 p-6 shadow-[0_12px_36px_-24px_rgba(120,53,15,0.5)] sm:p-8">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <h3 className="font-serif text-2xl font-bold text-[#7c2d12]">
          Panch Lakshana{" "}
          <span className="text-base font-normal text-stone-500">— the five marks</span>
        </h3>
        <span className="rounded-full border border-amber-800/20 bg-amber-50 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-amber-800">
          Parashara&rsquo;s system of chart evaluation
        </span>
      </div>

      <ol className="mt-6 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {PRINCIPLES.map((p, i) => {
          const isLink = p.linkTo === "jaimini" && onOpenJaimini;
          return (
            <li
              key={p.sanskrit}
              className={`relative overflow-hidden rounded-2xl border p-4 transition ${
                p.active
                  ? "border-amber-600/50 bg-gradient-to-br from-amber-100 via-amber-50 to-white shadow-md shadow-amber-900/10"
                  : isLink
                    ? "border-teal-600/40 bg-gradient-to-br from-teal-50 via-white to-[#fdfaf4] shadow-sm hover:border-teal-500 hover:shadow-md"
                    : "border-stone-200 bg-[#fdfaf4] hover:border-amber-500/40 hover:bg-amber-50/70"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg font-mono text-sm font-bold ${
                    p.active
                      ? "bg-amber-600 text-white"
                      : isLink
                        ? "bg-teal-700 text-white"
                        : "bg-stone-100 text-stone-600 ring-1 ring-stone-200"
                  }`}
                >
                  {i + 1}
                </span>
                <div>
                  <div
                    className={`font-serif text-lg font-bold leading-tight ${
                      p.active
                        ? "text-[#7c2d12]"
                        : isLink
                          ? "text-teal-900"
                          : "text-stone-800"
                    }`}
                  >
                    {p.sanskrit}
                  </div>
                  <div className="text-xs text-stone-500">{p.devanagari}</div>
                </div>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-stone-600">{p.gloss}</p>

              {p.active && (
                <span className="absolute right-3 top-3 rounded-full bg-amber-600/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-widest text-amber-800">
                  In focus
                </span>
              )}

              {isLink && (
                <button
                  type="button"
                  onClick={onOpenJaimini}
                  className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-teal-800 px-3 py-2 text-xs font-bold text-teal-50 transition hover:bg-teal-700 active:scale-[0.99]"
                >
                  {p.linkLabel ?? "Open Jaimini Updesha Sutram →"}
                </button>
              )}
            </li>
          );
        })}
      </ol>
    </section>
  );
}
