import { useMemo, useState } from "react";
import { BookOpen, ExternalLink, Search } from "lucide-react";
import { DEVOTIONAL_BOOK_CATEGORIES, DEVOTIONAL_BOOKS } from "../lib/devotionalBooks";

export default function DevotionalLibrary() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");

  const books = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return DEVOTIONAL_BOOKS.filter((book) => {
      const matchesCategory = category === "All" || book.category === category;
      const text = `${book.titleHi} ${book.titleEn} ${book.category} ${book.note ?? ""}`.toLowerCase();
      return matchesCategory && (!normalized || text.includes(normalized));
    });
  }, [category, query]);

  return (
    <section className="space-y-6">
      <header className="overflow-hidden rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-5 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-700/25 bg-amber-100 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.22em] text-amber-800">
              <BookOpen className="h-3.5 w-3.5" />
              साहित्य-संग्रह
            </div>
            <h2 className="mt-3 font-serif text-2xl font-black text-[#7c2d12] sm:text-4xl">
              परम श्रद्धेय स्वामी सनातन श्रीजी महाराज साहित्य-संग्रह
            </h2>
            <p className="mt-3 text-sm leading-7 text-stone-600 sm:text-base sm:leading-8">
              सनातन धर्म, वेद, उपनिषद, ब्रह्मसूत्र, श्रीमद्भगवद्गीता, रामकथा, कृष्णकथा,
              तत्त्व, दर्शन, साधना, ज्योतिष तथा भारतीय संस्कृति के विविध आयामों पर आधारित
              ग्रन्थों एवं प्रवचनों का डिजिटल संग्रह अध्ययन, मनन एवं अनुसंधान हेतु प्रस्तुत है।
            </p>
          </div>
          <div className="rounded-2xl border border-amber-800/15 bg-white/80 px-4 py-3 text-sm shadow-sm lg:w-64">
            <div className="text-[10px] font-bold uppercase tracking-wider text-amber-700">
              Total Books
            </div>
            <div className="mt-1 font-mono text-3xl font-black text-[#7c2d12]">
              {DEVOTIONAL_BOOKS.length}
            </div>
            <p className="mt-1 text-xs text-stone-500">Archive.org source links with cover thumbnails.</p>
          </div>
        </div>
      </header>

      <div className="rounded-3xl border border-amber-800/15 bg-white/80 p-4 shadow-sm">
        <div className="grid gap-3 lg:grid-cols-[1fr_260px]">
          <label className="relative block">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-amber-700" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search by Hindi / English title, topic, Jyotirved, Ram Katha..."
              className="w-full rounded-xl border border-amber-800/20 bg-[#fffdf8] py-3 pl-10 pr-3 text-sm outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/15"
            />
          </label>
          <select
            value={category}
            onChange={(event) => setCategory(event.target.value)}
            className="w-full rounded-xl border border-amber-800/20 bg-[#fffdf8] px-3 py-3 text-sm font-semibold outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/15"
          >
            <option value="All">All Categories</option>
            {DEVOTIONAL_BOOK_CATEGORIES.map((item) => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {books.map((book) => (
          <article
            key={book.id}
            className="group flex min-w-0 flex-col overflow-hidden rounded-3xl border border-amber-800/15 bg-white/90 shadow-[0_12px_35px_-28px_rgba(120,53,15,0.55)] transition hover:-translate-y-0.5 hover:border-amber-700/35 hover:shadow-lg"
          >
            <a href={book.archiveUrl} target="_blank" rel="noreferrer" className="block bg-amber-50 p-4">
              <div className="mx-auto aspect-[3/4] w-full max-w-[180px] overflow-hidden rounded-2xl border border-amber-800/20 bg-white shadow-sm">
                <img
                  src={book.coverUrl}
                  alt={`${book.titleHi} cover`}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.03]"
                />
              </div>
            </a>
            <div className="flex flex-1 flex-col p-4">
              <div className="flex items-start justify-between gap-2">
                <span className="rounded-full bg-amber-100 px-2 py-0.5 font-mono text-[10px] font-black text-amber-800">
                  #{book.id}
                </span>
                <span className="rounded-full border border-stone-200 bg-[#fdfaf4] px-2 py-0.5 text-[10px] font-bold text-stone-500">
                  {book.category}
                </span>
              </div>
              <h3 className="mt-3 font-serif text-lg font-black leading-snug text-[#7c2d12]">
                {book.titleHi}
              </h3>
              <p className="mt-1 text-xs font-semibold leading-5 text-stone-500">{book.titleEn}</p>
              {book.note && <p className="mt-2 text-xs leading-5 text-stone-600">{book.note}</p>}
              {book.language && (
                <p className="mt-2 text-[10px] font-bold uppercase tracking-wide text-indigo-700">
                  {book.language}
                </p>
              )}
              <a
                href={book.archiveUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-auto inline-flex items-center justify-center gap-2 rounded-xl bg-[#7c2d12] px-4 py-2.5 text-xs font-bold text-amber-50 transition hover:bg-[#9a3412]"
              >
                Download (PDF)
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </article>
        ))}
      </div>

      {books.length === 0 && (
        <div className="rounded-3xl border border-amber-800/15 bg-white/80 p-8 text-center text-sm text-stone-500">
          No books matched the current search.
        </div>
      )}

      <footer className="rounded-3xl border border-amber-800/15 bg-[#fffdf8] p-5 text-sm leading-7 text-stone-600 shadow-sm sm:p-6">
        <p>
          <strong className="text-[#7c2d12]">लेखक:</strong> परम श्रद्धेय स्वामी सनातन श्रीजी महाराज
        </p>
        <p>
          <strong className="text-[#7c2d12]">विषय:</strong> वेद, उपनिषद्, ब्रह्मसूत्र,
          भगवद्गीता, रामकथा, कृष्णलीला, साधना, ज्योतिर्वेद, सनातन दर्शन एवं भारतीय संस्कृति।
        </p>
        <p>
          <strong className="text-[#7c2d12]">उद्देश्य:</strong> सत्य, धर्म, ज्ञान और आत्मबोध की
          सनातन परम्परा को जन-जन तक पहुँचाना।
        </p>
      </footer>
    </section>
  );
}
