import type { BirthInput } from "../lib/birthCalc";

const inputClass =
  "w-full rounded-xl border border-indigo-800/20 bg-white px-3 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/15";

const OFFSETS = [
  "-12:00", "-11:00", "-10:00", "-09:30", "-09:00", "-08:00", "-07:00", "-06:00",
  "-05:00", "-04:00", "-03:30", "-03:00", "-02:00", "-01:00", "+00:00", "+01:00",
  "+02:00", "+03:00", "+03:30", "+04:00", "+04:30", "+05:00", "+05:30", "+05:45",
  "+06:00", "+06:30", "+07:00", "+08:00", "+08:45", "+09:00", "+09:30", "+10:00",
  "+10:30", "+11:00", "+12:00", "+12:45", "+13:00", "+14:00",
];

export default function ManualCoordinates({
  value,
  onChange,
}: {
  value: BirthInput;
  onChange: (field: keyof BirthInput, value: string) => void;
}) {
  const format = value.manualCoordinateFormat ?? "DD";

  return (
    <div className="rounded-2xl border-2 border-indigo-500/25 bg-indigo-50/50 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-serif text-base font-bold text-indigo-950">Manual Coordinates</h3>
          <p className="mt-0.5 text-xs text-indigo-800/75">
            GPS/gazetteer coordinates ko Decimal Degrees ya Degrees-Minutes-Seconds mein enter karein.
          </p>
        </div>
        <div className="grid w-full grid-cols-2 rounded-xl border border-indigo-800/15 bg-white p-1 sm:w-auto">
          {(["DD", "DMS"] as const).map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => onChange("manualCoordinateFormat", item)}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold ${
                format === item ? "bg-indigo-800 text-white" : "text-stone-600"
              }`}
            >
              {item === "DD" ? "Decimal (DD)" : "DMS"}
            </button>
          ))}
        </div>
      </div>

      <label className="mt-4 block">
        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700">
          Custom Place Name
        </span>
        <input
          value={value.customPlaceName ?? ""}
          onChange={(event) => onChange("customPlaceName", event.target.value)}
          placeholder="Village / Town / Taluka / District, State, Country"
          className={`${inputClass} mt-1.5`}
        />
      </label>

      {format === "DD" ? (
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <DecimalCoordinate
            label="Latitude"
            max={90}
            value={value.latitude ?? ""}
            direction={value.latitudeDirection ?? "N"}
            directions={["N", "S"]}
            onValue={(next) => onChange("latitude", next)}
            onDirection={(next) => onChange("latitudeDirection", next)}
          />
          <DecimalCoordinate
            label="Longitude"
            max={180}
            value={value.longitude ?? ""}
            direction={value.longitudeDirection ?? "E"}
            directions={["E", "W"]}
            onValue={(next) => onChange("longitude", next)}
            onDirection={(next) => onChange("longitudeDirection", next)}
          />
        </div>
      ) : (
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          <DmsCoordinate
            label="Latitude"
            max={90}
            degrees={value.latitudeDegrees ?? ""}
            minutes={value.latitudeMinutes ?? ""}
            seconds={value.latitudeSeconds ?? ""}
            direction={value.latitudeDirection ?? "N"}
            directions={["N", "S"]}
            onChange={onChange}
            prefix="latitude"
          />
          <DmsCoordinate
            label="Longitude"
            max={180}
            degrees={value.longitudeDegrees ?? ""}
            minutes={value.longitudeMinutes ?? ""}
            seconds={value.longitudeSeconds ?? ""}
            direction={value.longitudeDirection ?? "E"}
            directions={["E", "W"]}
            onChange={onChange}
            prefix="longitude"
          />
        </div>
      )}

      <label className="mt-4 block">
        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700">
          Timezone Offset Active on Birth Date
        </span>
        <select
          value={value.timezoneOffset ?? "+05:30"}
          onChange={(event) => onChange("timezoneOffset", event.target.value)}
          className={`${inputClass} mt-1.5 font-mono font-bold`}
        >
          {OFFSETS.map((offset) => (
            <option key={offset} value={offset}>
              UTC{offset}{offset === "+05:30" ? " (IST)" : ""}
            </option>
          ))}
        </select>
        <p className="mt-1 text-[10px] text-indigo-700/70">
          Manual mode mein DST automatic nahi hota; DOB par active exact offset select karein.
        </p>
      </label>
    </div>
  );
}

function DecimalCoordinate({
  label, max, value, direction, directions, onValue, onDirection,
}: {
  label: string; max: number; value: string; direction: string; directions: string[];
  onValue: (value: string) => void; onDirection: (value: string) => void;
}) {
  return (
    <div>
      <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700">{label} · DD</span>
      <div className="mt-1.5 grid grid-cols-[1fr_105px] gap-2">
        <input type="number" min="0" max={max} step="0.000001" value={value} onChange={(e) => onValue(e.target.value)} placeholder={label === "Latitude" ? "23.022500" : "72.571400"} className={`${inputClass} font-mono`} />
        <select value={direction} onChange={(e) => onDirection(e.target.value)} className={`${inputClass} font-bold`}>
          {directions.map((item) => <option key={item}>{item}</option>)}
        </select>
      </div>
    </div>
  );
}

function DmsCoordinate({
  label, max, degrees, minutes, seconds, direction, directions, onChange, prefix,
}: {
  label: string; max: number; degrees: string; minutes: string; seconds: string;
  direction: string; directions: string[]; prefix: "latitude" | "longitude";
  onChange: (field: keyof BirthInput, value: string) => void;
}) {
  return (
    <div>
      <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700">{label} · DMS</span>
      <div className="mt-1.5 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <input type="number" min="0" max={max} value={degrees} onChange={(e) => onChange(`${prefix}Degrees` as keyof BirthInput, e.target.value)} placeholder="Deg" className={`${inputClass} min-w-0 font-mono`} />
        <input type="number" min="0" max="59" value={minutes} onChange={(e) => onChange(`${prefix}Minutes` as keyof BirthInput, e.target.value)} placeholder="Min" className={`${inputClass} min-w-0 font-mono`} />
        <input type="number" min="0" max="59.999" step="0.001" value={seconds} onChange={(e) => onChange(`${prefix}Seconds` as keyof BirthInput, e.target.value)} placeholder="Sec" className={`${inputClass} min-w-0 font-mono`} />
        <select value={direction} onChange={(e) => onChange(`${prefix}Direction` as keyof BirthInput, e.target.value)} className={`${inputClass} min-w-0 font-bold`}>
          {directions.map((item) => <option key={item}>{item}</option>)}
        </select>
      </div>
    </div>
  );
}
