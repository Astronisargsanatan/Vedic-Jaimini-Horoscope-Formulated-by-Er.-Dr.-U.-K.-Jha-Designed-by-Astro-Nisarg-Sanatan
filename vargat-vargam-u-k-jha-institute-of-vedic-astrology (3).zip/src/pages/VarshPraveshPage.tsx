import { useEffect, useMemo, useState } from "react";
import { CalendarRange, ChevronLeft, ChevronRight } from "lucide-react";
import NorthChart from "../components/NorthChart";
import { computeVarga, formatDMS, rashiName } from "../lib/astro";
import { computeVarshPravesh, formatVarshDate } from "../lib/varshPravesh";
import { useChart } from "../state/ChartContext";

export default function VarshPraveshPage() {
  const { chart, native } = useChart();
  const currentYear = new Date().getUTCFullYear();
  const [year, setYear] = useState(currentYear);

  useEffect(() => {
    if (!native?.date) return;
    const match = native.date.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (!match) return;
    const now = new Date();
    const anniversary = new Date(
      now.getFullYear(),
      Number(match[2]) - 1,
      Number(match[1]),
      23,
      59,
      59,
    );
    setYear(now > anniversary ? now.getFullYear() : now.getFullYear() - 1);
  }, [native?.date]);

  const calculation = useMemo(() => {
    if (!native) return { result: null, error: "Calculate the birth horoscope on Home first." };
    try {
      return { result: computeVarshPravesh(chart, native, year), error: "" };
    } catch (reason) {
      return {
        result: null,
        error: reason instanceof Error ? reason.message : "Unable to calculate Varsh Pravesh.",
      };
    }
  }, [chart, native, year]);

  const result = calculation.result;
  const signs = result ? computeVarga(result.chart, "D1") : null;

  return (
    <div className="space-y-7">
      <header className="rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-5 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">
          <CalendarRange className="h-4 w-4" />
          Nirayana Solar Return · Fixed Birth Place
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Varsh Pravesh
        </h1>
        <p className="mt-3 max-w-4xl text-sm leading-relaxed text-stone-600 sm:text-base">
          Selected year mein Surya jab natal Sun ki exact Lahiri Nirayana longitude par wapas aata
          hai, us exact second aur native ke original Birth Place par Varsh Pravesh D1 generate hota
          hai.
        </p>

        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center">
          <button
            type="button"
            onClick={() => setYear((value) => value - 1)}
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-amber-800/20 bg-white px-4 text-sm font-bold text-[#7c2d12] hover:bg-amber-50"
          >
            <ChevronLeft className="h-4 w-4" /> Previous Year
          </button>
          <div className="flex min-h-12 flex-1 items-center justify-center rounded-xl border border-amber-800/20 bg-amber-50 px-4 text-center">
            <span className="font-serif text-xl font-black text-[#7c2d12]">{year}</span>
            {result && (
              <span className="ml-3 text-xs text-stone-500">
                Completed Age {result.completedAge} · Running Year {result.runningYear}
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={() => setYear((value) => value + 1)}
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[#7c2d12] px-4 text-sm font-bold text-amber-50 hover:bg-[#9a3412]"
          >
            Next Year <ChevronRight className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              if (!native?.date) return setYear(currentYear);
              const match = native.date.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
              if (!match) return setYear(currentYear);
              const now = new Date();
              const anniversary = new Date(now.getFullYear(), Number(match[2]) - 1, Number(match[1]), 23, 59, 59);
              setYear(now > anniversary ? now.getFullYear() : now.getFullYear() - 1);
            }}
            className="inline-flex min-h-12 items-center justify-center rounded-xl border border-stone-300 bg-white px-4 text-xs font-bold text-stone-700 hover:bg-stone-50"
          >
            Current Age Year
          </button>
        </div>
      </header>

      {calculation.error && (
        <section className="rounded-2xl border-2 border-amber-500 bg-amber-50 p-5 text-sm text-amber-900">
          <strong>Varsh Pravesh requires Home birth data.</strong>
          <p className="mt-1">{calculation.error}</p>
        </section>
      )}

      {result && signs && native && (
        <>
          <section className="grid gap-5 lg:grid-cols-[minmax(0,410px)_1fr]">
            <div className="rounded-3xl border border-amber-800/15 bg-white/85 p-4 shadow-sm">
              <NorthChart
                signs={signs}
                title={`Varsh Pravesh D1 · ${result.targetYear}`}
                subtitle={`Age ${result.completedAge} completed · Running ${result.runningYear}`}
                accent="#7c2d12"
              />
              <div className="mt-3 rounded-xl bg-amber-50 p-3 text-center text-xs text-stone-600">
                <strong className="text-[#7c2d12]">Pravesh Time:</strong>{" "}
                {formatVarshDate(result.praveshInstant, native.tz)}
                <br />
                <strong className="text-[#7c2d12]">Location:</strong> {native.place}
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <Metric label="Target Year" value={`${result.targetYear}`} />
                <Metric
                  label="Varsh Pravesh Lagna"
                  value={`${result.chart.Lagna.sign}. ${rashiName(result.chart.Lagna.sign)} · ${formatDMS(result.chart.Lagna)}`}
                />
                <Metric
                  label="Natal Sun Nirayana"
                  value={`${result.natalSunSidereal.toFixed(8)}°`}
                />
                <Metric
                  label="Return Sun Nirayana"
                  value={`${result.returnSunSidereal.toFixed(8)}°`}
                />
              </div>

              <div className="rounded-2xl border-2 border-emerald-500/30 bg-emerald-50 p-4 text-xs leading-relaxed text-emerald-950">
                <strong>Exactness check:</strong> natal Sun और return Sun का अंतर{" "}
                <span className="font-mono font-black">
                  {result.differenceArcSeconds.toFixed(4)} arcseconds
                </span>
                । Search exact return को 1 second से बेहतर time resolution तक refine करता है।
              </div>

              <div className="rounded-2xl border border-indigo-700/15 bg-indigo-50 p-4 text-xs leading-relaxed text-indigo-950">
                <strong>Fixed-location rule:</strong> Varsh Pravesh chart हमेशा जन्मस्थान coordinates
                {native.lat != null && native.lon != null
                  ? ` (${native.lat.toFixed(5)}, ${native.lon.toFixed(5)})`
                  : ""} पर बनाया गया है। Current residence या transit location उपयोग नहीं हुई।
              </div>
            </div>
          </section>

          <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-sm">
            <header className="border-b border-amber-800/10 bg-amber-50 px-4 py-4 sm:px-6">
              <h2 className="font-serif text-xl font-black text-[#7c2d12]">
                Varsh Pravesh Planetary Positions
              </h2>
              <p className="text-xs text-stone-500">
                Exact solar-return instant · Lahiri Chitrapaksha · Mean Rahu/Ketu
              </p>
            </header>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[780px] text-sm">
                <thead>
                  <tr className="bg-amber-50 text-left text-[10px] font-bold uppercase tracking-wide text-amber-900">
                    <th className="px-3 py-2">Graha</th>
                    <th className="px-3 py-2">Varsh Rashi</th>
                    <th className="px-3 py-2">Longitude</th>
                    <th className="px-3 py-2 text-center">Varsh House</th>
                    <th className="px-3 py-2 text-center">Motion</th>
                    <th className="px-3 py-2">Natal Rashi</th>
                    <th className="px-3 py-2">Comparison</th>
                  </tr>
                </thead>
                <tbody>
                  {result.planets.map((planet) => (
                    <tr key={planet.key} className="border-t border-stone-100">
                      <td className="px-3 py-2 font-serif font-bold text-stone-900">{planet.key}</td>
                      <td className="px-3 py-2 font-semibold text-[#7c2d12]">
                        {planet.sign}. {planet.rashi}
                      </td>
                      <td className="px-3 py-2 font-mono text-xs text-stone-600">
                        {planet.longitude}
                      </td>
                      <td className="px-3 py-2 text-center font-mono">H{planet.house}</td>
                      <td className="px-3 py-2 text-center font-mono font-bold">{planet.motion}</td>
                      <td className="px-3 py-2 text-stone-600">
                        {planet.natalSign}. {rashiName(planet.natalSign)}
                      </td>
                      <td className="px-3 py-2 text-xs text-stone-500">
                        {planet.sign === planet.natalSign ? "Same Rashi" : "Rashi changed"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="rounded-3xl border border-indigo-700/15 bg-indigo-50/60 p-5 text-xs leading-relaxed text-indigo-950 sm:p-6">
            <h2 className="font-serif text-lg font-black">Varsh Pravesh Calculation Factors</h2>
            <ul className="mt-3 list-inside list-disc space-y-1.5 text-stone-700">
              <li>Natal anchor: exact geocentric apparent Sun at the Home birth UTC instant.</li>
              <li>Return condition: current Sun reaches the same Lahiri Nirayana longitude.</li>
              <li>Location: original Birth Place latitude and longitude only.</li>
              <li>Chart: exact return-second D1 Lagna and all Grahas.</li>
              <li>Rahu/Ketu: Mean Node; Ketu exactly 180° from Rahu; node lordship remains NULL.</li>
              <li>Previous/Next controls recalculate the complete return chart for that year.</li>
            </ul>
          </section>
        </>
      )}
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-amber-800/15 bg-white/85 p-4">
      <div className="text-[9px] font-bold uppercase tracking-wider text-amber-700">{label}</div>
      <div className="mt-1 break-words font-serif text-base font-black text-[#7c2d12]">{value}</div>
    </div>
  );
}
