import { useMemo, useState } from "react";
import { ChevronDown, ChevronUp, Copy, Eye, Layers3, Route } from "lucide-react";
import NorthChart from "../components/NorthChart";
import {
  PLANETS,
  computeEngineeredVarga,
  formatDMS,
  houseOf,
  rashiName,
  type PlanetKey,
} from "../lib/astro";
import {
  ALLOWED_FACTORS,
  analyze,
  exactDivision,
  primeFactorString,
  type ExactDivision,
  type LayerResult,
} from "../lib/factorize";
import {
  focusArea,
  harmonicName,
  layerName,
  layerNotation,
  mappingId,
  mappingNotation,
} from "../lib/vargaEngineering";
import { useChart } from "../state/ChartContext";

const PRESETS = [12, 16, 18, 20, 24, 30, 36, 40, 48, 60, 81];
const GENERATED_PER_LAYER = 600;

function ProductEquation({ factors, total }: { factors: readonly number[]; total: number }) {
  return (
    <span className="font-mono font-black text-stone-900">
      {factors.map((factor, index) => (
        <span key={`${factor}-${index}`}>
          D{factor}
          {index < factors.length - 1 && <span className="px-1.5 text-amber-600">×</span>}
        </span>
      ))}
      <span className="px-1.5 text-stone-400">=</span>
      <span className="text-emerald-700">D{total}</span>
    </span>
  );
}

function KundaliViewer({
  factors,
  total,
  onGoVarga,
}: {
  factors: readonly number[];
  total: number;
  onGoVarga?: () => void;
}) {
  const { chart, engineeringVargaName, applyEngineeringToDashvarga } = useChart();
  const signs = useMemo(() => computeEngineeredVarga(chart, factors), [chart, factors]);
  const stageCharts = useMemo(
    () => factors.map((_, index) => computeEngineeredVarga(chart, factors.slice(0, index + 1))),
    [chart, factors],
  );

  const chartLabel = `${layerNotation(factors)} (D${total})`;
  const isApplied = engineeringVargaName === chartLabel;

  const handleApply = () => {
    applyEngineeringToDashvarga(chartLabel, signs);
  };

  return (
    <div className="grid gap-6 border-t border-amber-800/15 bg-[#fffaf0] p-5 lg:grid-cols-[minmax(0,360px)_1fr]">
      <div className="rounded-2xl border border-amber-800/15 bg-white p-3 shadow-sm">
        <NorthChart
          signs={signs}
          title={`${layerNotation(factors)} · D${total}`}
          subtitle={`${layerName(factors)} Kundali`}
          accent="#7c2d12"
        />
        <div className="mt-3 flex flex-col gap-2">
          <p className="text-center text-[11px] leading-relaxed text-stone-500">
            Ordered transformation applied left to right from D1 longitudes.
          </p>
          <button
            type="button"
            onClick={handleApply}
            className={`w-full rounded-xl py-2 px-3 text-xs font-bold transition ${
              isApplied
                ? "bg-emerald-600 text-white shadow-sm"
                : "border border-emerald-700/30 bg-emerald-50 text-emerald-800 hover:bg-emerald-100"
            }`}
          >
            {isApplied ? "✓ Active in Dashvarga Slot 10" : "🔘 Use for Dashvarga"}
          </button>
          {isApplied && onGoVarga && (
            <button
              type="button"
              onClick={onGoVarga}
              className="w-full rounded-xl border border-stone-300 bg-white py-1.5 text-[11px] font-semibold text-stone-700 hover:bg-stone-50"
            >
              View in Vargat Vargam →
            </button>
          )}
        </div>
      </div>

      <div className="min-w-0">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h4 className="font-serif text-lg font-bold text-[#7c2d12]">
            Planetary Engineering Verification
          </h4>
          <span className="rounded-full border border-amber-700/20 bg-white px-3 py-1 font-mono text-[11px] text-amber-800">
            Varga Lagna: {signs.Lagna} · {rashiName(signs.Lagna)}
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-stone-200 bg-white">
          <table className="w-full min-w-[610px] text-sm">
            <thead>
              <tr className="border-b border-amber-800/15 bg-amber-50 text-left text-[10px] font-bold uppercase tracking-[0.12em] text-amber-800">
                <th className="px-3 py-2.5">Planet</th>
                <th className="px-3 py-2.5">D1 Position</th>
                <th className="px-3 py-2.5">Rashi Path</th>
                <th className="px-3 py-2.5">Final Rashi</th>
                <th className="px-3 py-2.5 text-center">House</th>
              </tr>
            </thead>
            <tbody>
              {PLANETS.map((planet) => {
                const position = chart[planet.key as PlanetKey];
                const finalSign = signs[planet.key];
                const path = [position.sign, ...stageCharts.map((stage) => stage[planet.key])];
                return (
                  <tr key={planet.key} className="border-b border-stone-100 last:border-0">
                    <td className="px-3 py-2 font-semibold text-stone-800">
                      {planet.short} · {planet.label.split(" ")[0]}
                    </td>
                    <td className="px-3 py-2 text-xs text-stone-500">
                      {position.sign}. {rashiName(position.sign)} ·{" "}
                      <span className="font-mono">{formatDMS(position)}</span>
                    </td>
                    <td className="px-3 py-2 font-mono text-xs text-indigo-700">
                      {path.join(" → ")}
                    </td>
                    <td className="px-3 py-2 font-mono font-bold text-[#9a3412]">
                      {finalSign}. {rashiName(finalSign)}
                    </td>
                    <td className="px-3 py-2 text-center font-mono text-stone-700">
                      {houseOf(finalSign, signs.Lagna)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function EngineeringMapping({
  factors,
  total,
  index,
  isOpen,
  onToggle,
  onGoVarga,
  exact,
}: {
  factors: readonly number[];
  total: number;
  index: number;
  isOpen: boolean;
  onToggle: () => void;
  onGoVarga?: () => void;
  exact: ExactDivision;
}) {
  const { chart, engineeringVargaName, applyEngineeringToDashvarga } = useChart();
  const id = mappingId(factors);
  const notation = layerNotation(factors);
  const chartLabel = `${layerNotation(factors)} (D${total})`;
  const isApplied = engineeringVargaName === chartLabel;

  const handleApply = () => {
    const signs = computeEngineeredVarga(chart, factors);
    applyEngineeringToDashvarga(chartLabel, signs);
  };

  return (
    <article
      className={`overflow-hidden border-b last:border-0 ${
        exact.possible
          ? isOpen
            ? "border-amber-800/10 bg-amber-50/45"
            : "border-amber-800/10 bg-white/60"
          : "border-rose-400/40 bg-rose-50/70"
      }`}
    >
      <div className="p-5 sm:p-6">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex items-start gap-3">
              <span
                className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg font-mono text-xs font-black ring-1 ${
                  exact.possible
                    ? "bg-amber-100 text-amber-800 ring-amber-700/20"
                    : "bg-rose-100 text-rose-700 ring-rose-400/40"
                }`}
              >
                {index}
              </span>
              <div>
                <h3
                  className={`font-serif text-xl font-black leading-tight sm:text-2xl ${
                    exact.possible ? "text-[#7c2d12]" : "text-rose-800"
                  }`}
                >
                  Varga Engineering : {harmonicName(total)} / D{total}
                </h3>
                <p className="mt-1 text-xs text-stone-500">
                  Ordered {factors.length}-layer harmonic · {notation}
                </p>
                {!exact.possible && (
                  <span className="mt-2 inline-flex items-center gap-2 rounded-full border-2 border-rose-500 bg-rose-100 px-3 py-1 font-mono text-xs font-black uppercase tracking-widest text-rose-700">
                    ✗ Not Possible · Red
                  </span>
                )}
              </div>
            </div>

            <dl className="mt-5 grid gap-3 text-sm md:grid-cols-3">
              <div>
                <dt className="text-[10px] font-bold uppercase tracking-[0.16em] text-amber-700">
                  Mathematical Mapping
                </dt>
                <dd className="mt-1.5">
                  <ProductEquation factors={factors} total={total} />
                </dd>
              </div>
              <div>
                <dt className="text-[10px] font-bold uppercase tracking-[0.16em] text-amber-700">
                  Layer Name
                </dt>
                <dd className="mt-1.5 font-serif text-base font-bold text-stone-800">
                  {layerName(factors)}
                </dd>
              </div>
              <div>
                <dt className="text-[10px] font-bold uppercase tracking-[0.16em] text-amber-700">
                  Focus Area
                </dt>
                <dd className="mt-1.5 text-sm leading-relaxed text-stone-600">
                  {focusArea(factors)}
                </dd>
              </div>
            </dl>

            {!exact.possible && (
              <div className="mt-4 rounded-xl border-2 border-rose-400 bg-rose-100/80 px-4 py-3 text-xs font-semibold leading-relaxed text-rose-800">
                <span className="font-black uppercase tracking-wider">Not Possible to the Second — </span>
                {exact.reason}
                <span className="mt-1 block text-[11px] font-normal text-rose-700">
                  Aapke niyam ke anusaar: 30° ko D{total} se bhag karne par agar second tak poora
                  anka na aaye (22′ 13″ ke baad ⅓″ jaisa bacha hua hissa), to yeh division
                  maany nahi hai. Kundali generate nahi ho sakti.
                </span>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {exact.possible ? (
              <>
                <button
                  type="button"
                  onClick={handleApply}
                  className={`inline-flex items-center justify-center gap-1.5 rounded-xl px-4 py-3 text-xs font-bold transition ${
                    isApplied
                      ? "bg-emerald-600 text-white shadow-sm"
                      : "border border-emerald-700/30 bg-emerald-50 text-emerald-800 hover:bg-emerald-100"
                  }`}
                  title="Transfer output signs (Lagna to Ketu) into 10th slot of Vargat Vargam"
                >
                  <span>{isApplied ? "✓ Active in Dashvarga" : "🔘 Use for Dashvarga"}</span>
                </button>

                <a
                  href={`#open-chart-${id}`}
                  aria-expanded={isOpen}
                  onClick={(event) => {
                    event.preventDefault();
                    onToggle();
                    window.setTimeout(() => {
                      document.getElementById(`open-chart-${id}`)?.scrollIntoView({
                        behavior: "smooth",
                        block: "center",
                      });
                    }, 50);
                  }}
                  className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-xs font-bold transition ${
                    isOpen
                      ? "border border-amber-800/20 bg-amber-100 text-[#7c2d12]"
                      : "bg-[#7c2d12] text-amber-50 shadow-sm hover:bg-[#9a3412]"
                  }`}
                >
                  <Eye className="h-4 w-4" />
                  <span>{isOpen ? "Close Kundali" : `View Kundali: ${notation} (D${total})`}</span>
                  {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </a>
              </>
            ) : (
              <span className="inline-flex cursor-not-allowed items-center gap-2 rounded-xl border-2 border-rose-400 bg-rose-100 px-4 py-3 text-xs font-black uppercase tracking-wider text-rose-700">
                ✗ Not Possible — Kundali Disabled
              </span>
            )}
          </div>
        </div>
      </div>

      {isOpen && exact.possible && (
        <div id={`open-chart-${id}`}>
          <KundaliViewer factors={factors} total={total} onGoVarga={onGoVarga} />
        </div>
      )}
    </article>
  );
}

function LayerMappings({
  layer,
  total,
  openId,
  setOpenId,
  onGoVarga,
  exact,
}: {
  layer: LayerResult;
  total: number;
  openId: string | null;
  setOpenId: (id: string | null) => void;
  onGoVarga?: () => void;
  exact: ExactDivision;
}) {
  return (
    <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/75 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.6)]">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-800/10 bg-gradient-to-r from-amber-100 via-amber-50 to-transparent px-5 py-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-600 font-mono text-sm font-black text-white">
            {layer.layer}L
          </span>
          <div>
            <h2 className="font-serif text-xl font-bold text-[#7c2d12]">
              {layer.layer}-Layer Varga Engineering
            </h2>
            <p className="text-xs text-stone-500">
              {layer.layer === 2
                ? "Base Varga of Factor Varga"
                : `${layer.layer} ordered harmonic transformations`}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {exact.possible ? (
            <span className="rounded-full border border-emerald-700/20 bg-emerald-50 px-3 py-1 font-mono text-xs font-bold text-emerald-800">
              {layer.total.toLocaleString()} mapping{layer.total === 1 ? "" : "s"} · Exact ✓
            </span>
          ) : (
            <span className="rounded-full border border-rose-500/40 bg-rose-50 px-3 py-1 font-mono text-xs font-bold text-rose-700">
              {layer.total.toLocaleString()} mapping{layer.total === 1 ? "" : "s"} · All Not Possible ✗
            </span>
          )}
        </div>
      </header>

      <div>
        {layer.combos.map((factors, index) => {
          const id = mappingId(factors);
          return (
            <EngineeringMapping
              key={id}
              factors={factors}
              total={total}
              index={index + 1}
              isOpen={openId === id}
              onToggle={() => setOpenId(openId === id ? null : id)}
              onGoVarga={onGoVarga}
              exact={exact}
            />
          );
        })}
      </div>

      <div className="border-t border-amber-800/10 bg-amber-50/70 px-5 py-2.5 text-[11px] font-semibold text-amber-900">
        Exactness check: 30° = 108000″ ÷ D{total} → {exact.display}
        {exact.possible
          ? " — poora second tak bata hai ✓"
          : ` + ${exact.remainderSeconds}″ remainder ✗ — Not Possible`}
      </div>

      {layer.truncated && (
        <div className="border-t border-amber-800/10 bg-amber-50 px-5 py-3 text-xs text-amber-800">
          Showing {layer.combos.length.toLocaleString()} of {layer.total.toLocaleString()} mappings in
          this layer to preserve browser performance.
        </div>
      )}
    </section>
  );
}

function buildEngineeringReport(total: number, layers: LayerResult[], exact: ExactDivision | null): string {
  const lines: string[] = [`VARGA ENGINEERING: ${harmonicName(total)} / D${total}`, ""];
  lines.push(
    exact
      ? `EXACTNESS: ${exact.reason}${exact.possible ? " ✓ POSSIBLE" : " ✗ NOT POSSIBLE"}`
      : "",
  );
  lines.push("");
  for (const layer of layers) {
    lines.push(`${layer.layer}-LAYER`);
    for (const factors of layer.combos) {
      lines.push(`Varga Engineering : ${harmonicName(total)} / D${total}`);
      lines.push(`Mathematical Mapping: ${mappingNotation(factors)} = D${total}`);
      lines.push(`Layer Name: ${layerName(factors)}`);
      lines.push(`Focus Area: ${focusArea(factors)}`);
      lines.push(
        exact && !exact.possible
          ? `View Kundali: ${layerNotation(factors)} (D${total}) — [NOT POSSIBLE · second tak division nahi hota]`
          : `View Kundali: ${layerNotation(factors)} (D${total})`,
      );
      lines.push("");
    }
  }
  return lines.filter((l) => l !== "" || true).join("\n");
}

export default function CalculatorPage({ onGoVarga }: { onGoVarga?: () => void }) {
  const { engineeringVargaName } = useChart();
  const [raw, setRaw] = useState("12");
  const [openId, setOpenId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const total = Number(raw.trim());
  const report = useMemo(
    () => analyze(raw.trim() === "" ? Number.NaN : total, GENERATED_PER_LAYER),
    [raw, total],
  );
  const exact = useMemo(
    () => (Number.isFinite(total) && total >= 1 ? exactDivision(total) : null),
    [total],
  );

  const copyReport = async () => {
    try {
      await navigator.clipboard.writeText(buildEngineeringReport(report.input, report.layers, exact));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="space-y-7">
      <header className="relative overflow-hidden rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-6 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="absolute -right-20 -top-24 h-64 w-64 rounded-full bg-amber-300/20 blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">
            <Layers3 className="h-4 w-4" />
            Ordered Harmonic Composition
          </div>
          <h1 className="mt-3 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
            Varga Engineering
          </h1>
          <p className="mt-3 max-w-3xl text-sm leading-relaxed text-stone-600 sm:text-base">
            Select a final division. The engine finds every ordered Varga composition and generates
            its Kundali from the single planetary dataset entered on Home. For example, D2 of D6
            and D6 of D2 both map mathematically to D12, but remain separate ordered layers.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            {ALLOWED_FACTORS.map((factor) => (
              <span
                key={factor}
                className="rounded-lg border border-amber-800/15 bg-white px-2.5 py-1 font-mono text-xs font-black text-[#7c2d12]"
              >
                D{factor}
              </span>
            ))}
          </div>
        </div>
      </header>

      {engineeringVargaName && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-700/25 bg-emerald-50/90 px-5 py-3.5 shadow-sm">
          <div className="flex items-center gap-2.5">
            <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-600 animate-pulse" />
            <span className="text-xs font-bold text-emerald-950">
              Active in 10th Dashvarga Slot:
            </span>
            <span className="font-mono text-sm font-black text-emerald-800">
              {engineeringVargaName}
            </span>
          </div>
          {onGoVarga && (
            <button
              type="button"
              onClick={onGoVarga}
              className="rounded-xl bg-emerald-700 px-3.5 py-1.5 text-xs font-bold text-white transition hover:bg-emerald-800"
            >
              View in Vargat Vargam →
            </button>
          )}
        </div>
      )}

      <section className="rounded-3xl border border-amber-800/15 bg-white/80 p-5 shadow-sm sm:p-6">
        <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-end">
          <div>
            <label className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-700">
              Final Chart Division
            </label>
            <div className="mt-2 flex items-center overflow-hidden rounded-2xl border border-amber-800/20 bg-[#fffdf8] focus-within:border-amber-500 focus-within:ring-4 focus-within:ring-amber-500/15">
              <span className="border-r border-amber-800/15 bg-amber-50 px-5 py-4 font-serif text-2xl font-black text-[#7c2d12]">
                D
              </span>
              <input
                value={raw}
                onChange={(event) => {
                  setRaw(event.target.value.replace(/[^0-9]/g, ""));
                  setOpenId(null);
                }}
                inputMode="numeric"
                placeholder="12"
                className="min-w-0 flex-1 bg-transparent px-4 py-4 font-mono text-3xl font-black text-stone-900 outline-none"
              />
            </div>
          </div>

          <button
            type="button"
            onClick={copyReport}
            disabled={!report.valid || report.layers.length === 0}
            className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-[#7c2d12] px-5 text-sm font-bold text-amber-50 transition hover:bg-[#9a3412] disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Copy className="h-4 w-4" />
            {copied ? "Engineering report copied" : "Copy all mappings"}
          </button>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {PRESETS.map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => {
                setRaw(String(preset));
                setOpenId(null);
              }}
              className={`rounded-lg border px-3 py-1.5 font-mono text-xs font-bold transition ${
                total === preset
                  ? "border-amber-600 bg-amber-100 text-[#7c2d12]"
                  : "border-stone-200 bg-white text-stone-600 hover:border-amber-400 hover:bg-amber-50"
              }`}
            >
              D{preset}
            </button>
          ))}
        </div>
      </section>

      {!report.valid ? (
        <section className="rounded-3xl border border-amber-600/30 bg-amber-100/70 p-6 text-sm text-amber-900">
          {report.error ?? "Enter a final Varga division."}
        </section>
      ) : report.layers.length === 0 ? (
        <section className="rounded-3xl border border-rose-400/30 bg-rose-50 p-6 text-rose-800">
          <h2 className="font-serif text-xl font-bold">No engineering mapping for D{report.input}</h2>
          <p className="mt-2 text-sm">
            D{report.input} cannot be composed from two or more of D2, D3, D4, D5, D6, D8, D9 and
            D10.
          </p>
        </section>
      ) : (
        <>
          {exact && !exact.possible && (
            <div className="flex items-start gap-3 rounded-3xl border-2 border-rose-500 bg-rose-100/80 px-5 py-4">
              <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-rose-600 font-black text-white">
                ✗
              </span>
              <div className="text-sm text-rose-900">
                <strong className="font-black uppercase tracking-wide">
                  D{report.input} Not Possible (Red) —
                </strong>{" "}
                30° ÷ {report.input} second tak poora nahi bata. Example:
                <span className="mt-1 block font-mono text-xs font-bold text-rose-800">
                  {exact.reason}
                </span>
                <span className="mt-1 block text-xs text-rose-700">
                  Sirf wohi divisions valid hain jinke 30° ÷ D[Total] se second tak purna anka aaye.
                  Kundali/Use-for-Dashvarga in sabke liye disabled hai.
                </span>
              </div>
            </div>
          )}

          {exact && exact.possible && (
            <div className="flex items-center gap-3 rounded-3xl border-2 border-emerald-500/50 bg-emerald-50 px-5 py-3.5">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-600 font-black text-white">
                ✓
              </span>
              <div className="text-sm text-emerald-900">
                <strong>D{report.input} Exact</strong> — 30° ÷ {report.input} ={" "}
                <span className="font-mono font-bold">{exact.display}</span> · second tak poora
                division ✓
              </div>
            </div>
          )}

          <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-2xl border border-amber-800/15 bg-white/75 p-4">
              <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-amber-700">
                Chart Name / Division
              </div>
              <div className="mt-1 font-serif text-xl font-black text-[#7c2d12]">
                {harmonicName(report.input)}
              </div>
              <div className="font-mono text-sm text-stone-500">D{report.input}</div>
            </div>
            <div className="rounded-2xl border border-amber-800/15 bg-white/75 p-4">
              <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-amber-700">
                Prime Signature
              </div>
              <div className="mt-2 font-mono text-lg font-black text-indigo-800">
                {primeFactorString(report.input)}
              </div>
            </div>
            <div className="rounded-2xl border border-amber-800/15 bg-white/75 p-4">
              <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-amber-700">
                Active Layers
              </div>
              <div className="mt-2 font-mono text-lg font-black text-stone-800">
                {report.layers.map((layer) => `${layer.layer}L`).join(" · ")}
              </div>
            </div>
            {exact && (
              <div
                className={`rounded-2xl border p-4 ${
                  exact.possible
                    ? "border-emerald-700/20 bg-emerald-50"
                    : "border-rose-500/40 bg-rose-50"
                }`}
              >
                <div
                  className={`text-[10px] font-bold uppercase tracking-[0.16em] ${
                    exact.possible ? "text-emerald-700" : "text-rose-700"
                  }`}
                >
                  Exact Mapping
                </div>
                <div
                  className={`mt-1 font-mono text-2xl font-black ${
                    exact.possible ? "text-emerald-800" : "text-rose-700"
                  }`}
                >
                  {exact.possible ? "✓ POSSIBLE" : "✗ NOT POSSIBLE"}
                </div>
                <div className="mt-0.5 font-mono text-[10px] text-stone-500">
                  30° ÷ {report.input} = {exact.display}
                  {exact.possible ? "" : ` + ${exact.remainderSeconds}″`}
                </div>
              </div>
            )}
          </section>

          <div className="flex items-start gap-2 rounded-2xl border border-indigo-700/15 bg-indigo-50/70 px-4 py-3 text-xs leading-relaxed text-indigo-900">
            <Route className="mt-0.5 h-4 w-4 shrink-0" />
            <p>
              <strong>Reading rule:</strong> D[X] of D[Y] is processed from left to right. The
              occupied portion of D[X] is expanded to a fresh 30° field before D[Y] is applied.
              Therefore, each different order has its own computed Kundali — <strong>lekin sirf
              tab jab 30° ÷ D[Total] second tak poora ho</strong>. D81 jaisa division (108000″ ÷ 81
              = 22′ 13″ + ⅓″) red "Not Possible" ke saath mark hota hai.
            </p>
          </div>

          {report.layers.map((layer) => (
            <LayerMappings
              key={layer.layer}
              layer={layer}
              total={report.input}
              openId={openId}
              setOpenId={setOpenId}
              onGoVarga={onGoVarga}
              exact={exact!}
            />
          ))}
        </>
      )}
    </div>
  );
}