import { useMemo, useState } from "react";
import { CalendarClock, RefreshCw } from "lucide-react";
import NorthChart from "../components/NorthChart";
import {
  RASHI_LORDS,
  formatDMS,
  rashiName,
  type PlanetKey,
} from "../lib/astro";
import {
  computeTransits,
  formatTransitDate,
  type TransitIngress,
  type TransitPlanet,
} from "../lib/transit";
import { useChart } from "../state/ChartContext";

const HOUSE_FOCUS: Record<number, string> = {
  1: "Self, body, temperament and immediate life direction",
  2: "Wealth, speech, family, food and accumulated resources",
  3: "Courage, communication, siblings, effort and short journeys",
  4: "Home, mother, comforts, property and emotional foundation",
  5: "Intelligence, education, children, creativity and purva punya",
  6: "Disease, debt, service, competition and overcoming obstacles",
  7: "Marriage, partnerships, public dealings and agreements",
  8: "Longevity, transformation, secrets, inheritance and sudden events",
  9: "Dharma, fortune, father, teacher, pilgrimage and higher wisdom",
  10: "Career, karma, status, authority and public responsibility",
  11: "Gains, fulfilment, networks, elder siblings and ambitions",
  12: "Expenditure, foreign lands, sleep, isolation and liberation",
};

const PLANET_FOCUS: Partial<Record<PlanetKey, string>> = {
  Surya: "Authority, vitality, father and recognition",
  Chandra: "Mind, emotion, mother and daily experience",
  Mangal: "Action, courage, property and conflict",
  Budh: "Intellect, speech, trade and analysis",
  Guru: "Wisdom, expansion, children and blessings",
  Shukra: "Relationships, comforts, arts and agreements",
  Shani: "Duty, delay, endurance and karmic responsibility",
  Rahu: "Amplification, foreign influence, desire and unconventional change",
  Ketu: "Detachment, release, insight and separation",
};

function dateInputValue(date: Date): string {
  const shifted = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return shifted.toISOString().slice(0, 16);
}

function IngressBlock({
  label,
  ingress,
  timeZone,
}: {
  label: string;
  ingress: TransitIngress | null;
  timeZone?: string;
}) {
  if (!ingress) {
    return (
      <div className="rounded-xl border border-stone-200 bg-stone-50 p-3 text-xs text-stone-500">
        <div className="font-bold uppercase tracking-wider">{label}</div>
        <div className="mt-1">Search range mein parivartan nahi mila.</div>
      </div>
    );
  }
  return (
    <div className="rounded-xl border border-amber-800/15 bg-[#fffdf8] p-3">
      <div className="text-[9px] font-bold uppercase tracking-[0.16em] text-amber-700">{label}</div>
      <div className="mt-1 font-serif text-sm font-black text-[#7c2d12]">
        {ingress.fromSign}. {rashiName(ingress.fromSign)} → {ingress.toSign}.{" "}
        {rashiName(ingress.toSign)}
      </div>
      <div className="mt-1 font-mono text-[10px] text-stone-600">
        {formatTransitDate(ingress.date, timeZone)} · {ingress.motion}
      </div>
    </div>
  );
}

function TransitCard({ planet, timeZone }: { planet: TransitPlanet; timeZone?: string }) {
  return (
    <article className="rounded-2xl border border-amber-800/15 bg-white/85 p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-serif text-lg font-black text-[#7c2d12]">{planet.key}</h3>
          <p className="mt-0.5 text-[10px] text-stone-500">{PLANET_FOCUS[planet.key]}</p>
        </div>
        <span
          className={`rounded-full px-2.5 py-1 font-mono text-xs font-black ${
            planet.motion === "R"
              ? "bg-rose-100 text-rose-700"
              : "bg-emerald-100 text-emerald-700"
          }`}
        >
          {planet.motion}
        </span>
      </div>

      <div className="mt-3 rounded-xl bg-amber-50 p-3">
        <div className="text-[9px] font-bold uppercase tracking-wider text-amber-700">
          Current Gochar
        </div>
        <div className="mt-1 flex flex-wrap items-baseline gap-x-2">
          <span className="font-serif text-base font-black text-stone-900">
            {planet.position.sign}. {rashiName(planet.position.sign)}
          </span>
          <span className="font-mono text-xs text-stone-600">{formatDMS(planet.position)}</span>
        </div>
        <div className="mt-1 text-[10px] text-stone-500">
          Janma Lagna se House {planet.houseFromLagna} · Natal position se{" "}
          {planet.signDistanceFromNatal}th
        </div>
      </div>

      <div className="mt-3 grid gap-2">
        <IngressBlock label="Next Rashi Parivartan" ingress={planet.nextIngress} timeZone={timeZone} />
        <IngressBlock
          label="Next-to-Next Rashi Parivartan"
          ingress={planet.secondIngress}
          timeZone={timeZone}
        />
      </div>
    </article>
  );
}

export default function TransitPage() {
  const { chart, native } = useChart();
  const [referenceDate, setReferenceDate] = useState(() => new Date());
  const [inputDate, setInputDate] = useState(() => dateInputValue(new Date()));
  const result = useMemo(() => computeTransits(chart, referenceDate), [chart, referenceDate]);

  const refreshNow = () => {
    const now = new Date();
    setReferenceDate(now);
    setInputDate(dateInputValue(now));
  };

  return (
    <div className="space-y-7">
      <header className="rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-6 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">
          Lahiri Nirayana · Mean Rahu/Ketu · Janma Lagna Reference
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Transit · Gochar
        </h1>
        <p className="mt-3 max-w-4xl text-sm leading-relaxed text-stone-600 sm:text-base">
          वर्तमान गोचर को जन्म लग्न से दिखाया गया है। प्रत्येक ग्रह की natal position से तुलना,
          current house, गति, अगला Rashi Parivartan और उसके बाद का next-to-next Parivartan इसी
          page पर उपलब्ध है।
        </p>

        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-end">
          <label className="block flex-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700">
              Transit Reference Date & Time
            </span>
            <input
              type="datetime-local"
              value={inputDate}
              onChange={(event) => {
                setInputDate(event.target.value);
                const next = new Date(event.target.value);
                if (!Number.isNaN(next.getTime())) setReferenceDate(next);
              }}
              className="mt-1.5 w-full rounded-xl border border-amber-800/20 bg-white px-3 py-3 font-mono text-sm outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/15"
            />
          </label>
          <button
            type="button"
            onClick={refreshNow}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-[#7c2d12] px-5 text-sm font-bold text-amber-50 transition hover:bg-[#9a3412]"
          >
            <RefreshCw className="h-4 w-4" /> Current Gochar
          </button>
        </div>
      </header>

      <section className="grid gap-5 lg:grid-cols-[minmax(0,400px)_1fr]">
        <div className="rounded-3xl border border-amber-800/15 bg-white/85 p-4 shadow-sm">
          <NorthChart
            signs={result.chartSigns}
            title="Gochar Kundali from Janma Lagna"
            subtitle={`Janma Lagna: ${result.janmaLagna}. ${rashiName(result.janmaLagna)}`}
            accent="#7c2d12"
          />
          <div className="mt-3 rounded-xl border border-amber-800/10 bg-amber-50 px-3 py-2 text-center text-xs text-stone-600">
            Calculated: {formatTransitDate(result.calculatedAt, native?.tz)}
            <br />
            Lahiri Ayanamsha: {result.ayanamsha.toFixed(6)}° · Mean Nodes
          </div>
        </div>

        <div className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm">
          <h2 className="font-serif text-xl font-black text-[#7c2d12]">
            Natal vs Gochar Comparison
          </h2>
          <p className="mt-1 text-xs text-stone-500">
            Birth chart ke Graha ko current transit se side-by-side compare kiya gaya hai.
          </p>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[740px] text-sm">
              <thead>
                <tr className="border-b border-amber-800/20 text-left text-[10px] font-bold uppercase tracking-wide text-amber-800">
                  <th className="py-2 pr-3">Graha</th>
                  <th className="py-2 pr-3">Natal Position</th>
                  <th className="py-2 pr-3">Gochar Position</th>
                  <th className="py-2 pr-3 text-center">House from Lagna</th>
                  <th className="py-2 pr-3 text-center">From Natal Graha</th>
                  <th className="py-2 pr-3">Gochar Sign Lord</th>
                  <th className="py-2 text-center">Motion</th>
                </tr>
              </thead>
              <tbody>
                {result.planets.map((planet) => (
                  <tr key={planet.key} className="border-b border-stone-200/70 last:border-0">
                    <td className="py-2 pr-3 font-serif font-bold text-stone-900">{planet.key}</td>
                    <td className="py-2 pr-3 text-xs text-stone-600">
                      {planet.natalPosition.sign}. {rashiName(planet.natalPosition.sign)} ·{" "}
                      <span className="font-mono">{formatDMS(planet.natalPosition)}</span>
                    </td>
                    <td className="py-2 pr-3 text-xs font-semibold text-[#7c2d12]">
                      {planet.position.sign}. {rashiName(planet.position.sign)} ·{" "}
                      <span className="font-mono">{formatDMS(planet.position)}</span>
                    </td>
                    <td className="py-2 pr-3 text-center font-mono font-bold">
                      H{planet.houseFromLagna}
                    </td>
                    <td className="py-2 pr-3 text-center font-mono">
                      {planet.signDistanceFromNatal}th
                    </td>
                    <td className="py-2 pr-3 text-xs">
                      {planet.key === "Rahu" || planet.key === "Ketu"
                        ? "NULL"
                        : RASHI_LORDS[planet.position.sign]}
                    </td>
                    <td className="py-2 text-center font-mono font-bold">{planet.motion}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section>
        <div className="mb-4 flex items-center gap-2">
          <CalendarClock className="h-5 w-5 text-amber-700" />
          <h2 className="font-serif text-2xl font-black text-[#7c2d12]">
            Planet-wise Rashi Parivartan Schedule
          </h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {result.planets.map((planet) => (
            <TransitCard key={planet.key} planet={planet} timeZone={native?.tz} />
          ))}
        </div>
      </section>

      <section className="rounded-3xl border border-indigo-700/15 bg-indigo-50/70 p-5 sm:p-6">
        <h2 className="font-serif text-lg font-black text-indigo-950">Gochar Reading Factors</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {result.planets.map((planet) => (
            <div key={`factor-${planet.key}`} className="rounded-xl border border-indigo-700/10 bg-white/75 p-3">
              <div className="font-serif text-sm font-black text-[#7c2d12]">
                {planet.key} in House {planet.houseFromLagna}
              </div>
              <p className="mt-1 text-[11px] leading-relaxed text-stone-600">
                {PLANET_FOCUS[planet.key]} acting through: {HOUSE_FOCUS[planet.houseFromLagna]}.
              </p>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs leading-relaxed text-indigo-900/80">
          Transit is a timing layer, not a standalone promise. Final judgement should combine D1
          natal strength, Dasha, Ashtakavarga bindus, relevant Varga, house lordship and planetary
          aspects. Rahu/Ketu use Mean Node positions and have no sign lordship in this application.
        </p>
      </section>
    </div>
  );
}
