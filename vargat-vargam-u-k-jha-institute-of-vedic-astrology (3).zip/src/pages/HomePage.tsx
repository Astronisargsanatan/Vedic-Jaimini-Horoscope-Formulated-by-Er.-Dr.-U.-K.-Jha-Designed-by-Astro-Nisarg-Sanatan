import { useMemo, useState } from "react";
import {
  PLANETS,
  RASHIS,
  computeVarga,
  degWithinSign,
  formatDMS,
  houseOf,
  rashiFull,
  rashiName,
  type PlanetKey,
} from "../lib/astro";
import { calculateBirthChart, type BirthCalculation, type BirthInput } from "../lib/birthCalc";
import { placeLabel as formatPlaceLabel } from "../lib/gazetteer";
import NorthChart from "../components/NorthChart";
import PlaceSelect from "../components/PlaceSelect";
import OnlinePlaceSearch from "../components/OnlinePlaceSearch";
import ManualCoordinates from "../components/ManualCoordinates";
import { useChart } from "../state/ChartContext";

const fieldClass =
  "w-full rounded-xl border border-amber-800/20 bg-[#fffdf8] px-3 py-3 text-sm text-stone-900 outline-none transition placeholder:text-stone-400 focus:border-amber-500 focus:ring-4 focus:ring-amber-500/15";

const numInput =
  "w-full rounded-lg border border-stone-300 bg-white px-2 py-1.5 text-center font-mono text-sm text-stone-800 outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/25";

export default function HomePage({ onGoVarga }: { onGoVarga: () => void }) {
  const { chart, setField, setChartFromBirth, reset } = useChart();
  const [birth, setBirth] = useState<BirthInput>({
    fullName: "",
    date: "",
    time: "",
    locationMode: "gazetteer",
    manualCoordinateFormat: "DD",
    latitudeDirection: "N",
    longitudeDirection: "E",
    timezoneOffset: "+05:30",
  });
  const [calculation, setCalculation] = useState<BirthCalculation | null>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "error" | "success">("idle");
  const [message, setMessage] = useState("");
  const [showCorrections, setShowCorrections] = useState(false);
  const [showPayloads, setShowPayloads] = useState(false);

  const d1 = computeVarga(chart, "D1");

  const payload = useMemo(() => {
    return {
      native: {
        fullName: calculation?.input.fullName ?? birth.fullName,
        dateOfBirth: calculation?.input.date ?? birth.date,
        timeOfBirth: calculation?.input.time ?? birth.time,
        placeOfBirth: calculation?.geo.displayName ?? birth.placeLabel ?? "",
        placeOfBirthCategory: calculation?.geo.category ?? "",
      },
      geoTemporal: calculation
        ? {
            resolvedPlace: calculation.geo.displayName,
            latitude: calculation.geo.roundedLat,
            longitude: calculation.geo.roundedLon,
            timezone: calculation.geo.timezone,
            timezoneOffset: calculation.timezoneOffsetLabel,
            utc: calculation.utcDate.toISOString(),
            julianDay: Number(calculation.julianDay.toFixed(6)),
          }
        : null,
      ephemeris: {
        ayanamsha: "Lahiri / Chitrapaksha",
        rahuKetu: "Mean Nodes only; Ketu = Rahu + 180 degrees",
        nodeLordship: "NULL",
      },
      planetaryPositions: PLANETS.reduce(
        (acc, planet) => {
          const pos = chart[planet.key];
          acc[planet.key] = {
            sign: pos.sign,
            rashi: rashiName(pos.sign),
            degree: pos.deg,
            minutes: pos.min,
            seconds: pos.sec,
            motion: pos.motion ?? "D",
          };
          return acc;
        },
        {} as Record<PlanetKey, unknown>,
      ),
    };
  }, [birth, calculation, chart]);

  const clamp = (v: string, max: number) => {
    const n = Math.floor(Number(v.replace(/[^0-9]/g, "")));
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, Math.min(max, n));
  };

  const updateBirth = (field: keyof BirthInput, value: string) => {
    setBirth((current) => ({ ...current, [field]: value }));
  };

  const calculate = async () => {
    setStatus("loading");
    setMessage("Resolving place, timezone and Lahiri sidereal positions...");
    try {
      const result = await calculateBirthChart(birth);
      setCalculation(result);
      // Native birth details + chart dono ek hi jagah se pass hote hain,
      // taaki Vimshottari/Jaimini/PDF sab modules isi dataset se chalein.
      setChartFromBirth(result.chart, {
        fullName: result.input.fullName,
        date: result.input.date,
        time: result.input.time,
        place: result.geo.displayName,
        lat: result.geo.roundedLat,
        lon: result.geo.roundedLon,
        tz: `${result.geo.timezone} (${result.timezoneOffsetLabel})`,
        ayanamsha: `Lahiri (Chitrapaksha) ${result.lahiriAyanamsha.toFixed(4)}°`,
        lmt: result.lmt,
        siderealTime: result.siderealTime,
        birthUtc: result.utcDate.toISOString(),
      });
      setStatus("success");
      setMessage("Birth chart calculated and applied to the common planetary dataset.");
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Unable to calculate birth chart.");
    }
  };

  return (
    <div className="space-y-8">
      <section className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.6)] sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="font-serif text-2xl font-bold text-[#7c2d12]">
              Birth Details → Automatic Planetary Positions
            </h2>
            <p className="mt-1 max-w-3xl text-sm text-stone-600">
              Enter only four mandatory fields. The system resolves place coordinates, timezone,
              UTC, Lahiri Chitrapaksha ayanamsha, Lagna and 9 Grahas, then updates every module
              from one common dataset.
            </p>
          </div>
          <button
            onClick={() => {
              reset();
              setCalculation(null);
              setStatus("idle");
              setMessage("Sample chart restored.");
            }}
            className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-sm font-semibold text-stone-600 transition hover:bg-stone-50"
          >
            Reset sample
          </button>
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <label className="block">
            <span className="text-[11px] font-bold uppercase tracking-[0.16em] text-amber-700">
              1. Full Name
            </span>
            <input
              value={birth.fullName}
              onChange={(e) => updateBirth("fullName", e.target.value)}
              placeholder="Full Name"
              className={`${fieldClass} mt-1.5`}
            />
          </label>

          <label className="block">
            <span className="text-[11px] font-bold uppercase tracking-[0.16em] text-amber-700">
              2. Date of Birth (DD/MM/YYYY)
            </span>
            <input
              value={birth.date}
              onChange={(e) => updateBirth("date", e.target.value)}
              placeholder="23/04/1990"
              className={`${fieldClass} mt-1.5 font-mono`}
            />
          </label>

          <label className="block">
            <span className="text-[11px] font-bold uppercase tracking-[0.16em] text-amber-700">
              3. Time of Birth (HH:MM:SS)
            </span>
            <input
              value={birth.time}
              onChange={(e) => updateBirth("time", e.target.value)}
              placeholder="14:35:20"
              className={`${fieldClass} mt-1.5 font-mono`}
            />
          </label>

          <div className="md:col-span-2">
            <div className="mb-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <span className="text-[11px] font-bold uppercase tracking-[0.16em] text-amber-700">
                4. Birth Location Method
              </span>
              <div className="grid w-full grid-cols-1 rounded-xl border border-amber-800/20 bg-amber-50 p-1 min-[430px]:grid-cols-3 sm:w-auto">
                <button
                  type="button"
                  onClick={() => updateBirth("locationMode", "gazetteer")}
                  className={`rounded-lg px-2 py-2 text-[10px] font-bold transition sm:px-3 sm:text-xs ${
                    birth.locationMode === "gazetteer"
                      ? "bg-[#7c2d12] text-amber-50 shadow"
                      : "text-stone-600 hover:bg-white"
                  }`}
                >
                  1. Offline Database
                </button>
                <button
                  type="button"
                  onClick={() => updateBirth("locationMode", "online")}
                  className={`rounded-lg px-2 py-2 text-[10px] font-bold transition sm:px-3 sm:text-xs ${
                    birth.locationMode === "online"
                      ? "bg-sky-800 text-white shadow"
                      : "text-stone-600 hover:bg-white"
                  }`}
                >
                  2. Online Search
                </button>
                <button
                  type="button"
                  onClick={() => updateBirth("locationMode", "manual")}
                  className={`rounded-lg px-2 py-2 text-[10px] font-bold transition sm:px-3 sm:text-xs ${
                    birth.locationMode === "manual"
                      ? "bg-indigo-800 text-white shadow"
                      : "text-stone-600 hover:bg-white"
                  }`}
                >
                  3. Manual Coordinates
                </button>
              </div>
            </div>

            {birth.locationMode === "manual" ? (
              <ManualCoordinates value={birth} onChange={updateBirth} />
            ) : birth.locationMode === "online" ? (
              <OnlinePlaceSearch
                selected={birth.onlinePlaceName}
                onSelect={(place) => {
                  setBirth((current) => ({
                    ...current,
                    onlinePlaceName: place.displayName,
                    onlineLatitude: place.latitude,
                    onlineLongitude: place.longitude,
                  }));
                  setStatus("idle");
                  setMessage("");
                }}
              />
            ) : (
              <PlaceSelect
                value={birth}
                onSelect={(place) => {
                  setBirth((current) => ({
                    ...current,
                    placeId: place.id,
                    placeLabel: formatPlaceLabel(place),
                  }));
                  if (status === "error") {
                    setStatus("idle");
                    setMessage("");
                  }
                }}
              />
            )}
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            onClick={calculate}
            disabled={status === "loading"}
            className="rounded-2xl bg-[#7c2d12] px-6 py-3 font-serif text-lg font-bold text-amber-50 transition hover:bg-[#9a3412] disabled:cursor-wait disabled:opacity-60"
          >
            {status === "loading" ? "Calculating..." : "Calculate Horoscope"}
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            disabled={!calculation}
            className="rounded-2xl border border-[#7c2d12] bg-white px-6 py-3 font-serif text-lg font-bold text-[#7c2d12] transition hover:bg-amber-50 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Download (PDF)
          </button>
          <span
            className={`text-sm ${
              status === "error"
                ? "text-rose-700"
                : status === "success"
                  ? "text-emerald-700"
                  : "text-stone-500"
            }`}
          >
            {message || "Default timezone is IST; foreign places use resolved local timezone/DST."}
          </span>
        </div>

        {calculation && (
          <div className="mt-5 grid gap-3 rounded-2xl border border-emerald-700/20 bg-emerald-50/70 p-4 text-xs text-emerald-950 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <div className="font-bold uppercase tracking-wider text-emerald-700">Resolved Place</div>
              <div className="mt-1 line-clamp-2">{calculation.geo.displayName}</div>
            </div>
            <div>
              <div className="font-bold uppercase tracking-wider text-emerald-700">Coordinates</div>
              <div className="mt-1 font-mono">
                {calculation.geo.roundedLat.toFixed(2)}°, {calculation.geo.roundedLon.toFixed(2)}°
              </div>
            </div>
            <div>
              <div className="font-bold uppercase tracking-wider text-emerald-700">Timezone → UTC</div>
              <div className="mt-1 font-mono">
                {calculation.geo.timezone} · {calculation.timezoneOffsetLabel}
              </div>
              <div className="font-mono text-[10px] text-emerald-800/70">
                {calculation.utcDate.toISOString()}
              </div>
            </div>
            <div>
              <div className="font-bold uppercase tracking-wider text-emerald-700">Lahiri Ayanamsha</div>
              <div className="mt-1 font-mono">{calculation.lahiriAyanamsha.toFixed(6)}°</div>
              <div className="font-mono text-[10px] text-emerald-800/70">
                JD {calculation.julianDay.toFixed(5)}
              </div>
            </div>
          </div>
        )}

        {calculation && (
          <div className="mt-3 grid gap-3 rounded-2xl border border-indigo-700/20 bg-indigo-50/70 p-4 text-xs text-indigo-950 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <div className="font-bold uppercase tracking-wider text-indigo-700">
                Local Mean Time
              </div>
              <div className="mt-1 font-mono">{calculation.lmt}</div>
              <div className="font-mono text-[10px] text-indigo-800/70">
                corr {calculation.lmtCorrectionMinutes >= 0 ? "+" : ""}
                {calculation.lmtCorrectionMinutes.toFixed(2)} min
              </div>
            </div>
            <div>
              <div className="font-bold uppercase tracking-wider text-indigo-700">Sidereal Time</div>
              <div className="mt-1 font-mono">{calculation.siderealTime}</div>
              <div className="font-mono text-[10px] text-indigo-800/70">
                RAMC {calculation.ramc.toFixed(4)}°
              </div>
            </div>
            <div>
              <div className="font-bold uppercase tracking-wider text-indigo-700">MC (Dasama)</div>
              <div className="mt-1 font-mono">
                {calculation.mcNirayana.sign}. {rashiName(calculation.mcNirayana.sign)}
              </div>
              <div className="font-mono text-[10px] text-indigo-800/70">
                {formatDMS(calculation.mcNirayana)}
              </div>
            </div>
            <div>
              <div className="font-bold uppercase tracking-wider text-indigo-700">Obliquity ε</div>
              <div className="mt-1 font-mono">{calculation.obliquity.toFixed(6)}°</div>
              <div className="font-mono text-[10px] text-indigo-800/70">
                true obliquity of date
              </div>
            </div>
          </div>
        )}
      </section>

      <section className="rounded-3xl border border-amber-800/15 bg-white/80 p-5 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.6)] sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-serif text-2xl font-bold text-[#7c2d12]">
              Computed Planetary Positions
            </h2>
            <p className="mt-1 text-sm text-stone-600">
              Lahiri Nirayana positions. Rahu/Ketu are Mean Nodes and their lordship is null.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowCorrections((v) => !v)}
            className="rounded-xl border border-amber-800/20 bg-amber-50 px-4 py-2 text-sm font-semibold text-amber-900 hover:bg-amber-100"
          >
            {showCorrections ? "Hide manual correction" : "Advanced manual correction"}
          </button>
        </div>

        <div className="mt-5 overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b border-amber-800/20 text-left text-[11px] uppercase tracking-[0.16em] text-amber-700">
                <th className="py-2 pr-3">Planet</th>
                <th className="py-2 pr-3">Rashi</th>
                <th className="py-2 pr-3">Degree</th>
                <th className="py-2 pr-3">Minutes</th>
                <th className="py-2 pr-3">Seconds</th>
                <th className="py-2 pr-3 text-center">Motion</th>
                <th className="py-2 text-right">Abs °</th>
              </tr>
            </thead>
            <tbody>
              {PLANETS.map((p) => {
                const pos = chart[p.key as PlanetKey];
                const abs = (pos.sign - 1) * 30 + degWithinSign(pos);
                return (
                  <tr key={p.key} className="border-b border-stone-200/70 last:border-0">
                    <td className="py-2 pr-3 font-semibold text-stone-800">{p.label}</td>
                    <td className="py-2 pr-3 text-stone-700">
                      {pos.sign}. {rashiName(pos.sign)}
                    </td>
                    <td className="py-2 pr-3 font-mono text-stone-700">{pos.deg}°</td>
                    <td className="py-2 pr-3 font-mono text-stone-700">{pos.min}′</td>
                    <td className="py-2 pr-3 font-mono text-stone-700">{pos.sec}″</td>
                    <td className="py-2 pr-3 text-center">
                      <span
                        className={`rounded-full px-2 py-0.5 font-mono text-xs font-bold ${
                          pos.motion === "R"
                            ? "bg-rose-100 text-rose-700"
                            : "bg-emerald-100 text-emerald-700"
                        }`}
                      >
                        {pos.motion ?? "D"}
                      </span>
                    </td>
                    <td className="py-2 text-right font-mono text-xs text-stone-500">
                      {abs.toFixed(4)}°
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {showCorrections && (
          <div className="mt-5 overflow-x-auto rounded-2xl border border-amber-800/15 bg-amber-50/40 p-3">
            <div className="mb-2 text-xs font-semibold text-amber-900">
              Manual correction only. Use this if an external Panchanga/ephemeris value must be
              matched exactly.
            </div>
            <table className="w-full min-w-[650px] border-separate border-spacing-y-1.5">
              <tbody>
                {PLANETS.map((p) => {
                  const pos = chart[p.key as PlanetKey];
                  return (
                    <tr key={p.key} className="bg-[#fdfaf4]">
                      <td className="rounded-l-xl px-3 py-2 text-sm font-semibold text-stone-800">
                        {p.label}
                      </td>
                      <td className="px-2 py-2">
                        <select
                          value={pos.sign}
                          onChange={(e) => setField(p.key, "sign", Number(e.target.value))}
                          className="w-full rounded-lg border border-stone-300 bg-white px-2 py-1.5 text-sm text-stone-800 outline-none focus:border-amber-500"
                        >
                          {RASHIS.map((r) => (
                            <option key={r.num} value={r.num}>
                              {r.num}. {r.name} ({r.en})
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-2 py-2">
                        <input
                          value={pos.deg}
                          onChange={(e) => setField(p.key, "deg", clamp(e.target.value, 29))}
                          inputMode="numeric"
                          className={numInput}
                        />
                      </td>
                      <td className="px-2 py-2">
                        <input
                          value={pos.min}
                          onChange={(e) => setField(p.key, "min", clamp(e.target.value, 59))}
                          inputMode="numeric"
                          className={numInput}
                        />
                      </td>
                      <td className="px-2 py-2">
                        <input
                          value={pos.sec}
                          onChange={(e) => setField(p.key, "sec", clamp(e.target.value, 59))}
                          inputMode="numeric"
                          className={numInput}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="rounded-3xl border border-amber-800/15 bg-white/80 p-5 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.6)] sm:p-6">
        <h2 className="font-serif text-2xl font-bold text-[#7c2d12]">
          D1 — Main Horoscope / Rashi Chart
        </h2>
        <p className="mt-1 text-sm text-stone-600">
          North Indian style. Numbers in the corners are Rashi numbers; Lagna is the top-centre
          house.
        </p>

        <div className="mt-5 grid gap-6 lg:grid-cols-[minmax(0,380px)_1fr]">
          <div className="rounded-2xl border border-amber-800/10 bg-[#fffdf8] p-3">
            <NorthChart signs={d1} title="D1 · Rashi (Birth Chart)" />
            <div className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-center text-sm">
              <span className="font-semibold text-amber-800">Lagna:</span>{" "}
              <span className="text-stone-700">
                {rashiFull(chart.Lagna.sign)} · {formatDMS(chart.Lagna)}
              </span>
            </div>
          </div>

          <div>
            <h3 className="font-serif text-lg font-bold text-[#7c2d12]">
              Quick Summary · Planetary Positions
            </h3>
            <div className="mt-3 overflow-x-auto">
              <table className="w-full min-w-[470px] text-sm">
                <thead>
                  <tr className="border-b border-amber-800/20 text-left text-[11px] uppercase tracking-[0.14em] text-amber-700">
                    <th className="py-2 pr-3">Planet</th>
                    <th className="py-2 pr-3">Rashi</th>
                    <th className="py-2 pr-3">Longitude</th>
                    <th className="py-2 pr-3 text-center">House</th>
                    <th className="py-2 pr-3 text-center">Motion</th>
                  </tr>
                </thead>
                <tbody>
                  {PLANETS.map((p) => {
                    const pos = chart[p.key as PlanetKey];
                    return (
                      <tr key={p.key} className="border-b border-stone-200/70 last:border-0">
                        <td className="py-2 pr-3 font-semibold text-stone-800">
                          {p.short} · {p.label.split(" ")[0]}
                        </td>
                        <td className="py-2 pr-3 text-stone-700">
                          {pos.sign}. {rashiName(pos.sign)}
                        </td>
                        <td className="py-2 pr-3 font-mono text-xs text-stone-600">
                          {formatDMS(pos)}
                        </td>
                        <td className="py-2 pr-3 text-center font-mono text-stone-700">
                          {houseOf(pos.sign, chart.Lagna.sign)}
                        </td>
                        <td className="py-2 pr-3 text-center font-mono text-xs text-stone-500">
                          {pos.motion ?? "D"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <button
              onClick={onGoVarga}
              className="mt-5 w-full rounded-2xl bg-[#7c2d12] px-5 py-3 font-serif text-lg font-bold text-amber-50 transition hover:bg-[#9a3412] active:scale-[0.99]"
            >
              View Vargat Vargam → D2 · D3 · D4 · D5 · D6 · D8 · D9 · D10
            </button>
          </div>
        </div>
      </section>

      <section className="rounded-3xl border border-stone-200 bg-[#fffdf8] p-4 shadow-sm sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="font-serif text-lg font-bold text-[#7c2d12]">
              Developer Data · JSON Payloads
            </h3>
            <p className="mt-0.5 text-xs text-stone-500">
              Technical JSON is hidden by default and is not required for horoscope reading.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowPayloads((value) => !value)}
            aria-expanded={showPayloads}
            className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-xs font-bold text-stone-700 transition hover:border-amber-500 hover:bg-amber-50"
          >
            {showPayloads ? "Hide JSON Payloads ↑" : "Show JSON Payloads ↓"}
          </button>
        </div>

        {showPayloads && (
          <div className="mt-4 space-y-4">
            <div>
              <h4 className="font-serif text-sm font-bold text-[#7c2d12]">
                Home Page Payload JSON Contract
              </h4>
              <pre className="mt-2 max-h-80 overflow-auto rounded-2xl bg-stone-950 p-4 text-xs leading-relaxed text-amber-50">
                {JSON.stringify(payload, null, 2)}
              </pre>
            </div>

            {calculation && (
              <div>
                <h4 className="font-serif text-sm font-bold text-[#7c2d12]">
                  Kundali Core Payload · ALENA_ENGINE_V3
                </h4>
                <p className="mt-1 text-xs text-stone-500">
                  native_info · astronomical_elements · kundali_houses (planets + arudhas) ·
                  planetary_table with Char Karaka, lordship and motion
                </p>
                <pre className="mt-2 max-h-[32rem] overflow-auto rounded-2xl bg-stone-950 p-4 text-xs leading-relaxed text-emerald-50">
                  {JSON.stringify(calculation.kundaliPayload, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}