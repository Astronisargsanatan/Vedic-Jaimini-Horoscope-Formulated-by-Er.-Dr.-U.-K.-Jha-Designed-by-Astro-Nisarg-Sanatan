import { useMemo } from "react";
import type { ReactNode } from "react";
import { CalendarDays, Clock3, MoonStar, Orbit } from "lucide-react";
import { computePanchang } from "../lib/panchang";
import { useChart } from "../state/ChartContext";

type Detail = { label: string; hindi: string; value: string | number; note?: string };

function DetailGrid({ title, subtitle, icon, details }: { title: string; subtitle: string; icon: ReactNode; details: Detail[] }) {
  return (
    <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.5)]">
      <header className="flex items-start gap-3 border-b border-amber-800/10 bg-amber-50 px-4 py-4 sm:px-6">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#7c2d12] text-amber-50">{icon}</span>
        <div>
          <h2 className="font-serif text-lg font-black text-[#7c2d12] sm:text-xl">{title}</h2>
          <p className="text-xs text-stone-500">{subtitle}</p>
        </div>
      </header>
      <div className="grid gap-px bg-stone-200 sm:grid-cols-2 lg:grid-cols-3">
        {details.map((detail) => (
          <div key={detail.label} className="min-w-0 bg-white p-4">
            <div className="text-[9px] font-bold uppercase tracking-[0.14em] text-amber-700">
              {detail.hindi} · {detail.label}
            </div>
            <div className="mt-1 break-words font-serif text-base font-black text-stone-900 sm:text-lg">
              {detail.value}
            </div>
            {detail.note && <p className="mt-1 text-[10px] leading-relaxed text-stone-500">{detail.note}</p>}
          </div>
        ))}
      </div>
    </section>
  );
}

export default function PanchangPage() {
  const { chart, native } = useChart();
  const p = useMemo(() => computePanchang(chart, native), [chart, native]);

  return (
    <div className="space-y-6">
      <header className="rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-5 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">Birth Panchanga · Avakahada Chakra</div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">Panchang</h1>
        <p className="mt-3 max-w-4xl text-sm leading-relaxed text-stone-600 sm:text-base">
          Tithi, Vara, Nakshatra, Yoga, Karana, calendar measures, astronomical values and complete
          Avakahada Chakra derived from the Home birth chart. Sunrise and sunset require calculated
          birth coordinates.
        </p>
        {!native?.birthUtc && (
          <div className="mt-4 rounded-xl border-2 border-amber-500 bg-amber-50 px-4 py-3 text-xs text-amber-900">
            Calculate Birth Details on Home first for the correct birth date, location, sunrise and sunset. Current values use the sample chart/reference time.
          </div>
        )}

        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {[
            ["Tithi", p.tithi], ["Vara", p.vara], ["Nakshatra", `${p.nakshatra} · Pada ${p.nakshatraPada}`],
            ["Yoga", p.yoga], ["Karana", p.karana],
          ].map(([label, value]) => (
            <div key={label} className="rounded-2xl border border-amber-800/15 bg-white/80 p-3">
              <div className="text-[9px] font-bold uppercase tracking-wider text-amber-700">{label}</div>
              <div className="mt-1 font-serif text-base font-black text-[#7c2d12]">{value}</div>
            </div>
          ))}
        </div>
      </header>

      <DetailGrid
        title="Samvatsara & Calendar Details"
        subtitle="संवत्सर एवं काल-मान विवरण"
        icon={<CalendarDays className="h-5 w-5" />}
        details={[
          { label: "Samvatsara", hindi: "संवत्सर", value: p.samvatsara, note: "60-year cycle; Gregorian-year anchor" },
          { label: "Vikram Samvat", hindi: "विक्रम संवत्", value: p.vikramSamvat },
          { label: "Shaka Samvat", hindi: "शक संवत्", value: p.shakaSamvat },
          { label: "Masa", hindi: "मास", value: p.masa },
          { label: "Paksha", hindi: "पक्ष", value: p.paksha },
          { label: "Ayana", hindi: "अयन", value: p.ayana },
          { label: "Gola", hindi: "गोल", value: p.gola },
          { label: "Ritu", hindi: "ऋतु", value: p.ritu },
        ]}
      />

      <DetailGrid
        title="Primary Panchanga Elements"
        subtitle="प्राथमिक पञ्चाङ्ग विवरण"
        icon={<MoonStar className="h-5 w-5" />}
        details={[
          { label: "Vara", hindi: "वार", value: p.vara },
          { label: "Tithi", hindi: "तिथि", value: p.tithi, note: `Tithi sequence number ${p.tithiNumber}/30` },
          { label: "Nakshatra", hindi: "नक्षत्र", value: `${p.nakshatra}, Pada ${p.nakshatraPada}` },
          { label: "Yoga", hindi: "योग", value: p.yoga },
          { label: "Karana", hindi: "करण", value: p.karana },
        ]}
      />

      <DetailGrid
        title="Astronomical & Epoch Data"
        subtitle="खगोलीय एवं साम्पातिक मान"
        icon={<Orbit className="h-5 w-5" />}
        details={[
          { label: "Suryodaya", hindi: "सूर्योदय", value: p.sunrise },
          { label: "Suryasta", hindi: "सूर्यास्त", value: p.sunset },
          { label: "Sampatika Kala", hindi: "साम्पातिक काल", value: p.sampatikaKala },
          { label: "Ayanamsha", hindi: "अयनांश", value: p.ayanamsha },
          { label: "Divamana", hindi: "दिवामान", value: p.divamana },
          { label: "Ratrimana", hindi: "रात्रिमान", value: p.ratrimana },
        ]}
      />

      <DetailGrid
        title="Avakahada Chakra Details"
        subtitle="अवकहडा चक्र विवरण"
        icon={<Clock3 className="h-5 w-5" />}
        details={[
          { label: "Varna", hindi: "वर्ण", value: p.varna },
          { label: "Tattva", hindi: "तत्व", value: p.tattva },
          { label: "Hamsaka", hindi: "हंसक", value: p.hamsaka },
          { label: "Gana", hindi: "गण", value: p.gana },
          { label: "Yoni", hindi: "योनि", value: p.yoni },
          { label: "Yunja", hindi: "युञ्ज", value: p.yunja },
          { label: "Nadi", hindi: "नाडी", value: p.nadi },
          { label: "Rajju", hindi: "रज्जु", value: p.rajju },
          { label: "Rashi", hindi: "राशि", value: p.rashi },
          { label: "Rashisha", hindi: "राशीश", value: p.rashisha },
          { label: "Rashi Akshara", hindi: "राश्यक्षर", value: p.rashiAkshara },
          { label: "Nakshatra Akshara", hindi: "नक्षत्राक्षर", value: p.nakshatraSyllables },
          { label: "Name Syllable", hindi: "नामाक्षर", value: p.nameSyllable },
          { label: "Paya", hindi: "पाय", value: p.paya },
          { label: "Vashya", hindi: "वश्य", value: p.vashya },
        ]}
      />
    </div>
  );
}
