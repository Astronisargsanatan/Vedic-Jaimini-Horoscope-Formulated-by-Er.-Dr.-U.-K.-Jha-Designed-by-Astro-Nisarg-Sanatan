import GuruVandana from "../components/GuruVandana";
import DevotionalLibrary from "../components/DevotionalLibrary";

export default function DevotionalPage() {
  return (
    <main className="space-y-6">
      <header className="rounded-3xl border border-amber-800/15 bg-white/80 px-5 py-6 shadow-sm sm:px-8 sm:py-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.24em] text-amber-700">
          Sacred Opening · मंगलाचरण
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Devotional
        </h1>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-stone-600 sm:text-base">
          Institute के स्तोत्र, वन्दना और मंगलाचरण को calculation modules से अलग, एक शांत और
          सुव्यवस्थित स्थान पर प्रस्तुत किया गया है।
        </p>
      </header>

      <nav className="flex flex-wrap gap-2 rounded-2xl border border-amber-800/15 bg-white/70 p-2">
        <a
          href="#guru-vandana"
          className="rounded-xl bg-[#7c2d12] px-4 py-2 text-xs font-bold text-amber-50"
        >
          Guru Vandana
        </a>
        <a
          href="#sanatan-library"
          className="rounded-xl border border-amber-800/20 bg-white px-4 py-2 text-xs font-bold text-[#7c2d12] transition hover:bg-amber-50"
        >
          Sanatan Literature Collection
        </a>
      </nav>

      <div id="guru-vandana" className="scroll-mt-24">
        <GuruVandana />
      </div>

      <div id="sanatan-library" className="scroll-mt-24">
        <DevotionalLibrary />
      </div>
    </main>
  );
}