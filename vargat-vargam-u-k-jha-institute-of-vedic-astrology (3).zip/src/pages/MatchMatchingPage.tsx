import { useMemo, useState } from "react";
import { computeSpousePrediction, type SpouseCategory } from "../lib/spouse";
import { rashiFull, rashiName } from "../lib/astro";
import { useChart } from "../state/ChartContext";

const CATEGORY_ORDER: SpouseCategory[] = [
  "Parashari 7th",
  "Jaimini DK",
  "Jaimini UL (A7)",
  "Navamsa D9",
  "Dwadashamsa D12",
  "Ashtakavarga",
  "Karakamsa",
  "Combination",
];

export default function MatchMatchingPage() {
  const { chart } = useChart();
  const result = useMemo(() => computeSpousePrediction(chart), [chart]);
  const [copied, setCopied] = useState(false);

  const maxScore = result.tally[0]?.score ?? 1;
  const categorySummary = CATEGORY_ORDER.map((category) => {
    const rules = result.rules.filter((rule) => rule.category === category);
    const score = rules.reduce((sum, rule) => sum + rule.weight, 0);
    const topVotes = rules.filter((rule) => rule.candidateSign === result.topSign).length;
    return { category, rules: rules.length, score, topVotes };
  });

  const copyReport = async () => {
    const lines = [
      "ALENA ENGINE · MATCH-MATCHING OVERALL SUMMARY",
      `Lagna: ${rashiFull(chart.Lagna.sign)}`,
      `7th sign: ${rashiName(result.seventhSign)} | DK: ${result.dkPlanet} (${rashiName(result.dkSign)}) | UL: ${rashiName(result.ulSign)}`,
      result.topSign ? `Most likely spouse rashi: ${rashiFull(result.topSign)} (${result.topScore} pts)` : "",
      "",
      "CANDIDATE RANKING:",
      ...result.tally.map(
        (item, index) =>
          `${index + 1}. ${item.sign}. ${rashiName(item.sign)} — ${item.score} pts, ${item.rules.length} repetitions`,
      ),
      "",
      "CATEGORY SUMMARY:",
      ...categorySummary.map((item) => `${item.category}: ${item.rules} rules, ${item.score} max weight, ${item.topVotes} top-rashi votes`),
    ];
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="space-y-6">
      <header className="rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-6 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">
          Alena Engine · Spouse Ascendant / Moon-Sign Determination
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Match – Matching
        </h1>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-stone-600 sm:text-base">
          47 सूक्ष्म नियमों को internal scoring engine में evaluate किया गया है। यहाँ केवल उनका
          Overall Summary, candidate ranking और category-level conclusion दिखाया गया है; individual
          rule-by-rule विवरण प्रदर्शित नहीं किया गया है।
        </p>

        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <MetaCard label="7वाँ भाव" value={rashiName(result.seventhSign)} tone="amber" />
          <MetaCard label="दारा कारक (DK)" value={`${result.dkPlanet} · ${rashiName(result.dkSign)}`} tone="rose" />
          <MetaCard label="उपपद (UL / A7)" value={rashiName(result.ulSign)} tone="purple" />
          <MetaCard label="नवांश 7वाँ" value={rashiName(result.d9.Lagna)} tone="indigo" />
        </div>
      </header>

      {/* TOP PREDICTION */}
      {result.topSign && (
        <section className="overflow-hidden rounded-3xl border-2 border-emerald-500/50 bg-gradient-to-r from-emerald-50 to-amber-50 p-6 shadow-[0_14px_42px_-28px_rgba(5,150,105,0.5)]">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-emerald-700">
                सर्वाधिक संभावित जीवनसाथी-राशि
              </div>
              <div className="mt-1 font-serif text-4xl font-black text-[#7c2d12]">
                {rashiFull(result.topSign)}
              </div>
              <div className="mt-1 text-sm text-stone-600">
                47 नियमों में से उच्चतम स्कोर: <strong>{result.topScore} अंक</strong>
              </div>
            </div>
            <button
              type="button"
              onClick={copyReport}
              className="rounded-xl bg-[#7c2d12] px-4 py-2.5 text-sm font-bold text-amber-50 transition hover:bg-[#9a3412]"
            >
              {copied ? "Summary copied" : "Copy Overall Summary"}
            </button>
          </div>

          {/* Ranked candidate bars */}
          <div className="mt-5 space-y-2">
            {result.tally.slice(0, 6).map((t, i) => (
              <div key={t.sign} className="flex items-center gap-3">
                <span className="w-8 text-right font-mono text-xs text-stone-400">#{i + 1}</span>
                <span className="w-28 shrink-0 font-serif text-sm font-bold text-stone-800">
                  {t.sign}. {rashiName(t.sign)}
                </span>
                <div className="h-3 flex-1 overflow-hidden rounded-full bg-white/70 ring-1 ring-stone-200">
                  <div
                    className={`h-full rounded-full ${i === 0 ? "bg-emerald-600" : "bg-amber-400"}`}
                    style={{ width: `${(t.score / maxScore) * 100}%` }}
                  />
                </div>
                <span className="w-20 text-right font-mono text-xs font-bold text-stone-600">
                  {t.score} pts · {t.rules.length}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      <div className="overflow-x-auto rounded-3xl border border-amber-800/15 bg-white/85 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.5)]">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-amber-800/20 bg-amber-50 text-left text-[11px] uppercase tracking-[0.12em] text-amber-800">
              <th className="px-3 py-3 text-center">Rank</th>
              <th className="px-3 py-3">Candidate Rashi</th>
              <th className="px-3 py-3 text-center">Weighted Score</th>
              <th className="px-3 py-3 text-center">Repetition Count</th>
              <th className="px-3 py-3">Supporting Rule Numbers</th>
            </tr>
          </thead>
          <tbody>
            {result.tally.map((item, index) => (
              <tr key={item.sign} className={`border-b border-stone-200/70 last:border-0 ${index === 0 ? "bg-emerald-50/70" : ""}`}>
                <td className="px-3 py-2 text-center font-mono text-xs text-stone-500">#{index + 1}</td>
                <td className="px-3 py-2 font-serif font-bold text-[#7c2d12]">{item.sign}. {rashiName(item.sign)}</td>
                <td className="px-3 py-2 text-center font-mono font-bold text-emerald-800">{item.score}</td>
                <td className="px-3 py-2 text-center font-mono">{item.rules.length}</td>
                <td className="px-3 py-2 font-mono text-xs text-stone-600">{item.rules.join(", ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <section className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
        <h2 className="font-serif text-xl font-black text-[#7c2d12]">Category-Level Summary</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {categorySummary.map((item) => (
            <div key={item.category} className="rounded-2xl border border-stone-200 bg-[#fdfaf4] p-4">
              <div className="text-[9px] font-bold uppercase tracking-wide text-amber-700">{item.category}</div>
              <div className="mt-2 font-mono text-lg font-black text-[#7c2d12]">{item.topVotes} top votes</div>
              <p className="mt-1 text-xs text-stone-500">{item.rules} internal rules · {item.score} max weight</p>
            </div>
          ))}
        </div>
      </section>

      <div className="rounded-2xl border border-indigo-700/15 bg-indigo-50/70 px-5 py-3 text-xs leading-relaxed text-indigo-900">
        <strong>विधि:</strong> हर नियम एक candidate राशि पर भार (weight) अनुसार मत देता है।
        सभी 47 मतों को जोड़कर उच्चतम स्कोर वाली राशि सबसे संभावित जीवनसाथी-राशि बनती है। यह
        Alena Engine का पाराशर + जैमिनि + नवांश + द्वादशांश + अष्टकवर्ग समन्वित निष्कर्ष है।
      </div>
    </div>
  );
}

function MetaCard({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "amber" | "rose" | "purple" | "indigo";
}) {
  const tones: Record<string, string> = {
    amber: "border-amber-800/15 bg-white/80 text-amber-800",
    rose: "border-rose-300/40 bg-rose-50 text-rose-800",
    purple: "border-purple-300/40 bg-purple-50 text-purple-800",
    indigo: "border-indigo-300/40 bg-indigo-50 text-indigo-800",
  };
  return (
    <div className={`rounded-2xl border px-4 py-3 ${tones[tone]}`}>
      <div className="text-[10px] font-bold uppercase tracking-wider opacity-80">{label}</div>
      <div className="mt-1 font-serif text-lg font-black">{value}</div>
    </div>
  );
}
