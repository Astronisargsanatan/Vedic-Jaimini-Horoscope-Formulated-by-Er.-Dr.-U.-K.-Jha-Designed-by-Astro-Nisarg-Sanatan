import { useMemo, useState } from "react";
import { Copy, Sparkles, BookOpen, Compass, Info, Check, Map } from "lucide-react";
import { useChart } from "../state/ChartContext";
import { computeJaiminiCharKaraka } from "../lib/jaimini";
import {
  arudhaByHouse,
  computeArudhaPadas,
  formatArudhaReport,
  relationLabel,
} from "../lib/arudha";
import { computeVarga, rashiName } from "../lib/astro";
import NorthChart from "../components/NorthChart";
import CharaDashaSection from "../components/CharaDashaSection";
import MandookDashaSection from "../components/MandookDashaSection";

export default function JaiminiPage() {
  const { chart } = useChart();
  const [copied, setCopied] = useState(false);
  const [arudhaCopied, setArudhaCopied] = useState(false);

  // Compute 7 Char Karakas automatically from shared chart state
  const karakaResults = useMemo(() => computeJaiminiCharKaraka(chart), [chart]);

  // Bhaveshat Bhavam → Arudha of Evolution (AL … A12)
  const arudhaResults = useMemo(() => computeArudhaPadas(chart), [chart]);
  const arudhaHouses = useMemo(() => arudhaByHouse(arudhaResults), [arudhaResults]);
  const d1Signs = useMemo(() => computeVarga(chart, "D1"), [chart]);

  const copyReport = async () => {
    const lines: string[] = [
      "==================================================",
      "   जैमिनि उपदेश सूत्रम् (JAIMINI UPDESHA SUTRAM)   ",
      "      7 CHAR KARAKA (सप्त चरकारक) SCHEME        ",
      "==================================================",
      "",
      "--- SUMMARY OF CHAR KARAKAS (DESCENDING ORDER) ---",
    ];

    karakaResults.forEach((res) => {
      lines.push(
        `${res.rank}. ${res.karaka.devanagari} (${res.karaka.role}) : ${res.label} -> Traversed: ${res.traversedDMS} (Navamsha ${res.navamshaNum}, Local: ${res.localDMS})`,
      );
    });

    lines.push("");
    lines.push("--- MATHEMATICAL BREAKDOWN PER PLANET ---");
    karakaResults.forEach((res) => {
      lines.push(`• Planet: ${res.label}`);
      lines.push(`  - Local Position: ${res.localDMS}`);
      lines.push(`  - Navamsha No.: ${res.navamshaNum} (Start: ${res.navamshaStartDMS})`);
      lines.push(`  - Traversed Arc: ${res.traversedDMS} (${res.traversedSeconds} seconds)`);
      lines.push(`  - Assigned Karaka: ${res.karaka.devanagari} (${res.karaka.sanskrit})`);
      lines.push(`  - Role Focus: ${res.karaka.english}`);
      lines.push("");
    });

    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const copyArudhaReport = async () => {
    try {
      await navigator.clipboard.writeText(formatArudhaReport(arudhaResults, chart.Lagna.sign));
      setArudhaCopied(true);
      setTimeout(() => setArudhaCopied(false), 2000);
    } catch {
      setArudhaCopied(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Jaimini module switchboard — shown first on opening the section. */}
      <nav className="sticky top-[62px] z-20 flex flex-wrap gap-2 rounded-2xl border border-amber-800/20 bg-[#fffaf0]/95 p-2 shadow-lg backdrop-blur">
        <a
          href="#char-dasha"
          className="rounded-xl bg-[#7c2d12] px-4 py-2.5 text-xs font-bold text-amber-50 transition hover:bg-[#9a3412]"
        >
          Char Dasha
        </a>
        <a
          href="#arudha-of-evolution"
          className="rounded-xl border border-teal-700/20 bg-teal-50 px-4 py-2.5 text-xs font-bold text-teal-900 transition hover:bg-teal-100"
        >
          Arudh System
        </a>
        <a
          href="#char-karak"
          className="rounded-xl border border-indigo-700/20 bg-indigo-50 px-4 py-2.5 text-xs font-bold text-indigo-900 transition hover:bg-indigo-100"
        >
          Char Karak
        </a>
        <a
          href="#mandook-dasha"
          className="rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-xs font-bold text-stone-700 transition hover:bg-stone-50"
        >
          Mandook Dasha
        </a>
      </nav>

      <CharaDashaSection />

      {/* HEADER BANNER */}
      <header className="relative overflow-hidden rounded-3xl border border-amber-800/20 bg-gradient-to-br from-[#fffaf0] via-[#fbf3e4] to-[#f5e5d3] p-6 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-amber-300/20 blur-3xl" />
        <div className="relative">
          <div className="inline-flex items-center gap-2 rounded-full border border-amber-700/30 bg-amber-100/90 px-3.5 py-1 text-xs font-bold uppercase tracking-[0.2em] text-[#7c2d12]">
            <Sparkles className="h-3.5 w-3.5 text-amber-700" />
            Vedic Jaimini Jyotisha
          </div>

          <h1 className="mt-3 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
            जैमिनि उपदेश सूत्रम्
            <span className="mt-1 block font-serif text-xl font-bold text-[#4a2511] sm:text-2xl">
              Jaimini Updesha Sutram — Char Karaka · Arudha of Evolution
            </span>
          </h1>

          <p className="mt-3 max-w-3xl text-sm leading-relaxed text-stone-700 sm:text-base">
            In Maharishi Jaimini&rsquo;s classical system, the 7 Char Karakas (सप्त चरकारक) are determined by calculating the exact <span className="font-semibold text-[#7c2d12]">Navamsha Traversed Longitude</span> ($D^\circ M&apos; S&apos;&apos;$) for each of the 7 planets (Sun through Saturn). The planet with the highest traversed arc becomes Atmakaraka (AK), down to the lowest as Darakaraka (DK).
          </p>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900">
                Scope (7 Planets):
              </span>
              {["Surya", "Chandra", "Mangal", "Budh", "Guru", "Shukra", "Shani"].map((p) => (
                <span
                  key={p}
                  className="rounded-lg border border-amber-800/15 bg-white/90 px-2.5 py-1 font-serif text-xs font-bold text-[#7c2d12] shadow-2xs"
                >
                  {p}
                </span>
              ))}
              <span className="ml-1 text-xs font-medium text-stone-500">
                (Rahu & Ketu excluded)
              </span>
            </div>

            <button
              type="button"
              onClick={copyReport}
              className="inline-flex items-center gap-2 rounded-xl bg-[#7c2d12] px-4 py-2.5 text-xs font-bold text-amber-50 shadow-sm transition hover:bg-[#9a3412] active:scale-[0.98]"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 text-emerald-300" />
                  Report Copied!
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  Copy Jaimini 7-Karaka Report
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* ═══════════════════════════════════════════════════
          BHAVESHAT BHAVAM — ARUDHA OF EVOLUTION
          ═══════════════════════════════════════════════════ */}
      <section
        id="arudha-of-evolution"
        className="scroll-mt-24 space-y-5 overflow-hidden rounded-3xl border border-teal-800/20 bg-white/85 shadow-[0_14px_40px_-26px_rgba(15,118,110,0.45)]"
      >
        <header className="flex flex-wrap items-start justify-between gap-4 border-b border-teal-800/15 bg-gradient-to-r from-teal-900 to-teal-700 px-5 py-5 text-teal-50 sm:px-6">
          <div>
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-teal-200">
              <Map className="h-3.5 w-3.5" />
              Bhaveshat Bhavam · भावेशात् भावम्
            </div>
            <h2 className="mt-1 font-serif text-2xl font-black sm:text-3xl">
              Arudha of Evolution (आरूढ़ पाद)
            </h2>
            <p className="mt-1 max-w-2xl text-xs leading-relaxed text-teal-100/85">
              Jis bhav ka Bhavesh apne se jitna aage hai, usi distance ko Bhavesh se aage ginti —
              jo bhav aaye wahi us bhav ka Arudha. Kendra (1/4/7/10) me special exception:
              bhava aur uska 7th kabhi Arudha nahi banate.
            </p>
          </div>
          <button
            type="button"
            onClick={copyArudhaReport}
            className="inline-flex items-center gap-2 rounded-xl border border-teal-100/25 bg-white/10 px-4 py-2 text-xs font-bold text-white transition hover:bg-white/20"
          >
            {arudhaCopied ? (
              <>
                <Check className="h-4 w-4 text-emerald-300" />
                Arudha report copied
              </>
            ) : (
              <>
                <Copy className="h-4 w-4" />
                Copy Arudha Report
              </>
            )}
          </button>
        </header>

        <div className="grid gap-6 px-5 pb-2 sm:px-6 lg:grid-cols-[minmax(0,360px)_1fr]">
          {/* Kundali with AL–A12 */}
          <div className="rounded-2xl border border-teal-800/15 bg-[#f0fdfa] p-3">
            <NorthChart
              signs={d1Signs}
              title="D1 · Arudha Padas"
              subtitle="AL · A2 · A3 · … · A12"
              accent="#0f766e"
              arudhaByHouse={arudhaHouses}
              showPlanets
            />
            <div className="mt-2 flex flex-wrap justify-center gap-1.5 text-[10px]">
              <span className="rounded-full bg-teal-100 px-2 py-0.5 font-bold text-teal-800">
                Teal = Arudha (AL–A12)
              </span>
              <span className="rounded-full bg-indigo-100 px-2 py-0.5 font-bold text-indigo-800">
                Blue = Planets
              </span>
              <span className="rounded-full bg-emerald-100 px-2 py-0.5 font-bold text-emerald-800">
                Green = Lagna
              </span>
            </div>
          </div>

          {/* Quick AL summary chips */}
          <div>
            <h3 className="font-serif text-lg font-bold text-teal-900">
              Arudha Summary — AL to A12
            </h3>
            <p className="mt-0.5 text-xs text-stone-500">
              Lagna: {chart.Lagna.sign}. {rashiName(chart.Lagna.sign)} · computed from D1 Bhavesh
              placements
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-4">
              {arudhaResults.map((r) => (
                <div
                  key={r.label}
                  className={`rounded-xl border p-2.5 ${
                    r.label === "AL"
                      ? "border-teal-600/40 bg-teal-50 ring-1 ring-teal-500/30"
                      : r.exceptionTriggered
                        ? "border-amber-400/40 bg-amber-50/80"
                        : "border-stone-200 bg-[#fdfaf4]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`font-mono text-sm font-black ${
                        r.label === "AL" ? "text-teal-800" : "text-stone-800"
                      }`}
                    >
                      {r.label}
                    </span>
                    <span className="text-[9px] font-semibold uppercase tracking-wide text-stone-400">
                      Bh {r.bhava}
                    </span>
                  </div>
                  <div className="mt-1 font-serif text-sm font-bold text-stone-900">
                    {r.arudhaSign}. {rashiName(r.arudhaSign)}
                  </div>
                  <div className="mt-0.5 text-[10px] text-stone-500">
                    House {r.arudhaHouse}
                    {r.exceptionTriggered && (
                      <span className="ml-1 font-semibold text-amber-700">· Kendra fix</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Detailed calculation table */}
        <div className="overflow-x-auto border-t border-teal-800/10">
          <table className="w-full min-w-[960px] text-sm">
            <thead>
              <tr className="border-b-2 border-teal-800/20 bg-teal-50 text-left text-[10px] font-bold uppercase tracking-[0.12em] text-teal-900">
                <th className="px-3 py-2.5">Pada</th>
                <th className="px-3 py-2.5">Bhava</th>
                <th className="px-3 py-2.5">Bhava Sign</th>
                <th className="px-3 py-2.5">Bhavesh</th>
                <th className="px-3 py-2.5">Lord Sign</th>
                <th className="px-3 py-2.5 text-center">Lord from Bhava</th>
                <th className="px-3 py-2.5">Relation</th>
                <th className="px-3 py-2.5 text-center">Tentative</th>
                <th className="px-3 py-2.5">Arudha Sign</th>
                <th className="px-3 py-2.5 text-center">Arudha House</th>
                <th className="px-3 py-2.5">Rule Applied</th>
              </tr>
            </thead>
            <tbody>
              {arudhaResults.map((r) => (
                <tr
                  key={r.label}
                  className={`border-b border-stone-200/70 last:border-0 ${
                    r.label === "AL"
                      ? "bg-teal-50/60"
                      : r.exceptionTriggered
                        ? "bg-amber-50/40"
                        : "bg-white"
                  }`}
                >
                  <td className="px-3 py-2 font-mono font-black text-teal-800">{r.label}</td>
                  <td className="px-3 py-2 font-mono text-stone-700">{r.bhava}</td>
                  <td className="px-3 py-2 text-stone-700">
                    {r.bhavaSign}. {rashiName(r.bhavaSign)}
                  </td>
                  <td className="px-3 py-2 font-semibold text-stone-900">{r.lord}</td>
                  <td className="px-3 py-2 text-stone-700">
                    {r.lordSign}. {rashiName(r.lordSign)}
                  </td>
                  <td className="px-3 py-2 text-center font-mono font-bold text-indigo-800">
                    {r.lordFromBhava}
                    <span className="text-[10px] text-stone-400">th</span>
                  </td>
                  <td className="px-3 py-2">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                        r.relation === "panaphara" || r.relation === "apoklima"
                          ? "bg-emerald-100 text-emerald-800"
                          : "bg-amber-100 text-amber-900"
                      }`}
                    >
                      {relationLabel(r.relation)}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-center font-mono text-stone-500">
                    H{r.tentativeHouse}
                    {r.exceptionTriggered && (
                      <span className="ml-1 text-[10px] text-rose-600">✕</span>
                    )}
                  </td>
                  <td className="px-3 py-2 font-mono font-black text-[#0f766e]">
                    {r.arudhaSign}. {rashiName(r.arudhaSign)}
                  </td>
                  <td className="px-3 py-2 text-center font-mono font-bold text-stone-800">
                    H{r.arudhaHouse}
                  </td>
                  <td className="max-w-[260px] px-3 py-2 text-[11px] leading-snug text-stone-600">
                    {r.ruleApplied}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Rules reference */}
        <div className="grid gap-3 border-t border-teal-800/10 bg-teal-50/40 px-5 py-4 text-xs leading-relaxed text-stone-700 sm:grid-cols-2 sm:px-6">
          <div className="rounded-xl border border-teal-800/15 bg-white/80 p-3">
            <h4 className="font-serif text-sm font-bold text-teal-900">
              General Rule — Panaphara &amp; Apoklima
            </h4>
            <p className="mt-1.5">
              Jab Bhavesh apne bhav se <strong>2, 5, 8, 11</strong> (Panaphara) ya{" "}
              <strong>3, 6, 9, 12</strong> (Apoklima) me ho: Bhavesh jitne bhav aage hai, utne hi
              bhav Bhavesh se aage ginti karo. Jo bhav aaye wahi Arudha.
            </p>
            <p className="mt-1 text-stone-500">
              Example: Vrishabha Lagna, Lagnesh 2nd me → 2nd se 2nd = 3rd bhav → AL.
            </p>
          </div>
          <div className="rounded-xl border border-amber-700/20 bg-amber-50/90 p-3">
            <h4 className="font-serif text-sm font-bold text-amber-900">
              Special Rule — Kendra (1 / 4 / 7 / 10)
            </h4>
            <p className="mt-1.5">
              Bhava aur uska 7th kabhi Arudha nahi banate. Isliye:
            </p>
            <ul className="mt-1.5 list-inside list-disc space-y-0.5 text-stone-600">
              <li>
                <strong>Own (1):</strong> tentative = same → final = <em>10th from bhava</em>
              </li>
              <li>
                <strong>4th:</strong> tentative = 7th → final = <em>4th (Bhavesh seat)</em>
              </li>
              <li>
                <strong>7th:</strong> tentative = same → final = <em>4th from bhava</em>
              </li>
              <li>
                <strong>10th:</strong> tentative = 7th → final = <em>10th (Bhavesh seat)</em>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* SECTION 1: 7 CHAR KARAKA CARDS */}
      <section id="char-karak" className="scroll-mt-24 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-800/15 pb-3">
          <h2 className="font-serif text-2xl font-bold text-[#7c2d12]">
            7 Char Karaka Sequence (सप्त चरकारक क्रम)
          </h2>
          <span className="text-xs font-medium text-stone-500">
            Sorted in Descending Order of Navamsha Traversed Arc
          </span>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {karakaResults.map((res) => (
            <div
              key={res.key}
              className="relative overflow-hidden rounded-2xl border border-amber-800/15 bg-white/90 p-4 shadow-[0_10px_28px_-20px_rgba(120,53,15,0.4)] transition hover:border-amber-600/40 hover:shadow-md"
            >
              <div className="flex items-center justify-between gap-2 border-b border-stone-100 pb-2.5">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-100 font-mono text-xs font-black text-amber-900">
                  #{res.rank}
                </span>
                <span
                  className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider ${res.karaka.color}`}
                >
                  {res.karaka.role}
                </span>
              </div>

              <div className="mt-3">
                <div className="font-serif text-xl font-black text-[#7c2d12]">
                  {res.karaka.devanagari}
                </div>
                <div className="text-xs font-semibold text-stone-500">
                  {res.karaka.sanskrit} ({res.karaka.english})
                </div>
              </div>

              <div className="mt-4 rounded-xl border border-amber-800/10 bg-[#fffdf8] p-3">
                <div className="text-[10px] font-bold uppercase tracking-wider text-amber-800">
                  Assigned Planet
                </div>
                <div className="mt-0.5 font-serif text-lg font-bold text-stone-900">
                  {res.label}
                </div>

                <div className="mt-2.5 flex items-baseline justify-between border-t border-stone-100 pt-2 text-xs">
                  <span className="text-stone-500">Navamsha Traversed:</span>
                  <span className="font-mono font-black text-[#9a3412]">
                    {res.traversedDMS}
                  </span>
                </div>

                <div className="mt-1 flex items-baseline justify-between text-xs">
                  <span className="text-stone-500">Navamsha No.:</span>
                  <span className="font-mono text-stone-700">
                    {res.navamshaNum}th Navamsha
                  </span>
                </div>

                <div className="mt-1 flex items-baseline justify-between text-xs">
                  <span className="text-stone-500">Local D°M&apos;S&apos;&apos;:</span>
                  <span className="font-mono text-stone-600">{res.localDMS}</span>
                </div>
              </div>

              <p className="mt-3 text-xs leading-relaxed text-stone-600">
                {res.karaka.significance}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* SECTION 2: MATHEMATICAL BREAKDOWN TABLE */}
      <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.6)]">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-800/10 bg-gradient-to-r from-amber-100 via-amber-50 to-transparent px-5 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#7c2d12] font-serif text-base font-bold text-amber-50">
              <Compass className="h-5 w-5" />
            </span>
            <div>
              <h3 className="font-serif text-xl font-bold text-[#7c2d12]">
                Detailed Mathematical Calculation Table
              </h3>
              <p className="text-xs text-stone-500">
                Step-by-step Navamsha Traversed Longitude = [Local D°M&apos;S&apos;&apos;] - [Navamsha Start]
              </p>
            </div>
          </div>
          <span className="rounded-full border border-amber-700/20 bg-amber-50 px-3 py-1 font-mono text-xs font-semibold text-amber-800">
            Sorted Descending (Highest to Lowest)
          </span>
        </header>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[850px] text-sm">
            <thead>
              <tr className="border-b-2 border-amber-800/20 bg-amber-50/80 text-left text-[11px] font-bold uppercase tracking-[0.14em] text-amber-800">
                <th className="px-4 py-3 text-center">Rank</th>
                <th className="px-4 py-3">Char Karaka</th>
                <th className="px-4 py-3">Planet</th>
                <th className="px-4 py-3">Local Position (D°M&apos;S&apos;&apos;)</th>
                <th className="px-4 py-3">Navamsha Slot</th>
                <th className="px-4 py-3">Navamsha Start</th>
                <th className="px-4 py-3 text-right">Traversed Arc (D°M&apos;S&apos;&apos;)</th>
                <th className="px-4 py-3 text-right">Total Seconds</th>
              </tr>
            </thead>
            <tbody>
              {karakaResults.map((res) => (
                <tr
                  key={res.key}
                  className="border-b border-stone-200/70 transition hover:bg-amber-50/50 last:border-0"
                >
                  <td className="px-4 py-3 text-center font-mono font-bold text-amber-900">
                    #{res.rank}
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-serif font-black text-[#7c2d12]">
                      {res.karaka.devanagari}
                    </span>{" "}
                    <span className="font-mono text-xs font-semibold text-stone-600">
                      ({res.karaka.role})
                    </span>
                  </td>
                  <td className="px-4 py-3 font-semibold text-stone-900">
                    {res.label}
                  </td>
                  <td className="px-4 py-3 font-mono text-stone-700">
                    {res.localDMS}
                  </td>
                  <td className="px-4 py-3 text-xs text-stone-600">
                    <span className="font-bold text-amber-800">
                      {res.navamshaNum}th Navamsha
                    </span>{" "}
                    ({(res.navamshaNum - 1) * 3}°20&apos; – {res.navamshaNum * 3}°20&apos;)
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-stone-500">
                    {res.navamshaStartDMS}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-black text-[#9a3412]">
                    {res.traversedDMS}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-xs text-stone-500">
                    {res.traversedSeconds.toLocaleString()}″
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* SECTION 3: VISUAL COMPARISON BAR CHART */}
      <section className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.6)] sm:p-6">
        <h3 className="font-serif text-xl font-bold text-[#7c2d12]">
          Navamsha Traversed Longitude Visual Gauge
        </h3>
        <p className="mt-1 text-xs text-stone-500">
          Max span per Navamsha = 03° 19&apos; 59&apos;&apos; (12,000 seconds). Bar length corresponds to relative traversed magnitude.
        </p>

        <div className="mt-5 space-y-3">
          {karakaResults.map((res) => {
            const percentage = Math.min(100, Math.max(0, (res.traversedSeconds / 12000) * 100));
            return (
              <div key={res.key} className="space-y-1">
                <div className="flex flex-wrap items-baseline justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-amber-900">#{res.rank}</span>
                    <span className="font-serif font-bold text-stone-900">{res.label}</span>
                    <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-[#7c2d12]">
                      {res.karaka.devanagari} ({res.karaka.role})
                    </span>
                  </div>
                  <div className="font-mono font-bold text-[#9a3412]">
                    {res.traversedDMS} <span className="text-stone-400">({percentage.toFixed(1)}%)</span>
                  </div>
                </div>

                <div className="h-3 w-full overflow-hidden rounded-full bg-stone-100 p-0.5 ring-1 ring-stone-200">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-amber-600 via-[#7c2d12] to-[#9a3412] transition-all duration-500"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* SECTION 4: RULE REFERENCE CARD */}
      <section className="rounded-3xl border border-amber-800/15 bg-gradient-to-b from-[#fffaf0] to-white p-5 shadow-sm sm:p-6">
        <div className="flex items-center gap-3 border-b border-amber-800/10 pb-3">
          <BookOpen className="h-5 w-5 text-[#7c2d12]" />
          <h3 className="font-serif text-lg font-bold text-[#7c2d12]">
            Jaimini 7 Char Karaka Mathematical Rulebook
          </h3>
        </div>

        <div className="mt-4 grid gap-4 text-xs leading-relaxed text-stone-700 md:grid-cols-2">
          <div className="rounded-2xl border border-amber-800/10 bg-white/70 p-4">
            <h4 className="flex items-center gap-2 font-serif text-sm font-bold text-stone-900">
              <Info className="h-4 w-4 text-amber-700" />
              1. Input Scope &amp; Exclusion Rule
            </h4>
            <p className="mt-2 text-stone-600">
              In this 7 Char Karaka scheme, strictly the 7 classical physical planets are used:{" "}
              <strong className="text-stone-900">Sun, Moon, Mars, Mercury, Jupiter, Venus, and Saturn</strong>.
              Zodiac signs are completely ignored for this specific comparison, as is Rahu and Ketu.
            </p>
          </div>

          <div className="rounded-2xl border border-amber-800/10 bg-white/70 p-4">
            <h4 className="flex items-center gap-2 font-serif text-sm font-bold text-stone-900">
              <Info className="h-4 w-4 text-amber-700" />
              2. Navamsha Traversed Formula
            </h4>
            <p className="mt-2 text-stone-600">
              Every sign spans 30° divided into 9 Navamshas of 3° 20&apos; 00&apos;&apos; each (12,000 seconds).
            </p>
            <div className="mt-2 rounded-lg bg-amber-50 p-2 font-mono text-[11px] font-semibold text-[#7c2d12]">
              Traversed Arc = [Planet Local D°M&apos;S&apos;&apos;] - [Navamsha Start D°M&apos;S&apos;&apos;]
            </div>
          </div>
        </div>
      </section>

      <MandookDashaSection />
    </div>
  );
}
