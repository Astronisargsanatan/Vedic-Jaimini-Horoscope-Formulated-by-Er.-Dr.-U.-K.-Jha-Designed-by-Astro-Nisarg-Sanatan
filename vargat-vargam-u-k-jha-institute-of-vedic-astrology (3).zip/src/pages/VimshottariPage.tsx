import { useMemo, useState } from "react";
import {
  LEVEL_NAMES,
  LORD_HINDI,
  bhuktaBhogya,
  computeVimshottari,
  formatDate,
  formatDuration,
  type DashaPeriod,
} from "../lib/vimshottari";
import { rashiName } from "../lib/astro";
import { useChart } from "../state/ChartContext";
import AarshaVimshottariSection from "../components/AarshaVimshottariSection";
import DashaPraveshModal from "../components/DashaPraveshModal";
import type { DashaPraveshRequest, PraveshAnchor } from "../lib/dashaPravesh";

const LEVEL_COLOR: Record<number, string> = {
  1: "text-[#7c2d12]",
  2: "text-rose-800",
  3: "text-indigo-800",
  4: "text-teal-800",
  5: "text-purple-800",
};

/**
 * Birth instant for dasha.
 * Preferred: exact UTC instant already resolved on Home (incl. IST/local offset).
 * Fallback: DOB + TOB interpreted as IST (+05:30).
 */
function resolveBirthInstant(native?: {
  date?: string;
  time?: string;
  birthUtc?: string;
}): { instant: Date; source: "utc" | "ist" | "today" } {
  if (native?.birthUtc) {
    const d = new Date(native.birthUtc);
    if (!Number.isNaN(d.getTime())) return { instant: d, source: "utc" };
  }

  const m = (native?.date ?? "").trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!m) return { instant: new Date(), source: "today" };

  const t = (native?.time ?? "").trim().match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?/);
  const hh = t ? Number(t[1]) : 12;
  const mm = t ? Number(t[2]) : 0;
  const ss = t ? Number(t[3] ?? 0) : 0;

  // Treat as IST (+05:30) when no resolved UTC instant exists.
  const wallAsUtc = Date.UTC(Number(m[3]), Number(m[2]) - 1, Number(m[1]), hh, mm, ss);
  return { instant: new Date(wallAsUtc - 330 * 60000), source: "ist" };
}

function DashaRow({
  period,
  now,
  depth,
  isActivePath,
  activePath,
  path,
  onOpenPravesh,
}: {
  period: DashaPeriod;
  now: Date;
  depth: number;
  isActivePath: boolean;
  activePath: DashaPeriod[];
  path: PraveshAnchor[];
  onOpenPravesh: (period: DashaPeriod, path: PraveshAnchor[]) => void;
}) {
  const [open, setOpen] = useState(isActivePath && depth < 3);
  const bb = bhuktaBhogya(period, now);
  const active = now >= period.start && now < period.end;
  const hasChildren = period.children && period.children.length > 0;

  return (
    <>
      <tr
        className={`border-b border-stone-200/60 ${
          active ? "bg-emerald-50/70" : depth % 2 === 0 ? "bg-white" : "bg-[#fdfaf4]"
        }`}
      >
        <td className="py-2 pr-2" style={{ paddingLeft: `${8 + depth * 18}px` }}>
          <button
            type="button"
            onClick={() => hasChildren && setOpen((v) => !v)}
            className="flex items-center gap-2 text-left"
          >
            {hasChildren ? (
              <span className="font-mono text-xs text-stone-400">{open ? "▾" : "▸"}</span>
            ) : (
              <span className="w-3" />
            )}
            <span className={`font-serif text-sm font-bold ${LEVEL_COLOR[period.level]}`}>
              {LORD_HINDI[period.lord]} <span className="text-stone-400">·</span> {period.lord}
            </span>
            {active && (
              <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-[9px] font-black uppercase tracking-wide text-white">
                Active
              </span>
            )}
          </button>
        </td>
        <td className="py-2 pr-2 text-[10px] uppercase tracking-wide text-stone-400">
          L{period.level}
        </td>
        <td className="py-2 pr-2 font-mono text-xs text-stone-600">{formatDate(period.start)}</td>
        <td className="py-2 pr-2 font-mono text-xs text-stone-600">{formatDate(period.end)}</td>
        <td className="py-2 pr-2 text-xs text-stone-600">{formatDuration(period.durationMs)}</td>
        <td className="py-2 pr-2 text-xs text-stone-500">{active ? bb.bhuktaLabel : active ? "" : ""}</td>
        <td className="py-2 pr-2 text-xs text-stone-500">{active ? bb.bhogyaLabel : ""}</td>
        <td className="py-2 pr-2">
          {period.level <= 3 && (
            <button
              type="button"
              onClick={() => onOpenPravesh(period, path)}
              className="whitespace-nowrap rounded-lg border border-indigo-700/20 bg-indigo-50 px-2 py-1 text-[9px] font-bold text-indigo-800 hover:bg-indigo-100"
            >
              View Dasha Pravesh Chart
            </button>
          )}
        </td>
      </tr>
      {open &&
        hasChildren &&
        period.children!.map((child, i) => (
          <DashaRow
            key={`${child.lord}-${child.level}-${i}`}
            period={child}
            now={now}
            depth={depth + 1}
            isActivePath={activePath.includes(child)}
            activePath={activePath}
            path={[
              ...path,
              {
                level:
                  child.level === 2
                    ? "Antardasha"
                    : child.level === 3
                      ? "Pratyantar Dasha"
                      : "Bhukti",
                name: child.lord,
                start: child.start,
              },
            ]}
            onOpenPravesh={onOpenPravesh}
          />
        ))}
    </>
  );
}

function PrachalitVimshottariSection() {
  const { chart, native } = useChart();
  const [pravesh, setPravesh] = useState<DashaPraveshRequest | null>(null);
  const now = useMemo(() => new Date(), []);
  const { instant: birth, source: birthSource } = useMemo(
    () => resolveBirthInstant(native ?? undefined),
    [native],
  );
  const result = useMemo(() => computeVimshottari(chart, birth, now), [chart, birth, now]);

  const levels = ["Mahadasha", "Antardasha", "Pratyantar", "Sukshma", "Pran"];
  const hasNative = Boolean(native?.date && native?.time);

  const SOURCE_LABEL: Record<string, string> = {
    utc: "Home का resolved UTC instant (timezone सहित)",
    ist: "DOB/TOB को IST (+05:30) माना गया",
    today: "जन्म विवरण नहीं मिला — आज की date reference",
  };

  return (
    <div className="space-y-6">
      {!hasNative && (
        <div className="rounded-2xl border-2 border-amber-500 bg-amber-50 px-5 py-4 text-sm text-amber-900">
          <strong>कृपया पहले Home page पर जन्म विवरण भरें।</strong> नीचे की गणना sample chart और
          आज की date पर आधारित है — यही गलत दशा-तिथियाँ दे रही थी। Home → Birth Details →{" "}
          <strong>Calculate Horoscope</strong> करें, तब यह section सही हो जाएगा।
        </div>
      )}
      <header className="rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-6 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">
          Chandra-based Dasha · 120-year cycle
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Vimshottari Dasha
        </h1>
        <p className="mt-2 font-serif text-lg font-bold text-[#9a3412]">
          प्रचलित यवन विंशोत्तरी दशा
        </p>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-stone-600 sm:text-base">
          चन्द्रमा की डिग्री (नक्षत्र + traversed भाग) से गणना। महादशा → अंतर्दशा → प्रत्यंतर →
          सूक्ष्म → प्राण, पाँचों स्तर भुक्त व भोग्य काल के साथ।
        </p>

        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <div className="rounded-2xl border border-amber-800/15 bg-white/80 px-4 py-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-amber-700">
              चन्द्र नक्षत्र
            </div>
            <div className="mt-1 font-serif text-lg font-black text-[#7c2d12]">
              {result.moon.nakshatraName}
            </div>
            <div className="text-[10px] text-stone-500">
              पद {result.moon.pada} · स्वामी {LORD_HINDI[result.moon.nakshatraLord]}
            </div>
          </div>
          <div className="rounded-2xl border border-amber-800/15 bg-white/80 px-4 py-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-amber-700">
              चन्द्र राशि
            </div>
            <div className="mt-1 font-serif text-lg font-black text-stone-800">
              {rashiName(chart.Chandra.sign)}
            </div>
            <div className="font-mono text-[10px] text-stone-500">
              {result.moon.moonLongitude.toFixed(3)}° sidereal
            </div>
          </div>
          <div className="rounded-2xl border border-rose-300/40 bg-rose-50 px-4 py-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-rose-700">
              भुक्त काल (जन्म से पहले बीता)
            </div>
            <div className="mt-1 font-serif text-lg font-black text-rose-800">
              {formatDuration(result.bhuktaAtBirthMs)}
            </div>
            <div className="text-[10px] text-rose-700/80">
              {LORD_HINDI[result.moon.nakshatraLord]} दशा का बीता भाग
            </div>
          </div>
          <div className="rounded-2xl border border-emerald-700/25 bg-emerald-50 px-4 py-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
              भोग्य काल (DOB में जुड़ेगा)
            </div>
            <div className="mt-1 font-serif text-lg font-black text-emerald-800">
              {formatDuration(result.bhogyaAtBirthMs)}
            </div>
            <div className="text-[10px] text-emerald-800/80">
              {LORD_HINDI[result.moon.nakshatraLord]} दशा का शेष
            </div>
          </div>
          <div className="rounded-2xl border border-amber-800/15 bg-white/80 px-4 py-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-amber-700">
              जन्म तिथि + भोग्य काल
            </div>
            <div className="mt-1 font-serif text-lg font-black text-stone-800">
              {formatDate(birth)}
            </div>
            <div className="font-mono text-[10px] text-stone-500">
              + {formatDuration(result.bhogyaAtBirthMs)} ={" "}
              {formatDate(
                new Date(birth.getTime() + result.bhogyaAtBirthMs),
              )}
            </div>
            <div className="mt-1 border-t border-stone-200 pt-1 text-[10px] font-semibold text-stone-600">
              जन्म-क्षण स्रोत: {SOURCE_LABEL[birthSource]}
            </div>
          </div>
        </div>

        <div className="mt-4 rounded-2xl border border-indigo-700/15 bg-indigo-50/70 px-4 py-3 text-xs leading-relaxed text-indigo-900">
          <strong>गणना-विधि:</strong> (1) चन्द्रमा <strong>{result.moon.nakshatraName}</strong>{" "}
          नक्षत्र में है, जिसका स्वामी <strong>{LORD_HINDI[result.moon.nakshatraLord]}</strong> है —
          अतः दशा इसी से आरम्भ होगी। (2) चन्द्रमा नक्षत्र के{" "}
          <strong>{(result.moon.traversedFraction * 100).toFixed(2)}%</strong> भाग को पार कर चुका
          है, अतः भुक्त ={" "}
          <span className="font-mono">{formatDuration(result.bhuktaAtBirthMs)}</span> तथा भोग्य ={" "}
          <span className="font-mono">{formatDuration(result.bhogyaAtBirthMs)}</span>। (3) यह{" "}
          <strong>भोग्य काल जन्म-तिथि में जोड़ा</strong> जाता है, अतः{" "}
          {LORD_HINDI[result.moon.nakshatraLord]} महादशा का अंत{" "}
          <span className="font-mono font-bold">
            {formatDate(new Date(birth.getTime() + result.bhogyaAtBirthMs))}
          </span>{" "}
          होगा। इसके बाद की सभी महादशाएँ क्रम में चलती हैं।
        </div>
      </header>

      {/* ACTIVE DASHA */}
      {result.activePath.length > 0 && (
        <section className="overflow-hidden rounded-3xl border-2 border-emerald-500/50 bg-gradient-to-r from-emerald-50 to-amber-50 p-5 shadow-[0_14px_42px_-28px_rgba(5,150,105,0.5)] sm:p-6">
          <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-emerald-700">
            वर्तमान चालू दशा (Active Now · {formatDate(now)})
          </div>
          <div className="mt-3 flex flex-wrap items-stretch gap-2">
            {result.activePath.map((p, i) => {
              const bb = bhuktaBhogya(p, now);
              return (
                <div
                  key={`active-${i}`}
                  className="min-w-[150px] flex-1 rounded-2xl border border-emerald-700/20 bg-white/85 px-4 py-3"
                >
                  <div className="text-[9px] font-bold uppercase tracking-wider text-emerald-700">
                    {levels[i]}
                  </div>
                  <div className="mt-0.5 font-serif text-xl font-black text-[#7c2d12]">
                    {LORD_HINDI[p.lord]}
                  </div>
                  <div className="text-[10px] text-stone-500">{p.lord}</div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-stone-200">
                    <div className="h-full rounded-full bg-emerald-600" style={{ width: `${bb.percent}%` }} />
                  </div>
                  <div className="mt-1 flex justify-between text-[9px] text-stone-500">
                    <span>भुक्त {bb.bhuktaLabel}</span>
                    <span>भोग्य {bb.bhogyaLabel}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* FULL TABLE */}
      <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.5)]">
        <div className="border-b border-amber-800/10 bg-gradient-to-r from-amber-100 via-amber-50 to-transparent px-5 py-4">
          <h2 className="font-serif text-xl font-bold text-[#7c2d12]">
            पूर्ण दशा तालिका · Maha → Antar → Pratyantar → Sukshma → Pran
          </h2>
          <p className="text-xs text-stone-500">
            किसी भी पंक्ति के ▸ पर क्लिक करके उसकी उपदशाएँ खोलें। चालू दशा हरे रंग में।
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-sm">
            <thead>
              <tr className="border-b border-amber-800/20 bg-amber-50 text-left text-[10px] uppercase tracking-[0.12em] text-amber-800">
                <th className="py-2.5 pl-3 pr-2">दशा स्वामी</th>
                <th className="py-2.5 pr-2">स्तर</th>
                <th className="py-2.5 pr-2">आरंभ</th>
                <th className="py-2.5 pr-2">अंत</th>
                <th className="py-2.5 pr-2">अवधि</th>
                <th className="py-2.5 pr-2">भुक्त काल</th>
                <th className="py-2.5 pr-2">भोग्य काल</th>
                <th className="py-2.5 pr-2">Pravesh Chart</th>
              </tr>
            </thead>
            <tbody>
              {result.mahadashas.map((maha, i) => (
                <DashaRow
                  key={`maha-${maha.lord}-${i}`}
                  period={maha}
                  now={now}
                  depth={0}
                  isActivePath={result.activePath.includes(maha)}
                  activePath={result.activePath}
                  path={[{ level: "Mahadasha", name: maha.lord, start: maha.start }]}
                  onOpenPravesh={(period, path) =>
                    setPravesh({
                      system: "Prachalit Yavan Vimshottari Dasha",
                      selected: {
                        level:
                          period.level === 1
                            ? "Mahadasha"
                            : period.level === 2
                              ? "Antardasha"
                              : "Pratyantar Dasha",
                        name: period.lord,
                        start: period.start,
                      },
                      path,
                    })
                  }
                />
              ))}
            </tbody>
          </table>
        </div>
        <div className="border-t border-amber-800/10 bg-[#fdfaf4] px-5 py-3 text-[11px] text-stone-500">
          {Object.entries(LEVEL_NAMES).map(([lvl, name]) => (
            <span key={lvl} className="mr-3 inline-block">
              <strong className={LEVEL_COLOR[Number(lvl)]}>L{lvl}</strong> = {name}
            </span>
          ))}
        </div>
      </section>
      <DashaPraveshModal request={pravesh} native={native} onClose={() => setPravesh(null)} />
    </div>
  );
}

export default function VimshottariPage() {
  const [section, setSection] = useState<"prachalit" | "aarsha">("prachalit");

  return (
    <div className="space-y-6">
      <nav className="sticky top-[62px] z-20 grid gap-2 rounded-2xl border border-amber-800/20 bg-[#fffaf0]/95 p-2 shadow-lg backdrop-blur sm:grid-cols-2">
        <button
          type="button"
          onClick={() => setSection("prachalit")}
          className={`rounded-xl px-4 py-3 text-left transition ${
            section === "prachalit"
              ? "bg-[#7c2d12] text-amber-50 shadow"
              : "border border-amber-800/15 bg-white text-stone-700 hover:bg-amber-50"
          }`}
        >
          <span className="block font-serif text-sm font-black sm:text-base">
            1. प्रचलित यवन विंशोत्तरी दशा
          </span>
          <span className={`mt-0.5 block text-[10px] ${section === "prachalit" ? "text-amber-100/80" : "text-stone-500"}`}>
            Moon Nakshatra based standard Vimshottari
          </span>
        </button>
        <button
          type="button"
          onClick={() => setSection("aarsha")}
          className={`rounded-xl px-4 py-3 text-left transition ${
            section === "aarsha"
              ? "bg-indigo-800 text-white shadow"
              : "border border-indigo-800/15 bg-white text-stone-700 hover:bg-indigo-50"
          }`}
        >
          <span className="block font-serif text-sm font-black sm:text-base">
            2. ऋषि प्रणीत आर्ष विंशोत्तरी दशा
          </span>
          <span className={`mt-0.5 block text-[10px] ${section === "aarsha" ? "text-indigo-100/80" : "text-stone-500"}`}>
            Krittikadi / Ardradi · Hora + Paksha · Triggering Planet
          </span>
        </button>
      </nav>

      {section === "prachalit" ? (
        <PrachalitVimshottariSection />
      ) : (
        <AarshaVimshottariSection />
      )}
    </div>
  );
}
