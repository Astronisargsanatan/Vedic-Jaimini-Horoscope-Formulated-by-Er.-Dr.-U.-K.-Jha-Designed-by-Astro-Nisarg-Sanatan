import { useState } from "react";
import AshtakavargaSection from "../components/AshtakavargaSection";
import MuktashtakiDashaSection from "../components/MuktashtakiDashaSection";

export default function AshtakavargaPage() {
  const [tab, setTab] = useState<"ashtakavarga" | "muktashtaki">("ashtakavarga");

  return (
    <div className="space-y-6">
      <nav className="sticky top-[62px] z-20 grid gap-2 rounded-2xl border border-amber-800/20 bg-[#fffaf0]/95 p-2 shadow-lg backdrop-blur sm:grid-cols-2">
        <button
          type="button"
          onClick={() => setTab("ashtakavarga")}
          className={`rounded-xl px-4 py-3 text-left ${
            tab === "ashtakavarga"
              ? "bg-[#7c2d12] text-amber-50"
              : "border border-amber-800/15 bg-white text-stone-700"
          }`}
        >
          <strong className="block font-serif">Ashtakavarga</strong>
          <span className="text-[10px] opacity-75">Prastara · Bhinna · Sarva 386</span>
        </button>
        <button
          type="button"
          onClick={() => setTab("muktashtaki")}
          className={`rounded-xl px-4 py-3 text-left ${
            tab === "muktashtaki"
              ? "bg-indigo-800 text-white"
              : "border border-indigo-800/15 bg-white text-stone-700"
          }`}
        >
          <strong className="block font-serif">Muktashtaki Dasha</strong>
          <span className="text-[10px] opacity-75">Maha · Antar · Pratyantar · ECP</span>
        </button>
      </nav>

      {tab === "ashtakavarga" ? <AshtakavargaSection /> : <MuktashtakiDashaSection />}
    </div>
  );
}
