import { useState } from "react";
import {
  PLANETS,
  VARGAS,
  computeVarga,
  formatDMS,
  houseOf,
  rashiFull,
  rashiName,
  vargaRange,
  type PlanetKey,
  type VargaId,
} from "../lib/astro";
import NorthChart from "../components/NorthChart";
import ConsolidatedSummary from "../components/ConsolidatedSummary";
import { useChart } from "../state/ChartContext";

function VargaCard({ id }: { id: VargaId }) {
  const { chart } = useChart();
  const meta = VARGAS.find((v) => v.id === id)!;
  const signs = computeVarga(chart, id);

  return (
    <section
      id={id}
      className="scroll-mt-24 overflow-hidden rounded-3xl border border-amber-800/15 bg-white/80 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.6)]"
    >
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-800/10 bg-gradient-to-r from-amber-100 via-amber-50 to-transparent px-5 py-4">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#7c2d12] font-serif text-sm font-black text-amber-50">
            {id}
          </span>
          <div>
            <h3 className="font-serif text-xl font-bold text-[#7c2d12]">
              {id} — {meta.name}{" "}
              <span className="font-sans text-sm font-normal text-stone-500">{meta.sanskrit}</span>
            </h3>
            <p className="text-xs text-stone-500">
              {meta.division} · {meta.group} · {meta.note}
            </p>
          </div>
        </div>
        <span className="rounded-full border border-amber-700/25 bg-amber-50 px-3 py-1 font-mono text-xs font-semibold text-amber-800">
          Varga Lagna: {signs.Lagna}. {rashiName(signs.Lagna)}
        </span>
      </header>

      <div className="grid gap-6 p-5 lg:grid-cols-[minmax(0,360px)_1fr]">
        <div className="rounded-2xl border border-amber-800/10 bg-[#fffdf8] p-3">
          <NorthChart signs={signs} />
          <div className="mt-2 text-center text-[11px] text-stone-500">
            La · Su · Ch · Ma · Bu · Gu · Sk · Sa · Ra · Ke
          </div>
        </div>

        <div className="overflow-x-auto">
          <h4 className="mb-2 font-serif text-sm font-bold uppercase tracking-wide text-[#7c2d12]">
            Planetary Verification Table
          </h4>
          <table className="w-full min-w-[460px] text-sm">
            <thead>
              <tr className="border-b border-amber-800/20 text-left text-[11px] uppercase tracking-[0.12em] text-amber-700">
                <th className="py-2 pr-2">Planet</th>
                <th className="py-2 pr-2">D1 Sign</th>
                <th className="py-2 pr-2">Degree</th>
                <th className="py-2 pr-2">Range</th>
                <th className="py-2 pr-2">{id} Sign</th>
                <th className="py-2 text-center">House</th>
              </tr>
            </thead>
            <tbody>
              {PLANETS.map((p) => {
                const pos = chart[p.key as PlanetKey];
                const vs = signs[p.key as PlanetKey];
                return (
                  <tr key={p.key} className="border-b border-stone-200/70 last:border-0">
                    <td className="py-1.5 pr-2 font-semibold text-stone-800">
                      {p.short} · {p.label.split(" ")[0]}
                    </td>
                    <td className="py-1.5 pr-2 text-stone-600">
                      {pos.sign}. {rashiName(pos.sign)}
                    </td>
                    <td className="py-1.5 pr-2 font-mono text-xs text-stone-500">
                      {formatDMS(pos)}
                    </td>
                    <td className="py-1.5 pr-2 font-mono text-xs text-stone-500">
                      {vargaRange(id, pos)}
                    </td>
                    <td className="py-1.5 pr-2 font-mono font-bold text-[#9a3412]">
                      {vs}. {rashiName(vs)}
                    </td>
                    <td className="py-1.5 text-center font-mono text-stone-700">
                      {houseOf(vs, signs.Lagna)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

export default function VargatVargamPage({ onGoHome }: { onGoHome: () => void }) {
  const { chart } = useChart();
  const [filter, setFilter] = useState<VargaId | "ALL">("ALL");
  const list = filter === "ALL" ? VARGAS.map((v) => v.id) : [filter];

  return (
    <div className="space-y-6">
      {/* summary */}
      <section className="rounded-3xl border border-amber-800/15 bg-gradient-to-b from-[#fffaf0] to-[#f9ecd6] p-5 shadow-[0_12px_36px_-26px_rgba(120,53,15,0.6)] sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="font-serif text-3xl font-black uppercase tracking-tight text-[#7c2d12]">
              Vargat Vargam
            </h2>
            <p className="mt-1 text-sm text-stone-600">
              Eight divisional charts generated automatically from the Home Page longitudes.
            </p>
            <div className="mt-3 inline-flex flex-wrap items-center gap-2 rounded-xl border border-amber-700/25 bg-white/80 px-4 py-2">
              <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-amber-700">
                Lagna
              </span>
              <span className="font-serif text-lg font-bold text-[#4a2511]">
                {rashiFull(chart.Lagna.sign)}
              </span>
              <span className="font-mono text-sm text-stone-600">{formatDMS(chart.Lagna)}</span>
            </div>
          </div>
          <button
            onClick={onGoHome}
            className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-sm font-semibold text-stone-600 transition hover:bg-stone-50"
          >
            ← Edit positions on Home
          </button>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <button
            onClick={() => setFilter("ALL")}
            className={`rounded-lg border px-3 py-1.5 text-sm font-semibold transition ${
              filter === "ALL"
                ? "border-amber-600 bg-amber-600 text-white"
                : "border-stone-300 bg-white text-stone-600 hover:bg-amber-50"
            }`}
          >
            All 8
          </button>
          {VARGAS.map((v) => (
            <button
              key={v.id}
              onClick={() => setFilter(v.id)}
              className={`rounded-lg border px-3 py-1.5 text-sm font-semibold transition ${
                filter === v.id
                  ? "border-amber-600 bg-amber-600 text-white"
                  : "border-stone-300 bg-white text-stone-600 hover:bg-amber-50"
              }`}
            >
              {v.id} · {v.name}
            </button>
          ))}
          <a
            href="#dashvarga-summary"
            className="ml-auto rounded-lg border border-emerald-700/25 bg-emerald-50 px-3 py-1.5 text-sm font-semibold text-emerald-800 transition hover:bg-emerald-100"
          >
            Final Summary ↓
          </a>
        </div>
      </section>

      {list.map((id) => (
        <VargaCard key={id} id={id} />
      ))}

      {/* Always last: one consolidated view of D1, all eight Vargas and manual engineering input. */}
      <ConsolidatedSummary />
    </div>
  );
}
