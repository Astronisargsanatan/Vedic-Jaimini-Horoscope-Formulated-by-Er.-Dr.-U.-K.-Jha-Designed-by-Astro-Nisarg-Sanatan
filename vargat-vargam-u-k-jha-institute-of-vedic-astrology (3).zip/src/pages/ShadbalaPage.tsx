import { useMemo, useState } from "react";
import { BarChart3, Calculator, Info } from "lucide-react";
import {
  SHADBALA_EXPLANATION,
  computeShadbala,
  rupa,
  type ShadbalaPlanetResult,
} from "../lib/shadbala";
import { rashiName } from "../lib/astro";
import { useChart } from "../state/ChartContext";

function statusClass(status: ShadbalaPlanetResult["status"]) {
  if (status === "Strong") return "bg-emerald-100 text-emerald-800 border-emerald-700/20";
  if (status === "Adequate") return "bg-amber-100 text-amber-800 border-amber-700/20";
  return "bg-rose-100 text-rose-800 border-rose-700/20";
}

export default function ShadbalaPage() {
  const { chart, native } = useChart();
  const result = useMemo(() => computeShadbala(chart, native), [chart, native]);
  const [selected, setSelected] = useState(result.planets[0].planet);
  const active = result.planets.find((planet) => planet.planet === selected) ?? result.planets[0];

  return (
    <div className="space-y-7">
      <header className="rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-5 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">
          <Calculator className="h-4 w-4" /> B.V. Raman / Parashari Graha Bala Worksheet
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Shadbala · षड्बल
        </h1>
        <p className="mt-3 max-w-4xl text-sm leading-relaxed text-stone-600 sm:text-base">
          Seven classical planets ke liye Sthana, Dig, Kala, Cheshta, Naisargika aur Drik Bala ka
          transparent Virupa/Rupa workout. Minimum requirement B.V. Raman/BPHS thresholds se compare hota hai.
        </p>
        <div className="mt-5 grid gap-3 sm:grid-cols-3">
          <Metric label="Strongest Planet" value={`${result.strongest.planet} · ${result.strongest.totalVirupas.toFixed(1)} V`} />
          <Metric label="Weakest Planet" value={`${result.weakest.planet} · ${result.weakest.totalVirupas.toFixed(1)} V`} />
          <Metric label="Unit" value="60 Virupa = 1 Rupa" />
        </div>
      </header>

      <section className="rounded-3xl border border-indigo-700/15 bg-white/85 p-5 shadow-sm sm:p-6">
        <div className="flex items-start gap-3">
          <Info className="mt-1 h-5 w-5 shrink-0 text-indigo-800" />
          <div>
            <h2 className="font-serif text-xl font-black text-[#7c2d12]">
              How this Shadbala result is made · यह परिणाम कैसे निकला
            </h2>
            <p className="mt-2 text-sm leading-7 text-stone-600">
              Every planet receives six component scores in Virupas. The final number is a direct
              addition: <strong>Sthana + Dig + Kala + Cheshta + Naisargika + Drik</strong>. Then it
              is compared with the B.V. Raman/BPHS required minimum. हर ग्रह के छह बल Virupa में
              जोड़े जाते हैं और फिर required minimum से तुलना होती है।
            </p>
          </div>
        </div>
        <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {SHADBALA_EXPLANATION.map((item) => (
            <div key={item.component} className="rounded-2xl border border-stone-200 bg-[#fdfaf4] p-4">
              <div className="font-serif text-sm font-black text-[#7c2d12]">{item.component}</div>
              <div className="mt-1 rounded-lg bg-white px-2 py-1 font-mono text-[10px] font-bold text-stone-700">
                {item.formula}
              </div>
              <p className="mt-2 text-xs leading-5 text-stone-600">{item.english}</p>
              <p className="mt-1 text-xs leading-5 text-stone-600">{item.hindi}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-sm">
        <header className="border-b border-amber-800/10 bg-amber-50 px-4 py-4 sm:px-6">
          <h2 className="font-serif text-xl font-black text-[#7c2d12]">Planet Ranking & Required Strength</h2>
          <p className="text-xs text-stone-500">Click any row to see the full component workout.</p>
        </header>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[780px] text-sm">
            <thead>
              <tr className="bg-amber-50 text-left text-[10px] font-bold uppercase tracking-wide text-amber-900">
                <th className="px-3 py-2">Planet</th>
                <th className="px-3 py-2">D1 Rashi</th>
                <th className="px-3 py-2 text-right">Total Virupa</th>
                <th className="px-3 py-2 text-right">Rupa</th>
                <th className="px-3 py-2 text-right">Required</th>
                <th className="px-3 py-2 text-right">Ratio</th>
                <th className="px-3 py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {result.planets.map((planet) => (
                <tr
                  key={planet.planet}
                  onClick={() => setSelected(planet.planet)}
                  className={`cursor-pointer border-t border-stone-100 transition hover:bg-amber-50 ${
                    selected === planet.planet ? "bg-amber-50" : "bg-white"
                  }`}
                >
                  <td className="px-3 py-2 font-serif font-black text-[#7c2d12]">{planet.planet}</td>
                  <td className="px-3 py-2">{chart[planet.planet].sign}. {rashiName(chart[planet.planet].sign)}</td>
                  <td className="px-3 py-2 text-right font-mono font-bold">{planet.totalVirupas.toFixed(2)}</td>
                  <td className="px-3 py-2 text-right font-mono">{rupa(planet.totalVirupas)}</td>
                  <td className="px-3 py-2 text-right font-mono">{planet.requiredVirupas}</td>
                  <td className="px-3 py-2 text-right font-mono">{(planet.ratio * 100).toFixed(1)}%</td>
                  <td className="px-3 py-2">
                    <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${statusClass(planet.status)}`}>
                      {planet.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-amber-700" />
            <h2 className="font-serif text-xl font-black text-[#7c2d12]">{active.planet} Component Breakdown</h2>
          </div>
          <div className="mt-4 space-y-3">
            {active.components.map((component) => {
              const width = Math.max(0, Math.min(100, (component.virupas / 180) * 100));
              return (
                <div key={component.name}>
                  <div className="flex items-center justify-between gap-3 text-xs">
                    <span className="font-semibold text-stone-700">{component.sanskrit} · {component.name}</span>
                    <span className="font-mono font-bold text-[#7c2d12]">{component.virupas.toFixed(2)} V</span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-stone-100">
                    <div className="h-full rounded-full bg-[#7c2d12]" style={{ width: `${width}%` }} />
                  </div>
                  <p className="mt-1 text-[10px] leading-relaxed text-stone-500">{component.note}</p>
                </div>
              );
            })}
          </div>
          <div className="mt-5 rounded-2xl border-2 border-emerald-600/25 bg-emerald-50 p-4">
            <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">Total</div>
            <div className="mt-1 font-mono text-2xl font-black text-emerald-800">
              {active.totalVirupas.toFixed(2)} Virupas · {active.rupas.toFixed(2)} Rupas
            </div>
            <p className="mt-2 text-xs text-emerald-900">{active.summary}</p>
            <p className="mt-2 border-t border-emerald-700/15 pt-2 font-mono text-[11px] text-emerald-950">
              {active.components.map((item) => item.virupas.toFixed(2)).join(" + ")} ={" "}
              {active.totalVirupas.toFixed(2)} V
            </p>
          </div>
        </div>

        <div className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
          <h2 className="font-serif text-xl font-black text-[#7c2d12]">Sthana Bala Detailed Workout</h2>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <thead>
                <tr className="bg-amber-50 text-left text-[10px] font-bold uppercase tracking-wide text-amber-900">
                  <th className="px-3 py-2">Sub Bala</th>
                  <th className="px-3 py-2 text-right">Virupa</th>
                  <th className="px-3 py-2">Formula / Data</th>
                </tr>
              </thead>
              <tbody>
                {active.sthanaSub.map((sub) => (
                  <tr key={sub.name} className="border-t border-stone-100">
                    <td className="px-3 py-2 font-semibold text-stone-800">{sub.sanskrit}<br /><span className="text-[10px] text-stone-400">{sub.name}</span></td>
                    <td className="px-3 py-2 text-right font-mono font-bold text-[#7c2d12]">{sub.virupas.toFixed(2)}</td>
                    <td className="px-3 py-2 text-xs leading-relaxed text-stone-600">{sub.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="overflow-hidden rounded-3xl border border-amber-800/15 bg-white/85 shadow-sm">
        <header className="border-b border-amber-800/10 bg-amber-50 px-4 py-4 sm:px-6">
          <h2 className="font-serif text-xl font-black text-[#7c2d12]">
            All-Planet Component Matrix · सभी ग्रहों का घटक-सार
          </h2>
          <p className="text-xs text-stone-500">
            This table shows exactly which component created the final score.
          </p>
        </header>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[920px] text-sm">
            <thead>
              <tr className="bg-amber-50 text-left text-[10px] font-bold uppercase tracking-wide text-amber-900">
                <th className="px-3 py-2">Planet</th>
                {result.planets[0].components.map((component) => (
                  <th key={component.name} className="px-3 py-2 text-right">{component.name}</th>
                ))}
                <th className="px-3 py-2 text-right">Total</th>
                <th className="px-3 py-2 text-right">Required</th>
              </tr>
            </thead>
            <tbody>
              {result.planets.map((planet) => (
                <tr key={`matrix-${planet.planet}`} className="border-t border-stone-100">
                  <td className="px-3 py-2 font-serif font-black text-[#7c2d12]">{planet.planet}</td>
                  {planet.components.map((component) => (
                    <td key={component.name} className="px-3 py-2 text-right font-mono text-xs">
                      {component.virupas.toFixed(2)}
                    </td>
                  ))}
                  <td className="px-3 py-2 text-right font-mono font-black text-emerald-800">
                    {planet.totalVirupas.toFixed(2)}
                  </td>
                  <td className="px-3 py-2 text-right font-mono text-stone-600">
                    {planet.requiredVirupas}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-3xl border border-indigo-700/15 bg-indigo-50/70 p-5 text-xs leading-relaxed text-indigo-950 sm:p-6">
        <div className="flex items-start gap-3">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-indigo-800" />
          <div>
            <h2 className="font-serif text-lg font-black">Method Notes</h2>
            <ul className="mt-2 list-inside list-disc space-y-1">
              {result.notes.map((note) => <li key={note}>{note}</li>)}
            </ul>
            <p className="mt-3">
              For professional-grade B.V. Raman exactness, final validation against the printed tables in
              <em> Graha and Bhava Balas </em> or a Swiss Ephemeris backend is recommended, especially for
              Kala Bala, Ayana Bala and exact Drik Bala arc strengths. This module shows a complete transparent
              working model from the horoscope data currently available in the app.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-amber-800/15 bg-white/85 p-4">
      <div className="text-[9px] font-bold uppercase tracking-wider text-amber-700">{label}</div>
      <div className="mt-1 break-words font-serif text-lg font-black text-[#7c2d12]">{value}</div>
    </div>
  );
}
