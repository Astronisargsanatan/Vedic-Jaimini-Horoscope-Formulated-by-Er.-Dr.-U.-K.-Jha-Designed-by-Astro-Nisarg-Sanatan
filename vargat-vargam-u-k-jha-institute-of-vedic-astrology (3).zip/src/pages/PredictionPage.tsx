import { useMemo, useState } from "react";
import { BookOpen, Compass, Layers3, Timer } from "lucide-react";
import { computePrediction } from "../lib/prediction";
import { rashiName } from "../lib/astro";
import { useChart } from "../state/ChartContext";

type View = "overview" | "bhava" | "dasha" | "varga";

export default function PredictionPage() {
  const { chart, native, engineeringSigns } = useChart();
  const result = useMemo(
    () => computePrediction(chart, native, engineeringSigns),
    [chart, engineeringSigns, native],
  );
  const [view, setView] = useState<View>("overview");

  return (
    <div className="space-y-6">
      <header className="rounded-3xl border border-amber-800/15 bg-gradient-to-br from-[#fffaf0] via-white to-amber-50 p-5 shadow-[0_14px_42px_-28px_rgba(120,53,15,0.65)] sm:p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.22em] text-amber-700">
          Alena Integrated Jyotish Synthesis
        </div>
        <h1 className="mt-2 font-serif text-3xl font-black text-[#7c2d12] sm:text-5xl">
          Prediction · फलित विश्लेषण
        </h1>
        <p className="mt-3 max-w-4xl text-sm leading-relaxed text-stone-600 sm:text-base">
          आत्मकारक, चन्द्र, जन्म लग्न, लग्नेश, पाँच लग्न, Bhava–Bhavesh–Karaka, Arudha Pada,
          Dashvarga, Ashtakavarga और सभी सक्रिय Dasha प्रणालियों का संयुक्त देवनागरी विश्लेषण।
        </p>
        {!native?.birthUtc && (
          <div className="mt-4 rounded-xl border-2 border-amber-500 bg-amber-50 p-4 text-xs text-amber-900">
            व्यक्तिगत भविष्यफल के लिए पहले Home पर Birth Details calculate करें। अभी sample chart
            के संकेत दिख रहे हैं।
          </div>
        )}

        <nav className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {([
            ["overview", "समग्र सार", BookOpen],
            ["bhava", "12 भाव फल", Compass],
            ["dasha", "दशा समय", Timer],
            ["varga", "पाँच लग्न व वर्ग", Layers3],
          ] as const).map(([key, label, Icon]) => (
            <button
              key={key}
              type="button"
              onClick={() => setView(key)}
              className={`flex min-h-12 items-center justify-center gap-2 rounded-xl border px-3 py-2 text-sm font-bold transition ${
                view === key
                  ? "border-[#7c2d12] bg-[#7c2d12] text-amber-50"
                  : "border-amber-800/15 bg-white text-stone-700 hover:bg-amber-50"
              }`}
            >
              <Icon className="h-4 w-4" /> {label}
            </button>
          ))}
        </nav>
      </header>

      {view === "overview" && (
        <>
          <section className="grid gap-4 lg:grid-cols-[0.8fr_1.2fr]">
            <div className="rounded-3xl border-2 border-amber-500/35 bg-amber-50 p-5 shadow-sm sm:p-6">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-amber-700">
                आत्मा का मुख्य संकेत
              </div>
              <h2 className="mt-2 font-serif text-3xl font-black text-[#7c2d12]">
                आत्मकारक {result.atmakaraka}
              </h2>
              <p className="mt-1 text-sm font-semibold text-stone-700">
                {result.atmakarakaSign}. {rashiName(result.atmakarakaSign)}
              </p>
              <p className="mt-4 text-sm leading-7 text-stone-700">{result.atmakarakaText}</p>
            </div>

            <div className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
              <h2 className="font-serif text-xl font-black text-[#7c2d12]">समन्वित निष्कर्ष</h2>
              <ol className="mt-4 space-y-3">
                {result.synthesis.map((text, index) => (
                  <li key={index} className="flex gap-3 text-sm leading-7 text-stone-700">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-100 font-mono text-xs font-black text-amber-800">
                      {index + 1}
                    </span>
                    <span>{text}</span>
                  </li>
                ))}
              </ol>
            </div>
          </section>

          <section className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
            <h2 className="font-serif text-xl font-black text-[#7c2d12]">जीवन के मुख्य क्षेत्र</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {result.bhavas.map((bhava) => (
                <article key={bhava.bhava} className="rounded-2xl border border-stone-200 bg-[#fdfaf4] p-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-serif text-base font-black text-stone-900">
                      {bhava.bhava}. {bhava.title}
                    </h3>
                    <Strength value={bhava.strength} />
                  </div>
                  <p className="mt-1 text-[10px] text-stone-500">{bhava.themes}</p>
                  <p className="mt-3 text-xs leading-6 text-stone-700">{bhava.prediction}</p>
                </article>
              ))}
            </div>
          </section>
        </>
      )}

      {view === "bhava" && (
        <section className="space-y-4">
          {result.bhavas.map((bhava) => (
            <article key={bhava.bhava} className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="text-[9px] font-bold uppercase tracking-wider text-amber-700">
                    Bhava {bhava.bhava} · {bhava.arudhaLabel}
                  </div>
                  <h2 className="mt-1 font-serif text-xl font-black text-[#7c2d12]">{bhava.title}</h2>
                  <p className="text-xs text-stone-500">{bhava.themes}</p>
                </div>
                <Strength value={bhava.strength} />
              </div>

              <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                <Datum label="Bhava Rashi" value={`${bhava.janmaSign}. ${rashiName(bhava.janmaSign)}`} />
                <Datum label="Bhavesh / Lord House" value={`${bhava.lord} · H${bhava.lordHouse}`} />
                <Datum label="Natural Karaka" value={bhava.karaka.join(" · ")} />
                <Datum label="Arudha Pada" value={`${bhava.arudhaLabel} · ${bhava.arudhaSign}. ${rashiName(bhava.arudhaSign)}`} />
                <Datum label="SAV Bindus" value={`${bhava.savBindus}`} />
                <Datum label="Five-Lagna Support" value={`${bhava.supportingLagnas}/5`} />
                <Datum label="Dashvarga Repetition" value={`${bhava.vargaRepetition}/10`} />
                <Datum label="Five Lagna Signs" value={bhava.fiveLagnaSigns.join(" · ")} />
              </div>
              <p className="mt-4 rounded-xl bg-amber-50 p-4 text-sm leading-7 text-stone-700">
                {bhava.prediction}
              </p>
            </article>
          ))}
        </section>
      )}

      {view === "dasha" && (
        <section className="space-y-4">
          {result.dashas.map((dasha) => (
            <article key={dasha.system} className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
              <div className="text-[9px] font-bold uppercase tracking-wider text-amber-700">Active Timing Layer</div>
              <h2 className="mt-1 font-serif text-xl font-black text-[#7c2d12]">{dasha.system}</h2>
              <div className="mt-3 rounded-xl border border-emerald-700/20 bg-emerald-50 p-3 font-serif text-lg font-black text-emerald-900">
                {dasha.active}
              </div>
              <p className="mt-3 text-sm leading-7 text-stone-700">{dasha.indication}</p>
            </article>
          ))}
          <div className="rounded-2xl border border-indigo-700/20 bg-indigo-50 p-4 text-xs leading-6 text-indigo-950">
            समय-निर्णय में एक ही Dasha को अकेले निर्णायक नहीं माना गया है। घटना का संकेत तब मजबूत
            है जब सक्रिय Graha/Rashi संबंधित Bhava, Bhavesh, Karaka, Arudha Pada, Dashvarga और
            Ashtakavarga से भी समर्थित हो।
          </div>
        </section>
      )}

      {view === "varga" && (
        <>
          <section className="rounded-3xl border border-amber-800/15 bg-white/85 p-5 shadow-sm sm:p-6">
            <h2 className="font-serif text-xl font-black text-[#7c2d12]">पाँच लग्नों का संयुक्त दृष्टिकोण</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              {result.lagnas.map((lagna) => (
                <article key={lagna.key} className="rounded-2xl border border-stone-200 bg-[#fdfaf4] p-4">
                  <div className="text-[9px] font-bold uppercase tracking-wider text-amber-700">{lagna.key} Lagna</div>
                  <h3 className="mt-1 font-serif text-lg font-black text-[#7c2d12]">{lagna.hindi}</h3>
                  <div className="mt-2 font-mono text-sm font-bold text-stone-800">
                    {lagna.sign}. {rashiName(lagna.sign)}
                  </div>
                  <p className="mt-2 text-xs leading-5 text-stone-600">{lagna.significance}</p>
                </article>
              ))}
            </div>
          </section>

          <section className="rounded-3xl border border-indigo-700/15 bg-indigo-50/60 p-5 shadow-sm sm:p-6">
            <h2 className="font-serif text-xl font-black text-indigo-950">Dominant Lagna Rashis</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {result.dominantSigns.map((item) => (
                <div key={item.sign} className="rounded-xl border border-indigo-700/15 bg-white p-4">
                  <div className="font-serif text-lg font-black text-[#7c2d12]">
                    {item.sign}. {rashiName(item.sign)}
                  </div>
                  <div className="mt-1 font-mono text-xs font-bold text-indigo-800">
                    {item.count} reference{item.count === 1 ? "" : "s"}
                  </div>
                  <p className="mt-2 text-xs text-stone-600">{item.sources.join(" · ")}</p>
                </div>
              ))}
            </div>
          </section>
        </>
      )}

      <section className="rounded-2xl border border-rose-700/15 bg-rose-50 p-4 text-xs leading-6 text-rose-950">
        <strong>फलित सीमा:</strong> यह module शास्त्रीय संकेतों का computational synthesis है। यह
        निश्चित घटना, चिकित्सा, कानूनी या आर्थिक परिणाम की guarantee नहीं देता। Exact timing के
        लिए verified birth time, Dasha Pravesh, Gochar और देश-काल-पात्र का विशेषज्ञ परीक्षण आवश्यक है।
      </section>
    </div>
  );
}

function Strength({ value }: { value: "प्रबल" | "मध्यम" | "परिश्रम-साध्य" }) {
  return (
    <span
      className={`rounded-full px-2.5 py-1 text-[10px] font-black ${
        value === "प्रबल"
          ? "bg-emerald-100 text-emerald-800"
          : value === "मध्यम"
            ? "bg-amber-100 text-amber-800"
            : "bg-rose-100 text-rose-800"
      }`}
    >
      {value}
    </span>
  );
}

function Datum({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-stone-200 bg-[#fdfaf4] p-3">
      <div className="text-[9px] font-bold uppercase tracking-wider text-stone-500">{label}</div>
      <div className="mt-1 break-words text-xs font-bold text-stone-800">{value}</div>
    </div>
  );
}
