import { useState } from "react";
import { Menu, X } from "lucide-react";
import Logo from "./components/Logo";
import Masthead from "./components/Masthead";
import InstituteHeader from "./components/InstituteHeader";
import PanchLakshana from "./components/PanchLakshana";
import KundaliPdf from "./components/KundaliPdf";
import HomePage from "./pages/HomePage";
import VargatVargamPage from "./pages/VargatVargamPage";
import CalculatorPage from "./pages/CalculatorPage";
import JaiminiPage from "./pages/JaiminiPage";
import AshtakavargaPage from "./pages/AshtakavargaPage";
import MatchMatchingPage from "./pages/MatchMatchingPage";
import VimshottariPage from "./pages/VimshottariPage";
import DevotionalPage from "./pages/DevotionalPage";
import TransitPage from "./pages/TransitPage";
import PanchangPage from "./pages/PanchangPage";
import PredictionPage from "./pages/PredictionPage";
import VarshPraveshPage from "./pages/VarshPraveshPage";
import ShadbalaPage from "./pages/ShadbalaPage";
import { ChartProvider, useChart } from "./state/ChartContext";

type Page =
  | "home"
  | "devotional"
  | "varga"
  | "engineering"
  | "jaimini"
  | "ashtak"
  | "matching"
  | "dasha"
  | "transit"
  | "panchang"
  | "prediction"
  | "shadbala"
  | "varsh";

const NAV: { id: Page; en: string; hi: string; subEn: string; subHi: string }[] = [
  { id: "home", en: "HOME", hi: "मुखपृष्ठ", subEn: "Input + D1 Horoscope", subHi: "जन्म विवरण + मुख्य कुंडली" },
  { id: "devotional", en: "DEVOTIONAL", hi: "भक्ति", subEn: "Guru Vandana", subHi: "गुरु वन्दना · मंगलाचरण" },
  { id: "panchang", en: "PANCHANG", hi: "पञ्चाङ्ग", subEn: "Birth Panchang + Avakahada", subHi: "जन्म पञ्चाङ्ग + अवकहडा" },
  { id: "prediction", en: "PREDICTION", hi: "फलित", subEn: "Integrated Jyotish synthesis", subHi: "समन्वित ज्योतिष फलित" },
  { id: "shadbala", en: "SHADBALA", hi: "षड्बल", subEn: "B.V. Raman graha strength", subHi: "ग्रह बल गणना" },
  { id: "varsh", en: "VARSH PRAVESH", hi: "वर्ष प्रवेश", subEn: "Annual solar return", subHi: "वार्षिक सूर्य प्रत्यावर्तन" },
  { id: "varga", en: "VARGAT VARGAM", hi: "वर्गात् वर्गम्", subEn: "Divisional charts", subHi: "वर्ग कुंडलियाँ" },
  { id: "ashtak", en: "ASHTAKVARG", hi: "अष्टकवर्ग", subEn: "Bhinna + Sarva 386", subHi: "भिन्न + सर्व 386" },
  { id: "dasha", en: "VIMSHOTTARI", hi: "विंशोत्तरी दशा", subEn: "Two systems", subHi: "दो पद्धतियाँ" },
  { id: "transit", en: "TRANSIT", hi: "गोचर", subEn: "Current transit", subHi: "वर्तमान गोचर" },
  { id: "jaimini", en: "JAIMINI", hi: "जैमिनि सूत्र", subEn: "Karaka + Rashi Dashas", subHi: "कारक + राशि दशाएँ" },
  { id: "engineering", en: "VARGA ENGINEERING", hi: "वर्ग अभियांत्रिकी", subEn: "Factor combinations", subHi: "गुणन संयोजन" },
  { id: "matching", en: "MATCHING", hi: "संगति", subEn: "Match analysis", subHi: "संगति विश्लेषण" },
];

function Shell() {
  const [page, setPage] = useState<Page>("home");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { chart, native, engineeringVargaName, engineeringSigns } = useChart();

  const go = (p: Page, hash?: string) => {
    setPage(p);
    setMobileMenuOpen(false);
    window.setTimeout(() => {
      if (hash) {
        document.getElementById(hash)?.scrollIntoView({ behavior: "smooth", block: "start" });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }, 50);
  };

  return (
    <div className="app-screen min-h-screen w-full max-w-full bg-[#faf3e6] text-stone-800">
      <div className="pointer-events-none fixed inset-0 print:hidden">
        <div className="absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-amber-300/25 blur-3xl" />
        <div className="absolute top-60 right-0 h-96 w-96 rounded-full bg-orange-200/30 blur-3xl" />
      </div>

      <nav className="sticky top-0 z-30 w-full max-w-full border-b border-amber-800/15 bg-[#faf3e6]/95 backdrop-blur print:hidden">
        <div className="mx-auto flex max-w-6xl min-w-0 items-center gap-2 px-3 py-2 sm:gap-3 sm:px-6 sm:py-2.5">
          <Logo className="h-9 w-9 shrink-0 object-contain" />
          <span className="hidden min-w-0 truncate font-serif text-sm font-bold text-[#14532d] sm:block xl:max-w-36 2xl:max-w-none">
            U K Jha Institute
          </span>
          <button
            type="button"
            onClick={() => setMobileMenuOpen((value) => !value)}
            aria-expanded={mobileMenuOpen}
            aria-label="Open navigation"
            className="ml-auto flex h-10 w-10 items-center justify-center rounded-xl border border-amber-800/20 bg-white text-[#7c2d12] shadow-sm xl:hidden"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>

          <div className="ml-auto hidden min-w-0 items-center justify-end gap-1 xl:flex">
            {NAV.map((n) => (
              <button
                key={n.id}
                onClick={() => go(n.id)}
                title={n.subEn}
                className={`shrink-0 whitespace-nowrap rounded-xl px-2.5 py-2 text-[10px] font-bold uppercase tracking-wide transition 2xl:px-3 2xl:text-xs ${
                  page === n.id
                    ? "bg-[#7c2d12] text-amber-50 shadow"
                    : "text-stone-600 hover:bg-amber-100"
                }`}
              >
                {n.en}
              </button>
            ))}
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="max-h-[calc(100dvh-4rem)] overflow-y-auto overscroll-contain border-t border-amber-800/10 bg-[#fffaf0] px-3 py-3 shadow-lg xl:hidden">
            <div className="mx-auto grid max-w-6xl grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
              {NAV.map((item) => (
                <button
                  key={`mobile-${item.id}`}
                  type="button"
                  onClick={() => go(item.id)}
                  className={`min-h-16 rounded-xl border px-3 py-2 text-left transition ${
                    page === item.id
                      ? "border-[#7c2d12] bg-[#7c2d12] text-amber-50"
                      : "border-amber-800/15 bg-white text-stone-700"
                  }`}
                >
                  <span className="block text-[10px] font-black uppercase tracking-wide sm:text-xs">
                    {item.en}
                  </span>
                  <span
                    className={`mt-1 block text-[9px] leading-snug ${
                      page === item.id ? "text-amber-100/80" : "text-stone-400"
                    }`}
                  >
                    {item.subEn}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

        <main className="app-content relative mx-auto w-full max-w-6xl min-w-0 px-3 py-5 sm:px-6 sm:py-8 lg:py-10 print:hidden">
          {page === "varga" ? (
            <Masthead />
          ) : page === "home" ? (
            <InstituteHeader />
          ) : (
            <InstituteHeader compact />
          )}

          {page === "home" && (
            <div className="mt-8">
              <HomePage onGoVarga={() => go("varga")} />
            </div>
          )}

        {page === "devotional" && (
          <div className="mt-8">
            <DevotionalPage />
          </div>
        )}

        {page === "varga" && (
          <>
            <div className="mt-8">
              <PanchLakshana onOpenJaimini={() => go("jaimini", "arudha-of-evolution")} />
            </div>
            <div className="mt-8">
              <VargatVargamPage onGoHome={() => go("home")} />
            </div>
          </>
        )}

        {page === "engineering" && (
          <div className="mt-8">
            <CalculatorPage onGoVarga={() => go("varga")} />
          </div>
        )}

        {page === "jaimini" && (
          <div className="mt-8">
            <JaiminiPage />
          </div>
        )}

        {page === "ashtak" && (
          <div className="mt-8">
            <AshtakavargaPage />
          </div>
        )}

        {page === "dasha" && (
          <div className="mt-8">
            <VimshottariPage />
          </div>
        )}

        {page === "transit" && (
          <div className="mt-8">
            <TransitPage />
          </div>
        )}

        {page === "panchang" && (
          <div className="mt-8">
            <PanchangPage />
          </div>
        )}

        {page === "prediction" && (
          <div className="mt-8">
            <PredictionPage />
          </div>
        )}

        {page === "shadbala" && (
          <div className="mt-8">
            <ShadbalaPage />
          </div>
        )}

        {page === "varsh" && (
          <div className="mt-8">
            <VarshPraveshPage />
          </div>
        )}

        {page === "matching" && (
          <div className="mt-8">
            <MatchMatchingPage />
          </div>
        )}

        <footer className="mt-12 border-t border-amber-800/20 pt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Logo className="h-10 w-10 object-contain" />
              <span className="font-serif text-sm font-bold text-[#14532d]">
                U K Jha Institute of Vedic Astrology · Er. Dr. U K Jha
              </span>
            </div>
            {page === "varga" && (
              <span className="text-xs text-stone-500">
                Vargat Vargam · Panch Lakshana · Varga Engineering
              </span>
            )}
          </div>
        </footer>
      </main>

      <KundaliPdf
        chart={chart}
        native={native}
        engineeringVargaName={engineeringVargaName}
        engineeringSigns={engineeringSigns}
      />
    </div>
  );
}

export default function App() {
  return (
    <ChartProvider>
      <Shell />
    </ChartProvider>
  );
}
